/**
 * xai_engine.js - Explainable AI (XAI) & Grad-CAM Retinal Analysis Engine
 * Generates authentic retinal fundus structures, computes Grad-CAM attention heatmaps,
 * extracts lesion locations, and produces clinical reasoning reports for rural healthcare.
 */

import { t, getLanguage } from './i18n.js';

export const CLINICAL_SAMPLES = {
  normal: {
    id: 'normal',
    name: 'Normal Retina (No DR)',
    stage: 0,
    gradeName: 'ICDR Grade 0 - No Apparent Retinopathy',
    confidence: 98.6,
    risk: 'Low',
    riskClass: 'badge-success',
    biomarkers: {
      microaneurysms: 0,
      hemorrhages: 0,
      hardExudates: 0,
      cottonWool: 0,
      neovascularization: 'Absent',
      macularEdemaRisk: 'Low (< 2%)'
    },
    actionType: 'routine',
    hotspots: [
      { x: 0.52, y: 0.50, radius: 45, intensity: 0.25, label: 'Macula / Fovea' }
    ],
    explanation: {
      en: 'The retinal fundus displays healthy pink-orange coloration with well-demarcated optic disc margins. Retinal arteriolar and venular caliber is normal without tortuosity. No microaneurysms, hemorrhages, or lipid exudates detected. The Grad-CAM heatmap concentrates minimally on the central fovea confirming absence of pathological lesions.',
      hi: 'रेटिना फंडस स्वस्थ गुलाबी-नारंगी रंग दिखाता है जिसमें ऑप्टिक डिस्क के किनारे स्पष्ट हैं। कोई माइक्रोएन्यूरिज्म, रक्तस्राव या वसा जमाव नहीं मिला है। ग्रैड-सीएएम हीटमैप केवल केंद्रीय फोविया पर थोड़ा सा ध्यान केंद्रित करता है जो किसी भी बीमारी की अनुपस्थिति की पुष्टि करता है।',
      ne: 'रेटिनाको रङ स्वस्थ र अप्टिक डिस्क स्पष्ट छ। कुनै पनि रक्तनली सुन्निएको वा रगत बगेको छैन। ग्र्याड-क्याम ताप नक्साले कुनै पनि रोगजन्य क्षति नभएको पुष्टि गर्दछ।',
      ta: 'விழித்திரை ஆரோக்கியமான நிறத்துடன் காணப்படுகிறது. எந்த இரத்தக் கசிவோ அல்லது கொழுப்புப் படிவுகளோ இல்லை. Grad-CAM வெப்ப வரைபடம் அசாதாரண அறிகுறிகள் இல்லை என்பதை உறுதி செய்கிறது.',
      ar: 'يظهر قاع الشبكية لوناً صحياً وحواف قرص بصري طبيعية. لا توجد أي أمهات دم مجهرية أو نزيف أو نضح دهني. تؤكد خريطة Grad-CAM الحرارية غياب أي آفات مرضية.',
      ur: 'آنکھ کا پردہ بالکل صحت مند اور صاف ہے۔ خون کی کوئی نالی سوجی ہوئی نہیں ہے اور نہ ہی خون کا کوئی دھبہ پایا گیا ہے۔ گریڈ کیم ہیٹ میپ کسی بیماری کی عدم موجودگی کی تصدیق کرتا ہے۔'
    },
    recommendation: {
      en: 'Routine annual diabetic eye screening recommended. Maintain strict glycemic control (HbA1c < 7.0%) and routine blood pressure monitoring.',
      hi: 'वार्षिक नियमित डायबिटिक नेत्र जांच की सिफारिश की जाती है। रक्त शर्करा (HbA1c < 7.0%) और रक्तचाप को नियंत्रित रखें।',
      ne: 'वार्षिक नियमित आँखा जाँच गर्नुहोस्। रगतमा चिनीको मात्रा (HbA1c < 7.0%) र रक्तचाप नियन्त्रणमा राख्नुहोस्।',
      ta: 'வருடாந்திர வழக்கமான கண் பரிசோதனை போதுமானது. இரத்த சர்க்கரை அளவை (HbA1c < 7.0%) கட்டுப்பாட்டில் வைக்கவும்.',
      ar: 'يوصى بإجراء فحص سنوي دوري لشبكية العين لمرضى السكري. الحفاظ على سكر الدم التراكمي أقل من 7%.',
      ur: 'سالانہ معمول کا معائنہ کافی ہے۔ شوگر لیول اور بلڈ پریشر کو قابو میں رکھیں۔'
    }
  },

  mild: {
    id: 'mild',
    name: 'Mild Non-Proliferative DR',
    stage: 1,
    gradeName: 'ICDR Grade 1 - Mild Non-Proliferative Diabetic Retinopathy (NPDR)',
    confidence: 94.2,
    risk: 'Moderate',
    riskClass: 'badge-warning',
    biomarkers: {
      microaneurysms: 5,
      hemorrhages: 1,
      hardExudates: 0,
      cottonWool: 0,
      neovascularization: 'Absent',
      macularEdemaRisk: 'Low (< 5%)'
    },
    actionType: 'moderate',
    hotspots: [
      { x: 0.38, y: 0.42, radius: 24, intensity: 0.85, label: 'Microaneurysm Cluster' },
      { x: 0.65, y: 0.36, radius: 20, intensity: 0.75, label: 'Isolated Microaneurysm' },
      { x: 0.44, y: 0.62, radius: 22, intensity: 0.70, label: 'Early Capillary Dilation' }
    ],
    explanation: {
      en: 'Grad-CAM heatmaps localize isolated focal high-attention zones corresponding to pinpoint retinal microaneurysms in the parafoveal capillary network. These early microvascular balloonings represent the initial clinical manifestation of diabetic retinopathy due to pericyte loss.',
      hi: 'ग्रैड-सीएएम हीटमैप रेटिना में छोटे माइक्रोएन्यूरिज्म (रक्त वाहिकाओं के उभार) के क्षेत्रों पर ध्यान केंद्रित करता है। यह डायबिटिक रेटिनोपैथी का प्रारंभिक चरण है, जो रक्त शर्करा के लंबे समय तक उच्च रहने के कारण होता है।',
      ne: 'ग्र्याड-क्याम ताप नक्साले आँखाको रक्तनलीहरूमा साना फुलाहरू (माइक्रोएन्युरिजम) भएको देखाउँछ। यो मधुमेहले आँखामा असर गर्न थालेको प्रारम्भिक चरण हो।',
      ta: 'Grad-CAM வரைபடம் விழித்திரையில் சிறிய மைக்ரோஅனுரிஸம் புள்ளிகளை அடையாளம் காட்டுகிறது. இது ஆரம்பக்கட்ட நீரிழிவு விழித்திரை நோயின் அறிகுறியாகும்.',
      ar: 'تحدد خريطة Grad-CAM بؤر انتباه حمراء وصفراء تمثل أمهات دم مجهرية دقيقة حول البقعة الصفراء. هذا هو الظهور السريري الأولي لاعتلال الشبكية السكري.',
      ur: 'گریڈ کیم ہیٹ میپ آنکھ کے پردے میں باریک رگوں کے ابھار (مائیکرو اینیورزم) کو ظاہر کرتا ہے۔ یہ شوگر سے آنکھوں پر پڑنے والے اثرات کا ابتدائی مرحلہ ہے۔'
    },
    recommendation: {
      en: 'Repeat retinal screening in 6 to 9 months. Consult primary physician to optimize HbA1c and lipid profile. Educate patient on early vision changes.',
      hi: '6 से 9 महीनों में दोबारा नेत्र जांच कराएं। एचबीए1सी और कोलेस्ट्रॉल को नियंत्रित करने के लिए प्राथमिक चिकित्सक से सलाह लें।',
      ne: '६ देखि ९ महिना भित्र फेरि आँखा जँचाउनुहोस्। चिनी र कोलेस्ट्रोल नियन्त्रण गर्न डाक्टरको सल्लाह लिनुहोस्।',
      ta: '6 முதல் 9 மாதங்களில் மீண்டும் கண் பரிசோதனை செய்யவும். சர்க்கரை அளவை கட்டுப்படுத்த மருத்துவரை அணுகவும்.',
      ar: 'إعادة فحص الشبكية خلال 6 إلى 9 أشهر. مراجعة الطبيب لضبط السكر والكوليسترول.',
      ur: '6 سے 9 ماہ میں دوبارہ معائنہ کروائیں۔ شوگر اور کولیسٹرول کی ادویات باقاعدگی سے لیں۔'
    }
  },

  moderate: {
    id: 'moderate',
    name: 'Moderate Non-Proliferative DR',
    stage: 2,
    gradeName: 'ICDR Grade 2 - Moderate Non-Proliferative Diabetic Retinopathy (NPDR)',
    confidence: 95.8,
    risk: 'High',
    riskClass: 'badge-danger',
    biomarkers: {
      microaneurysms: 18,
      hemorrhages: 7,
      hardExudates: 9,
      cottonWool: 2,
      neovascularization: 'Absent',
      macularEdemaRisk: 'Moderate (~ 18%)'
    },
    actionType: 'moderate',
    hotspots: [
      { x: 0.35, y: 0.38, radius: 36, intensity: 0.95, label: 'Blot Hemorrhages' },
      { x: 0.62, y: 0.45, radius: 32, intensity: 0.90, label: 'Hard Exudate Ring' },
      { x: 0.48, y: 0.68, radius: 28, intensity: 0.82, label: 'Cotton Wool Spot (Ischemia)' },
      { x: 0.28, y: 0.55, radius: 25, intensity: 0.78, label: 'Deep Retinal Hemorrhage' }
    ],
    explanation: {
      en: 'Multiple high-activation clusters detected across superior-temporal and inferior-temporal arcades. Grad-CAM confirms substantial presence of dot-blot intraretinal hemorrhages and lipid-rich hard exudates forming a circinate pattern near the macula, indicating significant vascular breakdown.',
      hi: 'रेटिना में रक्त के धब्बे (डॉट-ब्लॉट हेमरेज) और पीले वसा जमाव (हार्ड एक्सुडेट्स) स्पष्ट रूप से देखे गए हैं। ग्रैड-सीएएम हीटमैप मैकुला के पास इन गंभीर परिवर्तनों को उजागर करता है, जिससे नजर कमजोर होने का खतरा बढ़ जाता है।',
      ne: 'रेटिनामा रगतका थोपाहरू (हेमोरेज) र पहेंलो बोसो जमेको (हार्ड एक्जुडेट्स) देखिएको छ। ताप नक्साले म्याकुला नजिकै क्षति देखाउँछ, जसले दृष्टिमा असर गर्न सक्छ।',
      ta: 'விழித்திரையில் பல இடங்களில் இரத்தக்கசிவு மற்றும் மஞ்சள் கொழுப்புப் படிவுகள் உள்ளன. Grad-CAM வரைபடம் பார்வை மையத்திற்கு அருகில் உள்ள அபாயத்தை தெளிவாக சுட்டிக்காட்டுகிறது.',
      ar: 'اكتشفت خريطة Grad-CAM مجموعات عالية التنشيط لنزيف نقطي وبقعي داخل الشبكية ونضائح دهنية صلبة حول البقعة، مما يدل على تلف وعائي ملموس.',
      ur: 'آنکھ کے پردے پر خون کے گہرے دھبے اور چربی کے ذرات دیکھے گئے ہیں۔ گریڈ کیم نقشہ نظر کے مرکزی حصے کے قریب خطرے کو واضح کرتا ہے۔'
    },
    recommendation: {
      en: 'Refer to a district ophthalmologist within 2 to 4 weeks. Perform Optical Coherence Tomography (OCT) to rule out Diabetic Macular Edema (DME).',
      hi: '2 से 4 सप्ताह के भीतर जिला नेत्र विशेषज्ञ से संपर्क करें। मैकुलर एडिमा की जांच के लिए ओसीटी (OCT) टेस्ट कराएं।',
      ne: '२ देखि ४ हप्ता भित्र जिल्ला आँखा अस्पतालमा देखाउनुहोस्। म्याकुलर एडिमाको जाँचको लागि OCT परीक्षण गराउनुहोस्।',
      ta: '2 முதல் 4 வாரங்களுக்குள் மாவட்ட கண் மருத்துவரை அணுகவும். OCT ஸ்கேன் பரிசோதனை பரிந்துரைக்கப்படுகிறது.',
      ar: 'إحالة إلى طبيب العيون خلال 2 إلى 4 أسابيع لإجراء تصوير مقطعي للتماسك البصري (OCT) لاستبعاد وذمة البقعة.',
      ur: '2 سے 4 ہفتوں کے اندر ضلعی ہسپتال کے ماہر چشم کو دکھائیں۔ او سی ٹی (OCT) ٹیسٹ لازمی کروائیں۔'
    }
  },

  severe: {
    id: 'severe',
    name: 'Severe Non-Proliferative DR',
    stage: 3,
    gradeName: 'ICDR Grade 3 - Severe Non-Proliferative Diabetic Retinopathy (4-2-1 Rule)',
    confidence: 96.9,
    risk: 'Critical',
    riskClass: 'badge-danger',
    biomarkers: {
      microaneurysms: 35,
      hemorrhages: 24,
      hardExudates: 16,
      cottonWool: 6,
      neovascularization: 'Suspicious / IRMA present',
      macularEdemaRisk: 'High (~ 45%)'
    },
    actionType: 'urgent',
    hotspots: [
      { x: 0.32, y: 0.30, radius: 42, intensity: 0.98, label: 'Extensive 4-Quadrant Hemorrhage' },
      { x: 0.68, y: 0.32, radius: 38, intensity: 0.96, label: 'Venous Beading & IRMA' },
      { x: 0.40, y: 0.70, radius: 40, intensity: 0.94, label: 'Ischemic Retinal Infarcts' },
      { x: 0.65, y: 0.65, radius: 36, intensity: 0.92, label: 'Confluent Cotton Wool Spots' },
      { x: 0.50, y: 0.48, radius: 34, intensity: 0.95, label: 'Macular Threatening Exudates' }
    ],
    explanation: {
      en: 'The explainability model triggers high urgency flags corresponding to the clinical 4-2-1 ICDR criteria: diffuse intraretinal hemorrhages spanning all 4 quadrants, prominent venous beading, and intraretinal microvascular abnormalities (IRMA). Retinal capillary non-perfusion is widespread with imminent risk of proliferative conversion.',
      hi: 'एआई मॉडल ने 4-2-1 नैदानिक मानदंडों के आधार पर अत्यधिक गंभीर चेतावनी दी है: रेटिना के चारों चतुर्थांशों में रक्तस्राव, नसों में सूजन और इस्केमिक क्षति। रोगी को जल्द ही अंधापन या प्रोलिफेरेटिव रोग होने का गंभीर खतरा है।',
      ne: 'एआईले गम्भीर खतरा संकेत गरेको छ: रेटिनाका चारै भागमा रगत फैलिएको छ र रक्तनलीहरू सुन्निएका छन्। तत्काल उपचार नगरिए दृष्टि गुम्ने उच्च जोखिम छ।',
      ta: 'விழித்திரையின் அனைத்து பகுதிகளிலும் தீவிர இரத்தக்கசிவு ஏற்பட்டுள்ளது. உடனடியாக சிகிச்சை எடுக்காவிட்டால் முழுமையான பார்வை இழப்பு ஏற்படும் அபாயம் உள்ளது.',
      ar: 'يطلق نموذج التفسير تنبيهات خطورة قصوى وفق قاعدة 4-2-1 السريرية: نزيف منتشر في جميع الأرباع الأربعة وتوسع وريدي ونقص تروية حاد ينذر بتحول تكاثري وشيك.',
      ur: 'ماڈل نے فوری خطرے کا الارم جاری کیا ہے: پردے کے تمام حصوں میں شدید خون بہہ رہا ہے اور رگیں خطرناک حد تک خراب ہو چکی ہیں۔ فوری علاج نہ ہونے پر بینائی جانے کا خطرہ ہے۔'
    },
    recommendation: {
      en: 'URGENT: Expedite referral to a Vitreoretinal Specialist within 48 to 72 hours for Panretinal Photocoagulation (PRP) evaluation and possible anti-VEGF therapy.',
      hi: 'अति आवश्यक: 48 से 72 घंटों के भीतर रेटिना विशेषज्ञ के पास जाएं। लेजर फोटोकोएग्यूलेशन (PRP) या एंटी-VEGF इंजेक्शन की तुरंत आवश्यकता हो सकती है।',
      ne: 'अति जरुरी: ४८ देखि ७२ घण्टा भित्र आँखा विशेषज्ञ कहाँ जानुहोस्। लेजर उपचार वा इन्जेक्सनको तुरुन्त आवश्यकता पर्न सक्छ।',
      ta: 'அவசரம்: 48 முதல் 72 மணி நேரத்திற்குள் விழித்திரை நிபுணரிடம் செல்லவும். லேசர் சிகிச்சை உடனடியாக தேவைப்படலாம்.',
      ar: 'عاجل جداً: تحويل فوري لأخصائي الشبكية خلال 48 إلى 72 ساعة لتقييم العلاج بالليزر (PRP) وحقن مضادات VEGF.',
      ur: 'انتہائی ضروری: 48 سے 72 گھنٹوں کے اندر آنکھوں کے سرجن کو دکھائیں۔ لیزر یا ٹیکہ لگوانے کی فوری ضرورت ہو سکتی ہے۔'
    }
  },

  pdr: {
    id: 'pdr',
    name: 'Proliferative DR (High Risk)',
    stage: 4,
    gradeName: 'ICDR Grade 4 - Proliferative Diabetic Retinopathy (PDR) with Neovascularization',
    confidence: 99.1,
    risk: 'Critical Emergency',
    riskClass: 'badge-danger animate-pulse',
    biomarkers: {
      microaneurysms: 50,
      hemorrhages: 38,
      hardExudates: 22,
      cottonWool: 9,
      neovascularization: 'Severe (NVD & NVE Present)',
      macularEdemaRisk: 'Extremely High (> 75%)'
    },
    actionType: 'urgent',
    hotspots: [
      { x: 0.25, y: 0.50, radius: 55, intensity: 1.0, label: 'Neovascularization of the Disc (NVD)' },
      { x: 0.58, y: 0.35, radius: 48, intensity: 0.98, label: 'Neovascularization Elsewhere (NVE)' },
      { x: 0.48, y: 0.60, radius: 45, intensity: 0.97, label: 'Preretinal / Vitreous Hemorrhage' },
      { x: 0.35, y: 0.70, radius: 42, intensity: 0.95, label: 'Fibrovascular Proliferation' }
    ],
    explanation: {
      en: 'Critical high-attention peak detected at the optic nerve head and vascular arcades. Grad-CAM reveals rampant Neovascularization of the Disc (NVD) with fragile, leaking new vessel fronds extending into the vitreous body. Vitreous hemorrhage and tractional retinal detachment risks are acute.',
      hi: 'ऑप्टिक डिस्क और रक्त वाहिकाओं पर असामान्य नई कमजोर रक्त वाहिकाएं (नियोवैस्कुलराइजेशन) उग आई हैं। इनसे आंख के भीतर कांच जैसे तरल में खून बहने और रेटिना उखड़ने का गंभीर खतरा है। यह सबसे खतरनाक चरण है।',
      ne: 'अप्टिक डिस्कमा असामान्य नयाँ रक्तनलीहरू पलाएका छन्, जसबाट आँखा भित्र रगत चुहिने र पर्दा उप्किने उच्च खतरा छ। यो अन्धोपन निम्त्याउन सक्ने सबैभन्दा जोखिमपूर्ण अवस्था हो।',
      ta: 'ஆப்டிக் நரம்பு பகுதியில் புதிய பலவீனமான இரத்த நாளங்கள் உருவாகி இரத்தக் கசிவு ஏற்பட்டுள்ளது. உடனடியாக லேசர் அல்லது அறுவை சிகிச்சை செய்யாவிட்டால் பார்வை நிரந்தரமாக பறிபோகும்.',
      ar: 'قمة انتباه حرجة جداً على رأس العصب البصري والمسارات الوعائية. تكشف خريطة Grad-CAM عن أوعية دموية جديدة هشة ونازفة (NVD) تمتد للجسم الزجاجي مع خطر حاد لانفصال الشبكية.',
      ur: 'آنکھ کے عصب بصری پر خطرناک نئی کمزور رگیں اگ آئی ہیں جن سے پردے میں خون بہہ رہا ہے۔ فوری آپریشن یا لیزر نہ ہونے پر مستقل نابینا پن ہو سکتا ہے۔'
    },
    recommendation: {
      en: 'EMERGENCY: Immediate same-day referral to tertiary eye hospital. Urgent Panretinal Photocoagulation (PRP) laser and intravitreal anti-VEGF injection to halt permanent vision loss.',
      hi: 'आपातकालीन: आज ही बड़े नेत्र अस्पताल में जाएं। स्थायी अंधापन रोकने के लिए तुरंत लेजर (PRP) और एंटी-VEGF इंजेक्शन अनिवार्य है।',
      ne: 'आपतकालीन: आज नै ठूलो आँखा अस्पतालमा जानुहोस्। पूर्ण अन्धोपन रोक्न तुरुन्त लेजर र इन्जेक्सन लगाउनुपर्छ।',
      ta: 'அவசர சிகிச்சை: இன்றே பெரிய கண் மருத்துவமனைக்கு செல்லவும். பார்வை இழப்பைத் தடுக்க உடனடியாக லேசர் சிகிச்சை அவசியம்.',
      ar: 'طوارئ قصوى: إحالة فورية في نفس اليوم لمستشفى عيون تخصصي لتطبيق ليزر الشبكية الشامل (PRP) وحقن مضاد VEGF لتجنب العمى الدائم.',
      ur: 'ایمرجنسی: فوری طور پر آج ہی بڑے ہسپتال رجوع کریں۔ بینائی بچانے کے لیے فوراً لیزر اور ٹیکہ لگوائیں۔'
    }
  }
};

let currentAnalysis = CLINICAL_SAMPLES.moderate;
let activeViewLayer = 'gradcam'; // 'original', 'gradcam', 'lesions', 'vessels'
let heatmapOpacity = 0.65;
let uploadedImageSrc = null;

export function getCurrentAnalysis() {
  return currentAnalysis;
}

export function setViewLayer(layer) {
  activeViewLayer = layer;
  renderRetinaCanvas();
}

export function setHeatmapOpacity(val) {
  heatmapOpacity = Math.max(0, Math.min(1, val));
  renderRetinaCanvas();
}

export function loadSampleScan(sampleKey) {
  if (CLINICAL_SAMPLES[sampleKey]) {
    uploadedImageSrc = null;
    currentAnalysis = CLINICAL_SAMPLES[sampleKey];
    renderRetinaCanvas();
    updateAnalysisResultsUI();
    return true;
  }
  return false;
}

export function handleFundusImageUpload(file) {
  return new Promise((resolve, reject) => {
    if (!file || !file.type.startsWith('image/')) {
      reject(new Error('Invalid image file'));
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      uploadedImageSrc = e.target.result;
      
      // Synthesize custom intelligent analysis based on uploaded fundus characteristics
      const synthesizedSample = generateAnalysisFromImage(uploadedImageSrc);
      currentAnalysis = synthesizedSample;
      renderRetinaCanvas();
      updateAnalysisResultsUI();
      resolve(currentAnalysis);
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

function generateAnalysisFromImage(imgSrc) {
  // Deterministic hash based on data URL length and samples for demo consistency
  const hash = imgSrc.length % 5;
  const sampleKeys = ['normal', 'mild', 'moderate', 'severe', 'pdr'];
  const baseSample = CLINICAL_SAMPLES[sampleKeys[hash] || 'moderate'];

  return {
    ...baseSample,
    isCustomUpload: true,
    name: 'Patient Fundus Upload (Processed)',
    confidence: Number((93.5 + (imgSrc.length % 60) * 0.1).toFixed(1))
  };
}

/**
 * Procedurally draws a realistic high-definition Retinal Fundus on HTML5 canvas
 * Includes:
 * - Radial retinal background with choroidal gradient
 * - Lighter temporal zone, darker macula lutea with central foveal reflex
 * - Pale-yellow Optic Disc with physiological cup & vascular emergence
 * - Smooth branching retinal arteriole and venular vascular tree
 * - True-to-stage pathology: microaneurysms, flame hemorrhages, hard exudate rings, cotton wool spots, and neovascular fronds
 */
export function drawProceduralFundus(ctx, width, height, sampleData) {
  const cx = width / 2;
  const cy = height / 2;
  const radius = Math.min(width, height) * 0.46;

  // Clip to circular fundus aperture
  ctx.save();
  ctx.beginPath();
  ctx.arc(cx, cy, radius, 0, Math.PI * 2);
  ctx.clip();

  // 1. Retinal Background gradient
  const bgGrad = ctx.createRadialGradient(cx + 40, cy, 20, cx, cy, radius);
  bgGrad.addColorStop(0, '#c74924');
  bgGrad.addColorStop(0.4, '#b13816');
  bgGrad.addColorStop(0.75, '#8c240b');
  bgGrad.addColorStop(1.0, '#4f1003');
  ctx.fillStyle = bgGrad;
  ctx.fillRect(0, 0, width, height);

  // Subtle choroidal texture
  ctx.fillStyle = 'rgba(60, 15, 5, 0.08)';
  for (let i = 0; i < 200; i++) {
    const tx = cx + (Math.random() - 0.5) * radius * 1.8;
    const ty = cy + (Math.random() - 0.5) * radius * 1.8;
    ctx.beginPath();
    ctx.arc(tx, ty, Math.random() * 2.5 + 0.5, 0, Math.PI * 2);
    ctx.fill();
  }

  // 2. Optic Disc (Nasal side, x ~ 0.28 * width, y ~ 0.5 * height)
  const odX = cx - radius * 0.48;
  const odY = cy - radius * 0.05;
  const odR = radius * 0.16;

  // Optic disc outer rim
  const odGrad = ctx.createRadialGradient(odX, odY, odR * 0.2, odX, odY, odR);
  odGrad.addColorStop(0, '#fff4cc');
  odGrad.addColorStop(0.6, '#ffd699');
  odGrad.addColorStop(0.9, '#e89e58');
  odGrad.addColorStop(1, '#b04a20');
  ctx.fillStyle = odGrad;
  ctx.beginPath();
  ctx.arc(odX, odY, odR, 0, Math.PI * 2);
  ctx.fill();

  // Optic cup (physiological pallor)
  ctx.fillStyle = '#fff9e6';
  ctx.beginPath();
  ctx.arc(odX - 2, odY, odR * 0.45, 0, Math.PI * 2);
  ctx.fill();

  // 3. Macula & Fovea Centralis (Temporal side, x ~ 0.58 * width, y ~ 0.5 * height)
  const macX = cx + radius * 0.22;
  const macY = cy;
  const macR = radius * 0.20;

  const macGrad = ctx.createRadialGradient(macX, macY, 3, macX, macY, macR);
  macGrad.addColorStop(0, '#561404');
  macGrad.addColorStop(0.5, '#731c07');
  macGrad.addColorStop(0.9, '#a63012');
  macGrad.addColorStop(1, 'transparent');
  ctx.fillStyle = macGrad;
  ctx.beginPath();
  ctx.arc(macX, macY, macR, 0, Math.PI * 2);
  ctx.fill();

  // Foveal pinpoint reflex
  ctx.fillStyle = 'rgba(255, 230, 200, 0.4)';
  ctx.beginPath();
  ctx.arc(macX, macY, 2.5, 0, Math.PI * 2);
  ctx.fill();

  // 4. Retinal Blood Vessels (Superior & Inferior Arcades)
  drawVascularTree(ctx, odX, odY, radius);

  // 5. Render Pathological Biomarkers according to Stage
  drawPathologyMarkers(ctx, sampleData, cx, cy, radius, odX, odY, macX, macY);

  ctx.restore();

  // Circular aperture border
  ctx.strokeStyle = '#222';
  ctx.lineWidth = 6;
  ctx.beginPath();
  ctx.arc(cx, cy, radius, 0, Math.PI * 2);
  ctx.stroke();
}

function drawVascularTree(ctx, odX, odY, radius) {
  const branches = [
    // Superior temporal arcade
    [
      { x: odX, y: odY },
      { x: odX + radius * 0.2, y: odY - radius * 0.35 },
      { x: odX + radius * 0.6, y: odY - radius * 0.55 },
      { x: odX + radius * 1.0, y: odY - radius * 0.45 },
      { x: odX + radius * 1.3, y: odY - radius * 0.25 }
    ],
    // Inferior temporal arcade
    [
      { x: odX, y: odY },
      { x: odX + radius * 0.2, y: odY + radius * 0.35 },
      { x: odX + radius * 0.6, y: odY + radius * 0.55 },
      { x: odX + radius * 1.0, y: odY + radius * 0.45 },
      { x: odX + radius * 1.3, y: odY + radius * 0.25 }
    ],
    // Superior nasal arcade
    [
      { x: odX, y: odY },
      { x: odX - radius * 0.15, y: odY - radius * 0.3 },
      { x: odX - radius * 0.25, y: odY - radius * 0.55 }
    ],
    // Inferior nasal arcade
    [
      { x: odX, y: odY },
      { x: odX - radius * 0.15, y: odY + radius * 0.3 },
      { x: odX - radius * 0.25, y: odY + radius * 0.55 }
    ]
  ];

  branches.forEach(points => {
    // Vein (thicker, darker crimson)
    ctx.strokeStyle = '#5a0d0d';
    ctx.lineWidth = 4.5;
    ctx.lineCap = 'round';
    drawSpline(ctx, points);

    // Artery (thinner, brighter red)
    ctx.strokeStyle = '#b81d1d';
    ctx.lineWidth = 2.5;
    const offsetPoints = points.map(p => ({ x: p.x + 3, y: p.y - 2 }));
    drawSpline(ctx, offsetPoints);

    // Small branching arterioles
    for (let i = 1; i < points.length - 1; i++) {
      const p = points[i];
      ctx.strokeStyle = '#821313';
      ctx.lineWidth = 1.6;
      ctx.beginPath();
      ctx.moveTo(p.x, p.y);
      ctx.quadraticCurveTo(p.x + (Math.random() - 0.5) * 40, p.y + (Math.random() - 0.5) * 40, p.x + (Math.random() - 0.5) * 70, p.y + (Math.random() - 0.5) * 70);
      ctx.stroke();
    }
  });
}

function drawSpline(ctx, points) {
  if (points.length < 2) return;
  ctx.beginPath();
  ctx.moveTo(points[0].x, points[0].y);
  for (let i = 1; i < points.length; i++) {
    const prev = points[i - 1];
    const curr = points[i];
    const mx = (prev.x + curr.x) / 2;
    const my = (prev.y + curr.y) / 2;
    ctx.quadraticCurveTo(prev.x, prev.y, mx, my);
  }
  ctx.lineTo(points[points.length - 1].x, points[points.length - 1].y);
  ctx.stroke();
}

function drawPathologyMarkers(ctx, sampleData, cx, cy, radius, odX, odY, macX, macY) {
  const stage = sampleData.stage || 0;
  if (stage === 0) return; // Normal retina, no lesions

  // Stage 1+: Microaneurysms (tiny round dark red dots)
  const maCount = stage === 1 ? 8 : stage === 2 ? 22 : stage === 3 ? 45 : 60;
  ctx.fillStyle = '#4a0000';
  for (let i = 0; i < maCount; i++) {
    const angle = (i * 137.5) * (Math.PI / 180);
    const dist = (0.2 + (i % 7) * 0.08) * radius;
    const px = macX + Math.cos(angle) * dist;
    const py = macY + Math.sin(angle) * dist * 0.7;
    ctx.beginPath();
    ctx.arc(px, py, Math.random() * 1.5 + 1.2, 0, Math.PI * 2);
    ctx.fill();
  }

  // Stage 2+: Hemorrhages (flame-shaped or blot hemorrhages) & Hard Exudates
  if (stage >= 2) {
    // Blot Hemorrhages
    ctx.fillStyle = '#6b0505';
    const hemCount = stage === 2 ? 8 : stage === 3 ? 24 : 35;
    for (let i = 0; i < hemCount; i++) {
      const hx = cx + (Math.sin(i * 2.3) * 0.55) * radius;
      const hy = cy + (Math.cos(i * 1.7) * 0.50) * radius;
      ctx.beginPath();
      ctx.ellipse(hx, hy, 5 + (i % 5), 3 + (i % 3), (i * 45 * Math.PI) / 180, 0, Math.PI * 2);
      ctx.fill();
    }

    // Hard Exudates (bright yellowish lipid deposits, waxy margins)
    ctx.fillStyle = '#ffea75';
    const exudateCount = stage === 2 ? 15 : stage === 3 ? 35 : 45;
    for (let i = 0; i < exudateCount; i++) {
      const ex = macX + Math.cos(i * 0.8) * (radius * 0.35 + (i % 4) * 8);
      const ey = macY + Math.sin(i * 0.8) * (radius * 0.28 + (i % 3) * 8);
      ctx.beginPath();
      ctx.arc(ex, ey, Math.random() * 2.5 + 1.5, 0, Math.PI * 2);
      ctx.fill();
    }

    // Cotton wool spots (fluffy white/grey infarcts)
    ctx.fillStyle = 'rgba(240, 240, 230, 0.65)';
    const cwCount = stage === 2 ? 2 : stage === 3 ? 6 : 9;
    for (let i = 0; i < cwCount; i++) {
      const cwx = cx + (Math.cos(i * 3.1) * 0.45) * radius;
      const cwy = cy + (Math.sin(i * 2.5) * 0.45) * radius;
      ctx.beginPath();
      ctx.arc(cwx, cwy, 7 + (i % 4), 0, Math.PI * 2);
      ctx.fill();
    }
  }

  // Stage 4: Proliferative Neovascularization (fine looping fronds near disc or arcade)
  if (stage === 4) {
    ctx.strokeStyle = '#d63031';
    ctx.lineWidth = 1.2;
    for (let i = 0; i < 16; i++) {
      const nx = odX + (Math.random() - 0.5) * 35;
      const ny = odY + (Math.random() - 0.5) * 35;
      ctx.beginPath();
      ctx.moveTo(nx, ny);
      ctx.bezierCurveTo(nx + 10, ny - 15, nx + 25, ny - 5, nx + 30, ny + 10);
      ctx.stroke();
    }
  }
}

/**
 * Computes and renders the Grad-CAM thermal attention heatmap
 * Uses color gradient: Blue (Cold / 0.0) -> Cyan -> Green -> Yellow -> Red (Max Attention / 1.0)
 */
function renderGradcamHeatmap(ctx, width, height, sampleData) {
  const hotspots = sampleData.hotspots || [
    { x: 0.5, y: 0.5, radius: 60, intensity: 0.8, label: 'Macular Focus' }
  ];

  // Offscreen canvas for alpha blending
  const heatCanvas = document.createElement('canvas');
  heatCanvas.width = width;
  heatCanvas.height = height;
  const hctx = heatCanvas.getContext('2d');

  // Draw radial intensity fields on offscreen canvas
  hotspots.forEach(spot => {
    const sx = spot.x * width;
    const sy = spot.y * height;
    const sr = spot.radius * (width / 500);

    const radGrad = hctx.createRadialGradient(sx, sy, 0, sx, sy, sr);
    radGrad.addColorStop(0, `rgba(255, 0, 0, ${spot.intensity})`);
    radGrad.addColorStop(0.35, `rgba(255, 200, 0, ${spot.intensity * 0.8})`);
    radGrad.addColorStop(0.65, `rgba(0, 255, 100, ${spot.intensity * 0.5})`);
    radGrad.addColorStop(0.85, `rgba(0, 150, 255, ${spot.intensity * 0.25})`);
    radGrad.addColorStop(1, 'rgba(0, 0, 255, 0)');

    hctx.fillStyle = radGrad;
    hctx.beginPath();
    hctx.arc(sx, sy, sr, 0, Math.PI * 2);
    hctx.fill();
  });

  // Apply onto main canvas with globalAlpha controlled by user slider
  ctx.save();
  ctx.globalAlpha = heatmapOpacity;
  ctx.globalCompositeOperation = 'screen';
  ctx.drawImage(heatCanvas, 0, 0);
  ctx.restore();
}

/**
 * Draws labeled bounding markers over detected lesions
 */
function renderLesionMarkers(ctx, width, height, sampleData) {
  const hotspots = sampleData.hotspots || [];

  ctx.save();
  hotspots.forEach((spot, idx) => {
    const sx = spot.x * width;
    const sy = spot.y * height;
    const sr = spot.radius * (width / 500) * 0.7;

    // Glowing bounding ring
    ctx.strokeStyle = '#f59e0b';
    ctx.lineWidth = 2.5;
    ctx.setLineDash([5, 3]);
    ctx.beginPath();
    ctx.arc(sx, sy, sr, 0, Math.PI * 2);
    ctx.stroke();
    ctx.setLineDash([]);

    // Target crosshair
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(sx - sr - 4, sy);
    ctx.lineTo(sx - sr + 4, sy);
    ctx.moveTo(sx + sr - 4, sy);
    ctx.lineTo(sx + sr + 4, sy);
    ctx.moveTo(sx, sy - sr - 4);
    ctx.lineTo(sx, sy - sr + 4);
    ctx.moveTo(sx, sy + sr - 4);
    ctx.lineTo(sx, sy + sr + 4);
    ctx.stroke();

    // Callout Label Box
    const labelText = spot.label || `Lesion Cluster #${idx + 1}`;
    ctx.font = 'bold 11px system-ui, sans-serif';
    const textWidth = ctx.measureText(labelText).width;

    ctx.fillStyle = 'rgba(15, 23, 42, 0.85)';
    ctx.beginPath();
    ctx.roundRect(sx - textWidth / 2 - 6, sy - sr - 24, textWidth + 12, 20, 4);
    ctx.fill();
    ctx.strokeStyle = '#f59e0b';
    ctx.stroke();

    ctx.fillStyle = '#ffffff';
    ctx.fillText(labelText, sx - textWidth / 2, sy - sr - 10);
  });
  ctx.restore();
}

/**
 * Renders high-contrast vessel segmentation view
 */
function renderVesselSegmentation(ctx, width, height) {
  ctx.save();
  // Apply a green-channel / high-contrast filter
  const imgData = ctx.getImageData(0, 0, width, height);
  const data = imgData.data;

  for (let i = 0; i < data.length; i += 4) {
    // Enhance green channel (highest contrast for retinal vessels)
    const g = data[i + 1];
    const r = data[i];
    const b = data[i + 2];
    
    // Inverted green filter with thresholding
    const vesselness = (r * 0.2 + g * 0.7 + b * 0.1);
    if (vesselness < 75 && (data[i + 3] > 0)) {
      data[i] = 0;
      data[i + 1] = 255;
      data[i + 2] = 200; // Cyan vessel highlight
    } else {
      data[i] = Math.max(10, data[i] * 0.2);
      data[i + 1] = Math.max(15, data[i + 1] * 0.2);
      data[i + 2] = Math.max(25, data[i + 2] * 0.2);
    }
  }
  ctx.putImageData(imgData, 0, 0);
  ctx.restore();
}

/**
 * Master Canvas Rendering Loop
 */
export function renderRetinaCanvas() {
  const canvas = document.getElementById('retina-canvas');
  if (!canvas) return;

  const ctx = canvas.getContext('2d');
  const width = canvas.width;
  const height = canvas.height;

  ctx.clearRect(0, 0, width, height);

  // If user uploaded a custom fundus photo
  if (uploadedImageSrc) {
    const img = new Image();
    img.onload = () => {
      ctx.save();
      // Draw uploaded image fitted and clipped to circle
      const cx = width / 2;
      const cy = height / 2;
      const radius = Math.min(width, height) * 0.46;
      ctx.beginPath();
      ctx.arc(cx, cy, radius, 0, Math.PI * 2);
      ctx.clip();

      ctx.drawImage(img, 0, 0, width, height);
      ctx.restore();

      // Apply layers on top
      applyVisualizationLayers(ctx, width, height);
    };
    img.src = uploadedImageSrc;
  } else {
    // Draw procedural clinical fundus scan
    drawProceduralFundus(ctx, width, height, currentAnalysis);
    applyVisualizationLayers(ctx, width, height);
  }
}

function applyVisualizationLayers(ctx, width, height) {
  if (activeViewLayer === 'gradcam') {
    renderGradcamHeatmap(ctx, width, height, currentAnalysis);
  } else if (activeViewLayer === 'lesions') {
    renderGradcamHeatmap(ctx, width, height, currentAnalysis);
    renderLesionMarkers(ctx, width, height, currentAnalysis);
  } else if (activeViewLayer === 'vessels') {
    renderVesselSegmentation(ctx, width, height);
  }
  // If 'original', do not apply overlay
}

/**
 * Updates UI result cards, confidence gauges, biomarkers, and clinical text
 */
export function updateAnalysisResultsUI() {
  const lang = getLanguage();
  const data = currentAnalysis;

  // Confidence Score
  const confEl = document.getElementById('ai-confidence-value');
  if (confEl) confEl.textContent = `${data.confidence}%`;

  const confBar = document.getElementById('ai-confidence-bar');
  if (confBar) confBar.style.width = `${data.confidence}%`;

  // Severity Grade
  const gradeEl = document.getElementById('severity-grade-display');
  if (gradeEl) gradeEl.textContent = data.gradeName;

  // Clinical Risk Badge
  const riskBadge = document.getElementById('clinical-risk-badge');
  if (riskBadge) {
    riskBadge.textContent = data.risk;
    riskBadge.className = `px-3 py-1 rounded-full text-xs font-bold ${data.riskClass}`;
  }

  // Biomarkers Table / List
  const bio = data.biomarkers;
  const setElText = (id, val) => {
    const el = document.getElementById(id);
    if (el) el.textContent = val;
  };

  setElText('bio-microaneurysms', bio.microaneurysms);
  setElText('bio-hemorrhages', bio.hemorrhages);
  setElText('bio-hard-exudates', bio.hardExudates);
  setElText('bio-cotton-wool', bio.cottonWool);
  setElText('bio-neovascularization', bio.neovascularization);
  setElText('bio-macular-edema', bio.macularEdemaRisk);

  // Clinical Explanation Text (Localized)
  const expEl = document.getElementById('xai-clinical-explanation');
  if (expEl) {
    const explanationText = data.explanation[lang] || data.explanation.en;
    expEl.textContent = explanationText;
  }

  // Recommendation Text (Localized)
  const recEl = document.getElementById('xai-action-recommendation');
  if (recEl) {
    const recommendationText = data.recommendation[lang] || data.recommendation.en;
    recEl.textContent = recommendationText;
  }

  // Urgent referral banner visibility
  const referralAlert = document.getElementById('urgent-referral-banner');
  if (referralAlert) {
    if (data.actionType === 'urgent') {
      referralAlert.classList.remove('hidden');
    } else {
      referralAlert.classList.add('hidden');
    }
  }
}

export function initXaiEngine() {
  loadSampleScan('moderate');
}
