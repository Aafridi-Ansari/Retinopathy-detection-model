/**
 * app.js - Main Application Orchestrator for RetinaXAI
 * Initializes themes, localization, XAI engine, medicine tracker,
 * voice assistant, emergency hospital directory, and patient profile records.
 */

import { initLanguage, setLanguage, getLanguage, applyLanguageToDOM, t, LANGUAGES } from './i18n.js';
import { 
  initXaiEngine, 
  loadSampleScan, 
  handleFundusImageUpload, 
  setViewLayer, 
  setHeatmapOpacity, 
  getCurrentAnalysis,
  renderRetinaCanvas,
  updateAnalysisResultsUI
} from './xai_engine.js';
import { 
  initMedicineTracker, 
  addMedicine, 
  removeMedicine, 
  toggleDoseTaken, 
  renderMedicineList 
} from './medicine_tracker.js';
import { 
  initHospitalDirectory, 
  setSelectedCountry, 
  getSelectedCountry, 
  COUNTRY_DATA 
} from './hospital_data.js';
import { 
  initVoiceAssistant, 
  toggleVoiceListening, 
  handleUserChatMessage, 
  renderBotGreeting,
  speakText
} from './voice_assistant.js';

// Global window bindings for inline HTML handlers
window.removeMedicineItem = (id) => removeMedicine(id);
window.toggleMedicineDose = (id, slot) => toggleDoseTaken(id, slot);

// Default patient profile record
const DEFAULT_PATIENT_PROFILE = {
  fullName: 'Rameshwar Devi',
  age: '54',
  gender: 'female',
  diabetesType: 'type2',
  durationYears: '9',
  hba1c: '9.2',
  bloodPressure: '142/90',
  healthWorkerId: 'ASHA-UP-VNS-042',
  districtVillage: 'Pindra PHC, Varanasi, Uttar Pradesh',
  phone: '+91 98765 43210'
};

document.addEventListener('DOMContentLoaded', () => {
  initTheme();
  initLanguage();
  initHospitalDirectory();
  initPatientProfile();
  initMedicineTracker();
  initXaiEngine();
  initVoiceAssistant();
  bindUIEvents();
  renderRetinaCanvas();
});

/* -------------------------------------------------------------------------- */
/* THEME MANAGEMENT (Dark / Light Mode)                                      */
/* -------------------------------------------------------------------------- */
function initTheme() {
  const savedTheme = localStorage.getItem('retinaxai_theme') || 'light';
  applyTheme(savedTheme);

  const themeToggleBtn = document.getElementById('theme-toggle-btn');
  if (themeToggleBtn) {
    themeToggleBtn.addEventListener('click', () => {
      const current = document.documentElement.getAttribute('data-theme') || 'light';
      const nextTheme = current === 'dark' ? 'light' : 'dark';
      applyTheme(nextTheme);
    });
  }
}

function applyTheme(theme) {
  document.documentElement.setAttribute('data-theme', theme);
  localStorage.setItem('retinaxai_theme', theme);

  const icon = document.getElementById('theme-toggle-icon');
  const text = document.getElementById('theme-toggle-text');

  if (icon) {
    icon.className = theme === 'dark' ? 'fa-solid fa-sun text-warning' : 'fa-solid fa-moon text-indigo-500';
  }
  if (text) {
    text.textContent = theme === 'dark' ? t('lightMode') : t('darkMode');
  }

  // Redraw canvas with theme updates if needed
  renderRetinaCanvas();
}

/* -------------------------------------------------------------------------- */
/* TAB NAVIGATION                                                             */
/* -------------------------------------------------------------------------- */
function setupTabNavigation() {
  const tabButtons = document.querySelectorAll('.nav-tab-btn');
  const tabPanels = document.querySelectorAll('.tab-panel');

  tabButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      const targetId = btn.getAttribute('data-tab');

      tabButtons.forEach(b => b.classList.remove('active'));
      tabPanels.forEach(p => p.classList.add('hidden'));

      btn.classList.add('active');
      const activePanel = document.getElementById(targetId);
      if (activePanel) {
        activePanel.classList.remove('hidden');
      }

      // If switching to screening tab, ensure canvas re-renders properly
      if (targetId === 'panel-screening') {
        setTimeout(() => renderRetinaCanvas(), 50);
      }
    });
  });
}

/* -------------------------------------------------------------------------- */
/* PATIENT PROFILE MANAGEMENT                                                 */
/* -------------------------------------------------------------------------- */
function initPatientProfile() {
  const savedProfile = localStorage.getItem('retinaxai_patient_profile');
  let profile = DEFAULT_PATIENT_PROFILE;

  if (savedProfile) {
    try {
      profile = { ...DEFAULT_PATIENT_PROFILE, ...JSON.parse(savedProfile) };
    } catch (e) {
      profile = DEFAULT_PATIENT_PROFILE;
    }
  }

  // Populate Profile Form fields
  const setVal = (id, val) => {
    const el = document.getElementById(id);
    if (el) el.value = val || '';
  };

  setVal('profile-fullname', profile.fullName);
  setVal('profile-age', profile.age);
  setVal('profile-gender', profile.gender);
  setVal('profile-diabetes-type', profile.diabetesType);
  setVal('profile-duration', profile.durationYears);
  setVal('profile-hba1c', profile.hba1c);
  setVal('profile-bp', profile.bloodPressure);
  setVal('profile-worker-id', profile.healthWorkerId);
  setVal('profile-village', profile.districtVillage);
  setVal('profile-phone', profile.phone);

  // Update header patient badge
  updatePatientHeaderBadge(profile);

  // Save profile form submission
  const profileForm = document.getElementById('patient-profile-form');
  if (profileForm) {
    profileForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const updatedProfile = {
        fullName: document.getElementById('profile-fullname')?.value || '',
        age: document.getElementById('profile-age')?.value || '',
        gender: document.getElementById('profile-gender')?.value || 'female',
        diabetesType: document.getElementById('profile-diabetes-type')?.value || 'type2',
        durationYears: document.getElementById('profile-duration')?.value || '',
        hba1c: document.getElementById('profile-hba1c')?.value || '',
        bloodPressure: document.getElementById('profile-bp')?.value || '',
        healthWorkerId: document.getElementById('profile-worker-id')?.value || '',
        districtVillage: document.getElementById('profile-village')?.value || '',
        phone: document.getElementById('profile-phone')?.value || ''
      };

      localStorage.setItem('retinaxai_patient_profile', JSON.stringify(updatedProfile));
      updatePatientHeaderBadge(updatedProfile);
      showToast(t('profileSaved') || 'Patient profile successfully saved!');
    });
  }
}

function updatePatientHeaderBadge(profile) {
  const badgeName = document.getElementById('header-patient-name');
  const badgeDetails = document.getElementById('header-patient-details');

  if (badgeName) badgeName.textContent = profile.fullName;
  if (badgeDetails) {
    badgeDetails.textContent = `${profile.age} yrs • HbA1c ${profile.hba1c}% • ${profile.districtVillage.split(',')[0]}`;
  }
}

export function getPatientProfile() {
  const saved = localStorage.getItem('retinaxai_patient_profile');
  if (saved) {
    try {
      return JSON.parse(saved);
    } catch (e) {
      return DEFAULT_PATIENT_PROFILE;
    }
  }
  return DEFAULT_PATIENT_PROFILE;
}

/* -------------------------------------------------------------------------- */
/* UI EVENT BINDINGS                                                          */
/* -------------------------------------------------------------------------- */
function bindUIEvents() {
  setupTabNavigation();

  // Language Selector
  const langSelect = document.getElementById('language-selector');
  if (langSelect) {
    langSelect.value = getLanguage();
    langSelect.addEventListener('change', (e) => {
      setLanguage(e.target.value);
      updateAnalysisResultsUI();
      renderMedicineList();
      renderBotGreeting();
    });
  }

  // Country Selector
  const countrySelect = document.getElementById('country-selector');
  if (countrySelect) {
    countrySelect.value = getSelectedCountry();
    countrySelect.addEventListener('change', (e) => {
      setSelectedCountry(e.target.value);
    });
  }

  // Sample Scan Selector Buttons
  const sampleButtons = document.querySelectorAll('.sample-scan-btn');
  sampleButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      const sampleKey = btn.getAttribute('data-sample');
      sampleButtons.forEach(b => b.classList.remove('active-sample', 'ring-2', 'ring-primary'));
      btn.classList.add('active-sample', 'ring-2', 'ring-primary');

      // Visual scanline feedback
      triggerScanAnimation();
      loadSampleScan(sampleKey);
    });
  });

  // File Upload Handling
  const fileInput = document.getElementById('fundus-file-input');
  const dropZone = document.getElementById('fundus-dropzone');

  if (fileInput) {
    fileInput.addEventListener('change', (e) => {
      if (e.target.files && e.target.files[0]) {
        triggerScanAnimation();
        handleFundusImageUpload(e.target.files[0]);
      }
    });
  }

  if (dropZone) {
    ['dragenter', 'dragover'].forEach(eventName => {
      dropZone.addEventListener(eventName, (e) => {
        e.preventDefault();
        dropZone.classList.add('border-primary', 'bg-primary/5');
      });
    });

    ['dragleave', 'drop'].forEach(eventName => {
      dropZone.addEventListener(eventName, (e) => {
        e.preventDefault();
        dropZone.classList.remove('border-primary', 'bg-primary/5');
      });
    });

    dropZone.addEventListener('drop', (e) => {
      if (e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0]) {
        triggerScanAnimation();
        handleFundusImageUpload(e.dataTransfer.files[0]);
      }
    });
  }

  // Visualization Layer Buttons
  const layerButtons = document.querySelectorAll('.layer-btn');
  layerButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      const layer = btn.getAttribute('data-layer');
      layerButtons.forEach(b => b.classList.remove('active', 'bg-primary', 'text-white'));
      btn.classList.add('active', 'bg-primary', 'text-white');
      setViewLayer(layer);
    });
  });

  // Heatmap Opacity Slider
  const opacitySlider = document.getElementById('heatmap-opacity-slider');
  const opacityDisplay = document.getElementById('heatmap-opacity-display');
  if (opacitySlider) {
    opacitySlider.addEventListener('input', (e) => {
      const val = parseFloat(e.target.value);
      if (opacityDisplay) opacityDisplay.textContent = `${Math.round(val * 100)}%`;
      setHeatmapOpacity(val);
    });
  }

  // Voice Assistant Mic & Input
  const micBtn = document.getElementById('voice-mic-trigger');
  if (micBtn) {
    micBtn.addEventListener('click', () => {
      toggleVoiceListening();
    });
  }

  const voiceForm = document.getElementById('voice-chat-form');
  const voiceInput = document.getElementById('voice-chat-input');
  if (voiceForm && voiceInput) {
    voiceForm.addEventListener('submit', (e) => {
      e.preventDefault();
      handleUserChatMessage(voiceInput.value);
    });
  }

  // Quick Inquiries Chips
  const inquiryChips = document.querySelectorAll('.quick-inquiry-btn');
  inquiryChips.forEach(chip => {
    chip.addEventListener('click', () => {
      const query = chip.getAttribute('data-query') || chip.textContent.trim();
      handleUserChatMessage(query);
    });
  });

  // Add Medicine Form
  const addMedForm = document.getElementById('add-medicine-form');
  if (addMedForm) {
    addMedForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const name = document.getElementById('med-name-input')?.value || '';
      const dosage = document.getElementById('med-dosage-input')?.value || '';
      const type = document.getElementById('med-type-input')?.value || 'tablet';
      const timing = document.getElementById('med-timing-input')?.value || 'afterMeal';

      const freqMorning = document.getElementById('med-slot-morning')?.checked || false;
      const freqNoon = document.getElementById('med-slot-afternoon')?.checked || false;
      const freqNight = document.getElementById('med-slot-night')?.checked || false;

      if (!name.trim()) return;

      addMedicine({
        name,
        dosage,
        type,
        timing,
        frequency: {
          morning: freqMorning,
          afternoon: freqNoon,
          night: freqNight
        }
      });

      // Reset form
      addMedForm.reset();
      showToast('Medication added successfully!');
      // Close modal
      const modal = document.getElementById('add-medicine-modal');
      if (modal) modal.classList.add('hidden');
    });
  }

  // Modal Open / Close buttons
  const openMedModalBtn = document.getElementById('open-add-med-modal');
  const closeMedModalBtn = document.getElementById('close-med-modal');
  const medModal = document.getElementById('add-medicine-modal');

  if (openMedModalBtn && medModal) {
    openMedModalBtn.addEventListener('click', () => medModal.classList.remove('hidden'));
  }
  if (closeMedModalBtn && medModal) {
    closeMedModalBtn.addEventListener('click', () => medModal.classList.add('hidden'));
  }

  // Report Generation & WhatsApp Sharing
  const printReportBtn = document.getElementById('print-report-btn');
  if (printReportBtn) {
    printReportBtn.addEventListener('click', () => {
      openReportModal();
    });
  }

  const shareWhatsAppBtn = document.getElementById('share-whatsapp-btn');
  if (shareWhatsAppBtn) {
    shareWhatsAppBtn.addEventListener('click', () => {
      shareReportViaWhatsApp();
    });
  }

  // Listen to custom language changes to update canvas labels
  window.addEventListener('languageChanged', () => {
    updateAnalysisResultsUI();
    renderRetinaCanvas();
  });
}

function triggerScanAnimation() {
  const scanLine = document.getElementById('retina-scan-animation');
  if (scanLine) {
    scanLine.classList.remove('hidden');
    setTimeout(() => {
      scanLine.classList.add('hidden');
    }, 2400);
  }
}

/* -------------------------------------------------------------------------- */
/* MEDICAL REPORT & TELE-REFERRAL EXPORT                                      */
/* -------------------------------------------------------------------------- */
function openReportModal() {
  const profile = getPatientProfile();
  const analysis = getCurrentAnalysis();
  const country = COUNTRY_DATA[getSelectedCountry()] || COUNTRY_DATA['IN'];

  // Fill in report modal fields
  const setEl = (id, text) => {
    const el = document.getElementById(id);
    if (el) el.textContent = text;
  };

  setEl('rep-patient-name', profile.fullName);
  setEl('rep-patient-age-gender', `${profile.age} Years • ${profile.gender.toUpperCase()}`);
  setEl('rep-patient-diabetes', `${profile.diabetesType.toUpperCase()} (${profile.durationYears} Years Duration)`);
  setEl('rep-patient-hba1c', `${profile.hba1c}%`);
  setEl('rep-patient-bp', profile.bloodPressure);
  setEl('rep-health-worker', profile.healthWorkerId);
  setEl('rep-district-village', profile.districtVillage);
  setEl('rep-report-date', new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }));

  setEl('rep-diagnosis-grade', analysis.gradeName);
  setEl('rep-confidence-score', `${analysis.confidence}%`);
  setEl('rep-clinical-risk', analysis.risk);
  setEl('rep-explanation', analysis.explanation[getLanguage()] || analysis.explanation.en);
  setEl('rep-recommendation', analysis.recommendation[getLanguage()] || analysis.recommendation.en);
  setEl('rep-hospital-referral', `${country.hospitals[0]?.name} (${country.hospitals[0]?.region})`);
  setEl('rep-ambulance-call', country.ambulance);

  // Copy retina canvas snapshot into report image
  const canvas = document.getElementById('retina-canvas');
  const reportImg = document.getElementById('rep-retina-image');
  if (canvas && reportImg) {
    reportImg.src = canvas.toDataURL('image/png');
  }

  const modal = document.getElementById('report-modal');
  if (modal) modal.classList.remove('hidden');
}

window.closeReportModal = function() {
  const modal = document.getElementById('report-modal');
  if (modal) modal.classList.add('hidden');
};

window.triggerPrintDialog = function() {
  window.print();
};

function shareReportViaWhatsApp() {
  const profile = getPatientProfile();
  const analysis = getCurrentAnalysis();
  const country = COUNTRY_DATA[getSelectedCountry()] || COUNTRY_DATA['IN'];

  const message = `*RetinaXAI: Tele-Ophthalmology Referral Slip*
----------------------------------------
*Patient:* ${profile.fullName} (${profile.age} Y / ${profile.gender.toUpperCase()})
*Location:* ${profile.districtVillage}
*ASHA ID:* ${profile.healthWorkerId}
*HbA1c:* ${profile.hba1c}% | *BP:* ${profile.bloodPressure}
----------------------------------------
*AI Diagnosis:* ${analysis.gradeName}
*Confidence:* ${analysis.confidence}%
*Risk Category:* ${analysis.risk.toUpperCase()}
*Action Required:* ${analysis.actionType === 'urgent' ? '🚨 URGENT EMERGENCY REFERRAL' : 'Routine Specialist Follow-up'}
*Nearest Center:* ${country.hospitals[0]?.name}
*Ambulance Hotline:* ${country.ambulance}
----------------------------------------
Generated via RetinaXAI Explainable Screening System.`;

  const url = `https://api.whatsapp.com/send?text=${encodeURIComponent(message)}`;
  window.open(url, '_blank');
}

/* -------------------------------------------------------------------------- */
/* TOAST NOTIFICATION UTILITY                                                 */
/* -------------------------------------------------------------------------- */
function showToast(message) {
  const toast = document.createElement('div');
  toast.className = 'fixed bottom-5 right-5 z-50 bg-primary text-white font-medium text-sm px-4 py-3 rounded-xl shadow-xl flex items-center gap-2 animate-fade-in';
  toast.innerHTML = `<i class="fa-solid fa-circle-check"></i><span>${message}</span>`;
  document.body.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transition = 'opacity 0.3s ease';
    setTimeout(() => toast.remove(), 300);
  }, 3000);
}
