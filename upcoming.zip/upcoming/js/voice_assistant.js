/**
 * voice_assistant.js - Arogya Netra Multilingual Voice Assistant & AI Chatbot
 * Supports Web Speech API (SpeechRecognition + SpeechSynthesis)
 * Provides interactive voice conversations for rural patients and ASHA health workers.
 */

import { t, getLanguage } from './i18n.js';

// Pre-trained healthcare QA knowledge base mapped across languages
const QA_KNOWLEDGE_BASE = [
  {
    keywords: ['what is', 'retinopathy', 'diabetic retinopathy', 'diabetes eye', 'क्या है', 'रेटिनोपैथी', 'के हो', 'விழித்திரை நோய்', 'اعتلال الشبكية', 'ریٹینوپیتھی'],
    responses: {
      en: 'Diabetic Retinopathy (DR) is a diabetes complication that damages blood vessels in the retina at the back of the eye. In early stages (NPDR), it often has zero symptoms. Without timely screening, it can progress to bleeding and permanent blindness. Annual screening can prevent 95% of severe vision loss!',
      hi: 'डायबिटिक रेटिनोपैथी मधुमेह (शुगर) की एक गंभीर जटिलता है जो आंख के पर्दे (रेटिना) की रक्त वाहिकाओं को नुकसान पहुंचाती है। शुरुआती चरणों में इसके कोई लक्षण नहीं दिखते। समय पर जांच और इलाज से 95% मामलों में अंधेपन को रोका जा सकता है!',
      ne: 'डायबिटिक रेटिनोप्याथी चिनीरोगको कारणले आँखाको पर्दा (रेटिना) मा असर पर्ने समस्या हो। सुरुवाती अवस्थामा कुनै लक्षण देखिँदैन। समयमै जाँच गर्नाले ९५% दृष्टि गुम्नबाट बचाउन सकिन्छ!',
      ta: 'நீரிழிவு விழித்திரை நோய் என்பது நீரிழிவு நோயினால் கண்ணின் விழித்திரையில் உள்ள இரத்த நாளங்கள் பாதிக்கப்படும் நிலையாகும். ஆரம்பத்தில் அறிகுறிகள் தெரியாது. ஆரம்பக்கட்ட பரிசோதனை 95% பார்வை இழப்பைத் தடுக்கிறது.',
      ar: 'اعتلال الشبكية السكري هو أحد مضاعفات مرض السكري التي تتلف الأوعية الدموية في شبكية العين. في المراحل الأولى لا تظهر أي أعراض. الفحص المبكر يقي من 95% من حالات فقدان البصر!',
      ur: 'ذیابیطس ریٹینوپیتھی آنکھ کے پردے کی رگوں کو شوگر کی وجہ سے ہونے والا نقصان ہے۔ شروع میں علامات محسوس نہیں ہوتیں۔ بروقت ٹیسٹ سے 95 فیصد نابینا پن روکا جا سکتا ہے۔'
    }
  },
  {
    keywords: ['smartphone', 'photo', 'camera', 'fundus', 'phone', 'स्मार्टफोन', 'फोटो', 'तस्वीर', 'मोबाइल', 'போன்', 'هاتف', 'فون', 'کیمرہ'],
    responses: {
      en: 'To capture fundus images in rural areas with a smartphone: 1) Dim the room lights to naturally dilate pupils, 2) Attach the 20D or 28D condensing lens adapter to the phone camera, 3) Use continuous low-beam LED flash, 4) Hold the lens 2 inches from the eye and center the optic disc, 5) Record a 5-second 4K video clip and extract the sharpest frame for RetinaXAI analysis.',
      hi: 'स्मार्टफोन से ग्रामीण क्षेत्रों में रेटिना की फोटो लेने के लिए: 1) कमरे की रोशनी धीमी करें ताकि पुतली फैल सके, 2) 20D लेंस अटैचमेंट को फोन के कैमरे पर लगाएं, 3) फोन की फ्लैशलाइट कम तीव्रता पर चालू रखें, 4) आंख से लगभग 2 इंच की दूरी पर लेंस केंद्रित करें, और 5) सबसे साफ फ्रेम को ऐप में अपलोड करें।',
      ne: 'स्मार्टफोनबाट आँखाको पर्दाको तस्बिर लिन: १) कोठाको बत्ती मधुरो पार्नुहोस्, २) क्यामेरामा २०D लेन्स एडप्टर जोड्नुहोस्, ३) फ्ल्यास अन गर्नुहोस्, ४) आँखाबाट २ इन्चको दुरीमा लेन्स मिलाउनुहोस् र सबैभन्दा स्पष्ट तस्बिर चयन गर्नुहोस्।',
      ta: 'ஸ்மார்ட்போன் மூலம் கண் புகைப்படம் எடுக்க: 1) அறையின் வெளிச்சத்தைக் குறைக்கவும், 2) 20D லென்ஸ் அடாப்டரை பொருத்தவும், 3) ஒளியை மையப்படுத்தி தெளிவான புகைப்படத்தை எடுத்து பதிவேற்றவும்.',
      ar: 'لالتقاط صورة قاع العين بالهاتف الذكي في المناطق الريفية: خفف إضاءة الغرفة، ثبت عدسة التكثيف 20D على كاميرا الهاتف، شغل إضاءة LED الخفيفة، وثبت العدسة على بعد 5 سم من العين لالتقاط أوضح إطار.',
      ur: 'اسمارٹ فون سے آنکھ کی تصویر لینے کا طریقہ: کمرے کی لائٹ مدہم کریں، فون پر 20D لینز لگائیں، آنکھ سے 2 انچ کے فاصلے پر فکس کریں اور واضح تصویر اسکین میں لگائیں۔'
    }
  },
  {
    keywords: ['heatmap', 'gradcam', 'color', 'colors', 'red', 'yellow', 'blue', 'हीटमैप', 'रंग', 'लाल', 'रङ', 'வண்ணங்கள்', 'ألوان', 'الخريطة الحرارية', 'ہیٹ میپ'],
    responses: {
      en: 'The Explainable AI Grad-CAM heatmap uses thermal coloring to show WHY the AI made its decision: RED zones indicate maximum attention on dangerous lesions (hemorrhages, neovascularization), YELLOW highlights microaneurysms and hard exudates, and BLUE represents healthy retinal background tissue.',
      hi: 'व्याख्यात्मक एआई ग्रैड-सीएएम हीटमैप यह दिखाता है कि एआई ने यह निर्णय क्यों लिया: लाल क्षेत्र सबसे खतरनाक क्षति (रक्तस्राव, नई असामान्य रक्त वाहिकाएं) को दर्शाते हैं, पीला क्षेत्र माइक्रोएन्यूरिज्म और वसा जमाव को दर्शाता है, और नीला क्षेत्र सामान्य स्वस्थ रेटिना को दर्शाता है।',
      ne: 'ताप नक्साले एआईले किन यस्तो नतिजा दियो भनेर प्रष्ट पार्छ: रातो भागले गम्भीर क्षति (रगत बगेको वा असामान्य नली), पहेंलो भागले मध्यम क्षति, र निलो भागले स्वस्थ रेटिना देखाउँछ।',
      ta: 'Grad-CAM வெப்ப வரைபடத்தின் வண்ணங்கள்: சிவப்பு நிறம் கடுமையான அபாயப் பகுதிகளையும், மஞ்சள் நிறம் மிதமான கொழுப்புப் படிவுகளையும், நீல நிறம் ஆரோக்கியமான விழித்திரையையும் குறிக்கிறது.',
      ar: 'توضح خريطة Grad-CAM أسباب قرار الذكاء الاصطناعي: اللون الأحمر يبرز الآفات شديدة الخطورة كالنزيف، واللون الأصفر يشير للنضح الدهني والتمدد الوعائي، والأزرق يمثل النسيج السليم.',
      ur: 'گریڈ کیم ہیٹ میپ کے رنگ: سرخ رنگ شدید خطرے اور خون کے دھبوں کی نشاندہی کرتا ہے، پیلا رنگ درمیانے درجے کے نقصانات اور نیلا رنگ صحت مند پردے کو ظاہر کرتا ہے۔'
    }
  },
  {
    keywords: ['diet', 'food', 'sugar', 'prevention', 'lifestyle', 'आहार', 'खाना', 'भोजन', 'खानपान', 'உணவுமுறை', 'غذاء', 'حمية', 'غذا', 'پرہیز'],
    responses: {
      en: 'To protect your vision with diabetes: 1) Eat green leafy vegetables (spinach, methi) rich in lutein and zeaxanthin, 2) Avoid refined sugar, white bread, and sugary teas, 3) Include whole grains, lentils, and flaxseeds, 4) Walk for 30 minutes daily to keep blood pressure and blood glucose in check, 5) Never skip your prescribed diabetic medicines.',
      hi: 'आंखों की रोशनी बचाने के लिए: 1) हरी पत्तेदार सब्जियां (पालक, मेथी) खाएं, 2) चीनी, मैदा और मीठी चाय से बचें, 3) साबुत अनाज और दालें खाएं, 4) रोजाना 30 मिनट टहलें, और 5) डॉक्टर द्वारा दी गई शुगर की दवा कभी न छोड़ें।',
      ne: 'आँखाको दृष्टि जोगाउन: १) हरियो सागसब्जी (पालुङ्गो, मेथी) प्रशस्त खानुहोस्, २) चिनी र मैदाबाट बनेका परिकार नखानुहोस्, ३) दैनिक ३० मिनेट हिँड्नुहोस्, र ४) तोकिएको औषधि नियमित खानुहोस्।',
      ta: 'பார்வையை பாதுகாக்க: 1) பசலைக்கீரை போன்ற பச்சை இலை காய்கறிகளை உண்ணுங்கள், 2) சர்க்கரை மற்றும் இனிப்புகளை தவிர்க்கவும், 3) தினமும் உடற்பயிற்சி செய்து மருந்துகளை தவறாமல் உட்கொள்ளுங்கள்.',
      ar: 'لحماية بصرك مع السكري: تناول الخضروات الورقية الخضراء، تجنب السكريات المكررة والخبز الأبيض، مارس المشي نصف ساعة يومياً، والتزم بمواعيد أدويتك بدقة.',
      ur: 'آنکھوں کی حفاظت کے لیے: سبز پتوں والی سبزیاں کھائیں، میٹھی اشیاء اور چینی سے مکمل پرہیز کریں، روزانہ 30 منٹ چہل قدمی کریں اور دوائیاں باقاعدگی سے لیں۔'
    }
  },
  {
    keywords: ['symptom', 'blur', 'floaters', 'blind', 'vision', 'लक्षण', 'धुंधला', 'दृष्टि', 'குறைபாடு', 'أعراض', 'غباش', 'دھندلا'],
    responses: {
      en: 'Warning symptoms of advanced Diabetic Retinopathy include: floating dark spots or cobwebs in your vision, sudden blurry sight, fluctuating focus, faded colors, and dark or empty areas in your visual field. If you notice a sudden curtain coming across your eye, seek EMERGENCY eye care immediately!',
      hi: 'गंभीर डायबिटिक रेटिनोपैथी के चेतावनी लक्षण: आंखों के सामने काले धब्बे या जाले तैरना, अचानक धुंधलापन दिखना, रंगों का फीका पड़ना या आंखों के आगे अंधेरा छा जाना। यदि अचानक पर्दा गिरता हुआ महसूस हो, तो तुरंत आपातकालीन नेत्र अस्पताल जाएं!',
      ne: 'खतराका लक्षणहरू: आँखा अगाडि काला धब्बा वा जालो तैरिनु, दृष्टि अचानक धमिलो हुनु, रङहरू फिक्का देखिनु। यस्ता लक्षण देखिएमा तुरुन्त आँखा अस्पताल जानुहोस्!',
      ta: 'எச்சரிக்கை அறிகுறிகள்: பார்வையில் கரும்புள்ளிகள் அல்லது வலை போன்ற அமைப்புகள் மிதப்பது, திடீர் மங்கலான பார்வை, நிறங்கள் மங்குதல். இந்த அறிகுறிகள் தோன்றினால் உடனடியாக அவசர கண் சிகிச்சை பெறவும்.',
      ar: 'أعراض الخطر: ظهور نقاط سوداء أو خيوط عنكبوت سابحة في مجال الرؤية، زغللة مفاجئة، وتراجع حدة الألوان. إذا شعرت بستارة سوداء تغطي عينك توجه للطوارئ فوراً!',
      ur: 'خطرناک علامات: آنکھوں کے آگے کالے دھبے یا جالے تیرنا، اچانک نظر کا دھندلا ہونا۔ اگر ایسا ہو تو فوراً ایمرجنسی میں ڈاکٹر کو دکھائیں۔'
    }
  }
];

let recognition = null;
let isListening = false;

export function initVoiceAssistant() {
  setupSpeechRecognition();
  renderBotGreeting();
}

function setupSpeechRecognition() {
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SpeechRecognition) {
    console.warn('Speech Recognition API not supported in this browser.');
    return;
  }

  recognition = new SpeechRecognition();
  recognition.continuous = false;
  recognition.interimResults = false;

  recognition.onstart = () => {
    isListening = true;
    updateMicButtonUI(true);
  };

  recognition.onresult = (event) => {
    const transcript = event.results[0][0].transcript;
    const inputEl = document.getElementById('voice-chat-input');
    if (inputEl) {
      inputEl.value = transcript;
    }
    handleUserChatMessage(transcript);
  };

  recognition.onerror = (err) => {
    console.error('Speech recognition error:', err);
    isListening = false;
    updateMicButtonUI(false);
  };

  recognition.onend = () => {
    isListening = false;
    updateMicButtonUI(false);
  };
}

export function toggleVoiceListening() {
  if (!recognition) {
    alert('Voice input is not supported on this browser. Please type your question in the chat box.');
    return;
  }

  if (isListening) {
    recognition.stop();
  } else {
    // Map application language to speech recognition locale
    const lang = getLanguage();
    const langMap = {
      en: 'en-US',
      hi: 'hi-IN',
      ne: 'ne-NP',
      ta: 'ta-IN',
      ar: 'ar-SA',
      ur: 'ur-PK'
    };
    recognition.lang = langMap[lang] || 'en-US';
    try {
      recognition.start();
    } catch (e) {
      console.warn('Recognition start exception:', e);
    }
  }
}

function updateMicButtonUI(listening) {
  const micBtn = document.getElementById('voice-mic-trigger');
  const listeningBadge = document.getElementById('mic-listening-indicator');
  
  if (micBtn) {
    if (listening) {
      micBtn.classList.add('bg-danger', 'animate-pulse', 'text-white');
      micBtn.classList.remove('bg-primary');
    } else {
      micBtn.classList.remove('bg-danger', 'animate-pulse', 'text-white');
      micBtn.classList.add('bg-primary');
    }
  }

  if (listeningBadge) {
    if (listening) {
      listeningBadge.classList.remove('hidden');
    } else {
      listeningBadge.classList.add('hidden');
    }
  }
}

export function speakText(text) {
  if (!('speechSynthesis' in window)) return;

  window.speechSynthesis.cancel(); // Cancel any ongoing speech
  const utterance = new SpeechSynthesisUtterance(text);
  const lang = getLanguage();
  const langMap = {
    en: 'en-US',
    hi: 'hi-IN',
    ne: 'ne-NP',
    ta: 'ta-IN',
    ar: 'ar-SA',
    ur: 'ur-PK'
  };
  utterance.lang = langMap[lang] || 'en-US';
  utterance.rate = 0.95;
  utterance.pitch = 1.0;

  window.speechSynthesis.speak(utterance);
}

export function stopSpeaking() {
  if ('speechSynthesis' in window) {
    window.speechSynthesis.cancel();
  }
}

export function handleUserChatMessage(userText) {
  const query = (userText || '').trim();
  if (!query) return;

  // Add User bubble to chat
  appendChatMessage(query, 'user');

  // Clear input box
  const inputEl = document.getElementById('voice-chat-input');
  if (inputEl) inputEl.value = '';

  // Determine Bot Response
  setTimeout(() => {
    const reply = generateBotResponse(query);
    appendChatMessage(reply, 'bot');
    speakText(reply);
  }, 400);
}

function generateBotResponse(query) {
  const lang = getLanguage();
  const qLower = query.toLowerCase();

  // Search Knowledge Base
  for (const item of QA_KNOWLEDGE_BASE) {
    const match = item.keywords.some(kw => qLower.includes(kw.toLowerCase()));
    if (match) {
      return item.responses[lang] || item.responses.en;
    }
  }

  // Fallback intelligent response
  const fallbacks = {
    en: "Thank you for asking. For any sudden vision disturbances, pain, or dark spots, please consult the nearest eye specialist hospital listed in the Emergency Directory immediately. Keeping your blood sugar (HbA1c < 7%) and blood pressure controlled is essential to prevent permanent eye damage.",
    hi: "आपके प्रश्न के लिए धन्यवाद। आंखों में किसी भी अचानक धुंधलेपन या काले धब्बों के लिए कृपया आपातकालीन निर्देशिका में दिए गए नजदीकी अस्पताल से संपर्क करें। अंधेपन से बचाव के लिए रक्त शर्करा और रक्तचाप को नियंत्रित रखना सबसे महत्वपूर्ण है।",
    ne: "तपाईंको प्रश्नको लागि धन्यवाद। आँखामा कुनै समस्या देखिएमा तुरुन्त आपतकालीन अस्पतालमा जँचाउनुहोस्। चिनी र रक्तचाप नियन्त्रणमा राख्नु नै दृष्टि जोगाउने मुख्य उपाय हो।",
    ta: "உங்கள் கேள்விக்கு நன்றி. திடீர் பார்வை குறைபாடு ஏற்பட்டால் உடனடியாக அவசர கண் மருத்துவமனைக்கு செல்லவும். சர்க்கரை அளவை கட்டுப்பாட்டில் வைப்பது மிக முக்கியம்.",
    ar: "شكراً لسؤالك. في حال حدوث أي تشوش مفاجئ بالرؤية أو ظهور بقع سوداء، يرجى مراجعة أقرب مستشفى عيون مدرج بدليل الطوارئ فوراً. ضبط السكر وضغط الدم أساسي لحماية شبكيتك.",
    ur: "آپ کے سوال کا شکریہ۔ اگر نظر میں اچانک دھندلا پن یا کالے دھبے محسوس ہوں تو فوری طور پر ہسپتال سے رجوع کریں۔ شوگر اور بلڈ پریشر کو قابو میں رکھنا بینائی کے لیے ضروری ہے۔"
  };

  return fallbacks[lang] || fallbacks.en;
}

export function appendChatMessage(text, sender) {
  const container = document.getElementById('voice-chat-messages');
  if (!container) return;

  const isBot = sender === 'bot';
  const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  const messageHtml = `
    <div class="chat-message flex items-start gap-3 ${isBot ? '' : 'flex-row-reverse'} mb-4 animate-fade-in">
      <div class="w-9 h-9 rounded-full flex items-center justify-center shrink-0 ${
        isBot ? 'bg-primary text-white shadow-md' : 'bg-accent text-white shadow-md'
      }">
        <i class="fa-solid ${isBot ? 'fa-user-doctor' : 'fa-user'} text-sm"></i>
      </div>
      <div class="max-w-[80%]">
        <div class="p-4 rounded-2xl text-sm leading-relaxed ${
          isBot 
            ? 'bg-surface border border-theme text-primary shadow-sm rounded-tl-sm' 
            : 'bg-primary text-white shadow-sm rounded-tr-sm'
        }">
          <p class="whitespace-pre-wrap">${text}</p>
        </div>
        <div class="flex items-center gap-2 mt-1 px-1 text-[11px] text-muted ${isBot ? '' : 'justify-end'}">
          <span>${time}</span>
          ${isBot ? `
            <button type="button" onclick="window.replaySpeech('${encodeURIComponent(text)}')" class="hover:text-primary transition-colors inline-flex items-center gap-1">
              <i class="fa-solid fa-volume-high text-xs"></i>
              <span>Listen</span>
            </button>
          ` : ''}
        </div>
      </div>
    </div>
  `;

  container.insertAdjacentHTML('beforeend', messageHtml);
  container.scrollTop = container.scrollHeight;
}

export function renderBotGreeting() {
  const container = document.getElementById('voice-chat-messages');
  if (!container) return;

  container.innerHTML = '';
  const greeting = t('botGreeting');
  appendChatMessage(greeting, 'bot');
}

window.replaySpeech = function(encodedText) {
  const text = decodeURIComponent(encodedText);
  speakText(text);
};
