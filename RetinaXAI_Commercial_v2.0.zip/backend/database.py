"""
database.py - SQLite Database Management & Relational Schema for RetinaXAI
Supports zero-dependency deployment using Python's standard sqlite3 library.
Provides automated schema migrations, secure password hashing, and clinical seed data.
"""

import sqlite3
import os
import hashlib
import json
import uuid
from datetime import datetime

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "retinaxai.db")

def get_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def hash_password(password: str, salt: str = None) -> str:
    if not salt:
        salt = uuid.uuid4().hex[:16]
    hashed = hashlib.sha256((password + salt).encode('utf-8')).hexdigest()
    return f"{salt}:{hashed}"

def verify_password(password: str, stored_hash: str) -> bool:
    try:
        salt, expected_hash = stored_hash.split(":")
        test_hash = hashlib.sha256((password + salt).encode('utf-8')).hexdigest()
        return test_hash == expected_hash
    except Exception:
        return False

def init_db():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = get_connection()
    cursor = conn.cursor()

    # 1. Users Table (Authentication & Roles)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS users (
        id TEXT PRIMARY KEY,
        email TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        full_name TEXT NOT NULL,
        role TEXT NOT NULL CHECK(role IN ('asha_worker', 'doctor', 'patient', 'admin')),
        district TEXT,
        health_center TEXT,
        phone TEXT,
        token TEXT,
        created_at TEXT NOT NULL
    );
    """)

    # 2. Patients Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS patients (
        id TEXT PRIMARY KEY,
        registered_by_user_id TEXT,
        full_name TEXT NOT NULL,
        age INTEGER NOT NULL,
        gender TEXT NOT NULL,
        diabetes_type TEXT NOT NULL,
        duration_years INTEGER DEFAULT 0,
        hba1c REAL,
        blood_pressure TEXT,
        district_village TEXT,
        phone TEXT,
        created_at TEXT NOT NULL,
        FOREIGN KEY(registered_by_user_id) REFERENCES users(id)
    );
    """)

    # 3. Screenings Table (XAI & Diagnostic Reports)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS screenings (
        id TEXT PRIMARY KEY,
        patient_id TEXT NOT NULL,
        screened_by_user_id TEXT,
        stage INTEGER NOT NULL,
        grade_name TEXT NOT NULL,
        confidence REAL NOT NULL,
        risk TEXT NOT NULL,
        biomarkers_json TEXT NOT NULL,
        explanation TEXT NOT NULL,
        recommendation TEXT NOT NULL,
        doctor_signature TEXT,
        doctor_notes TEXT,
        status TEXT DEFAULT 'completed',
        created_at TEXT NOT NULL,
        FOREIGN KEY(patient_id) REFERENCES patients(id),
        FOREIGN KEY(screened_by_user_id) REFERENCES users(id)
    );
    """)

    # 4. Medicines Table (Daily Adherence)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS medicines (
        id TEXT PRIMARY KEY,
        patient_id TEXT NOT NULL,
        name TEXT NOT NULL,
        dosage TEXT NOT NULL,
        med_type TEXT NOT NULL,
        timing TEXT NOT NULL,
        frequency_json TEXT NOT NULL,
        taken_today_json TEXT NOT NULL,
        date_added TEXT NOT NULL,
        FOREIGN KEY(patient_id) REFERENCES patients(id)
    );
    """)

    # 5. Audit Logs Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS audit_logs (
        id TEXT PRIMARY KEY,
        user_id TEXT,
        action TEXT NOT NULL,
        details TEXT,
        timestamp TEXT NOT NULL
    );
    """)

    conn.commit()
    seed_demo_data(conn)
    conn.close()

def seed_demo_data(conn):
    cursor = conn.cursor()

    # Check if users exist already
    cursor.execute("SELECT COUNT(*) as cnt FROM users")
    if cursor.fetchone()['cnt'] > 0:
        return  # Data already seeded

    now = datetime.now().isoformat()

    # Seed 3 Demo Users: ASHA Worker, Ophthalmologist Doctor, Patient
    users = [
        (
            "usr-asha-1",
            "asha@retinaxai.org",
            hash_password("asha123"),
            "Shanti Devi (ASHA)",
            "asha_worker",
            "Varanasi District",
            "Pindra Primary Health Sub-Center",
            "+91 98765 11001",
            "token_asha_demo_session",
            now
        ),
        (
            "usr-doc-1",
            "dr.varma@aiims.edu",
            hash_password("doctor123"),
            "Dr. Rajesh Varma, MS (Retina)",
            "doctor",
            "New Delhi Apex Center",
            "Dr. RP Centre for Ophthalmic Sciences, AIIMS",
            "+91 94123 45678",
            "token_doc_demo_session",
            now
        ),
        (
            "usr-pat-1",
            "patient@retinaxai.org",
            hash_password("patient123"),
            "Rameshwar Devi",
            "patient",
            "Varanasi District",
            "Pindra Village",
            "+91 98765 43210",
            "token_pat_demo_session",
            now
        )
    ]

    cursor.executemany("""
    INSERT INTO users (id, email, password_hash, full_name, role, district, health_center, phone, token, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, users)

    # Seed Demo Patient Record
    patient_id = "pat-1001"
    cursor.execute("""
    INSERT INTO patients (id, registered_by_user_id, full_name, age, gender, diabetes_type, duration_years, hba1c, blood_pressure, district_village, phone, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        patient_id,
        "usr-asha-1",
        "Rameshwar Devi",
        54,
        "female",
        "type2",
        9,
        9.2,
        "142/90",
        "Pindra PHC, Varanasi, Uttar Pradesh",
        "+91 98765 43210",
        now
    ))

    # Seed Initial Medicines for this patient
    medicines = [
        (
            "med-1",
            patient_id,
            "Metformin Hydrochloride",
            "500 mg",
            "tablet",
            "afterMeal",
            json.dumps({"morning": True, "afternoon": False, "night": True}),
            json.dumps({"morning": True, "afternoon": False, "night": True}),
            "2026-03-01"
        ),
        (
            "med-2",
            patient_id,
            "Glimepiride",
            "1 mg",
            "tablet",
            "beforeMeal",
            json.dumps({"morning": True, "afternoon": False, "night": False}),
            json.dumps({"morning": True, "afternoon": False, "night": False}),
            "2026-03-01"
        ),
        (
            "med-3",
            patient_id,
            "Insulin Glargine (Lantus)",
            "14 Units SubQ",
            "insulin",
            "night",
            json.dumps({"morning": False, "afternoon": False, "night": True}),
            json.dumps({"morning": False, "afternoon": False, "night": False}),
            "2026-03-05"
        ),
        (
            "med-4",
            patient_id,
            "Nepafenac 0.1% Drops",
            "1 Drop Both Eyes",
            "eyedrop",
            "afterMeal",
            json.dumps({"morning": True, "afternoon": True, "night": True}),
            json.dumps({"morning": True, "afternoon": True, "night": False}),
            "2026-03-10"
        )
    ]

    cursor.executemany("""
    INSERT INTO medicines (id, patient_id, name, dosage, med_type, timing, frequency_json, taken_today_json, date_added)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, medicines)

    # Seed Demo Screenings History
    biomarkers_mod = json.dumps({
        "microaneurysms": 18,
        "hemorrhages": 7,
        "hardExudates": 9,
        "cottonWool": 2,
        "neovascularization": "Absent",
        "macularEdemaRisk": "Moderate (~ 18%)"
    })

    cursor.execute("""
    INSERT INTO screenings (id, patient_id, screened_by_user_id, stage, grade_name, confidence, risk, biomarkers_json, explanation, recommendation, doctor_signature, doctor_notes, status, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        "scr-2001",
        patient_id,
        "usr-asha-1",
        2,
        "ICDR Grade 2 - Moderate NPDR",
        95.8,
        "High Risk",
        biomarkers_mod,
        "Multiple high-activation clusters detected across temporal arcades. Dot-blot intraretinal hemorrhages and lipid-rich hard exudates near macula.",
        "Refer to district ophthalmologist within 2-4 weeks. Perform OCT testing.",
        "Verified by Dr. Rajesh Varma (AIIMS) [Digital Seal: #AIIMS-RET-942]",
        "Patient exhibits early macular threatening circinate rings. Advised strict lipid & glycemic control.",
        "reviewed_by_doctor",
        now
    ))

    # Log action
    cursor.execute("""
    INSERT INTO audit_logs (id, user_id, action, details, timestamp)
    VALUES (?, ?, ?, ?, ?)
    """, (
        str(uuid.uuid4()),
        "usr-doc-1",
        "SYSTEM_INITIALIZE",
        "Database initialized with standard clinical seed records and ASHA-Doctor link.",
        now
    ))

    conn.commit()

if __name__ == "__main__":
    init_db()
    print(f"RetinaXAI SQLite Database successfully created at: {DB_PATH}")
