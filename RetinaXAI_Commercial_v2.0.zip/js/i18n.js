/**
 * i18n.js - Multi-language Localization Engine for RetinaXAI
 * Supports: English, Nepali (नेपाली), Tamil (தமிழ்), Arabic (العربية), Urdu (اردو), Hindi (हिन्दी)
 * Includes dynamic RTL (Right-to-Left) direction control.
 */

export const LANGUAGES = {
  en: {
    name: 'English',
    nativeName: 'English',
    dir: 'ltr',
    flag: '🇬🇧'
  },
  hi: {
    name: 'Hindi',
    nativeName: 'हिन्दी',
    dir: 'ltr',
    flag: '🇮🇳'
  },
  ne: {
    name: 'Nepali',
    nativeName: 'नेपाली',
    dir: 'ltr',
    flag: '🇳🇵'
  },
  ta: {
    name: 'Tamil',
    nativeName: 'தமிழ்',
    dir: 'ltr',
    flag: '🇮🇳'
  },
  ar: {
    name: 'Arabic',
    nativeName: 'العربية',
    dir: 'rtl',
    flag: '🇦🇪'
  },
  ur: {
    name: 'Urdu',
    nativeName: 'اردو',
    dir: 'rtl',
    flag: '🇵🇰'
  }
};

export const TRANSLATIONS = {
  en: {
    appTitle: 'RetinaXAI: Rural Eye Screening',
    appSubtitle: 'Explainable AI for Diabetic Retinopathy in Rural Healthcare',
    navScreening: 'AI Screening & XAI',
    navVoice: 'Voice Assistant',
    navMedicine: 'Medicine Tracker',
    navHospitals: 'Emergency & Hospitals',
    navProfile: 'Patient Profile',
    navAnalytics: 'Analytics & Triage',
    navAbout: 'About & Impact',
    
    // Screening tab
    screeningHeading: 'Diabetic Retinopathy Screening',
    screeningSubheading: 'Upload a retinal fundus image or pick a clinical sample to view Explainable AI Grad-CAM heatmaps and diagnostic predictions.',
    selectSample: 'Or Select a Clinical Sample Scan:',
    sampleNormal: 'Normal Retina (No DR)',
    sampleMild: 'Mild Non-Proliferative DR',
    sampleModerate: 'Moderate Non-Proliferative DR',
    sampleSevere: 'Severe Non-Proliferative DR',
    samplePdr: 'Proliferative DR (High Risk)',
    uploadPrompt: 'Drag and drop retinal fundus photo or click to browse',
    uploadHint: 'Supports high-res fundus camera captures & smartphone ophthalmoscope attachments (JPG, PNG)',
    runAnalysis: 'Run AI & Explainability Analysis',
    analyzing: 'Analyzing Retinal Biomarkers...',
    xaiViewMode: 'Visualization Layer:',
    viewOriginal: 'Original Fundus',
    viewGradcam: 'Grad-CAM Heatmap',
    viewLesions: 'Lesion Detection Map',
    viewVessels: 'Vessel Segmentation',
    heatmapOpacity: 'Heatmap Opacity:',
    
    // XAI Results
    resultsHeading: 'Diagnostic & Explainability Assessment',
    confidenceLabel: 'AI Confidence Score:',
    severityGrade: 'Severity Grade (ICDR):',
    riskLevel: 'Clinical Risk:',
    biomarkersDetected: 'Retinal Biomarkers Detected:',
    microaneurysms: 'Microaneurysms',
    hemorrhages: 'Hemorrhages',
    hardExudates: 'Hard Exudates',
    cottonWool: 'Cotton Wool Spots',
    neovascularization: 'Neovascularization',
    macularEdema: 'Macular Edema Risk',
    
    // Clinical Explanation
    explanationTitle: 'Explainable AI Reasoning (Grad-CAM Insights)',
    clinicalSummary: 'Clinical Impression:',
    recommendationTitle: 'Recommended Clinical Action:',
    urgentReferral: 'Urgent Ophthalmology Referral Required (Within 48h)',
    moderateReferral: 'Refer to District Eye Specialist (Within 2-4 Weeks)',
    routineCheckup: 'Annual Routine Diabetic Eye Follow-up',
    printReport: 'Print / Export Medical Report',
    shareWhatsApp: 'Share with District Doctor via WhatsApp',
    
    // Voice Assistant
    assistantHeading: 'Arogya Netra AI Voice Assistant',
    assistantSubheading: 'Interactive multilingual voice companion for rural patients and ASHA health workers.',
    micListening: 'Listening to your voice...',
    micPrompt: 'Click the microphone to speak or type your question below:',
    voiceInputPlaceholder: 'Ask about eye symptoms, diet, sugar control, or report explanation...',
    sendBtn: 'Send',
    sampleQuestions: 'Quick Inquiries:',
    q1: 'What is Diabetic Retinopathy and how can I prevent it?',
    q2: 'How should rural health workers take retinal photos with a smartphone?',
    q3: 'Explain what the Grad-CAM heatmap colors mean.',
    q4: 'What diet helps protect diabetic patients from blindness?',
    botGreeting: 'Namaste! I am your Arogya Netra AI Assistant. How can I help you with your eye health, screening results, or diabetes care today?',

    // Medicine Tracker
    medicineHeading: 'Patient Medication & Insulin Tracker',
    medicineSubheading: 'Monitor daily diabetic and ocular medication intake to ensure strict adherence and prevent vision loss.',
    addMedicine: 'Add New Medication',
    medicineName: 'Medicine Name',
    dosage: 'Dosage (e.g. 500mg, 10 units, 1 drop)',
    type: 'Medication Type',
    tablet: 'Tablet / Capsule',
    insulin: 'Insulin Injection',
    eyedrop: 'Eye Drops',
    syrup: 'Syrup / Solution',
    frequency: 'Frequency',
    morning: 'Morning',
    afternoon: 'Afternoon',
    night: 'Night',
    mealTiming: 'Meal Timing',
    beforeMeal: 'Before Meal',
    afterMeal: 'After Meal',
    withMeal: 'With Meal',
    saveMedicine: 'Save Medication',
    medicineList: 'Current Medications & Today’s Adherence Checklist:',
    noMedicines: 'No medications recorded yet. Click "Add New Medication" to begin tracking.',
    adherenceRate: 'Today’s Medication Adherence:',
    intakeStreak: 'Adherence Status:',
    statusOptimal: 'Excellent (100% Adherence)',
    statusPartial: 'Partial Adherence - Attention Needed',
    statusLow: 'Low Adherence - High Risk of Hyperglycemia',
    markTaken: 'Taken',
    markMissed: 'Missed',
    deleteMed: 'Remove',
    
    // Emergency & Hospitals
    hospitalHeading: 'Emergency Support & Specialized Eye Care',
    hospitalSubheading: 'Select a country/region to locate emergency ambulance lines, government helplines, and top tele-ophthalmology institutions.',
    selectCountry: 'Select Country / Region:',
    ambulanceNumber: 'Emergency Ambulance Hotline:',
    helplineNumber: 'National Health Helpline:',
    specialistHospitals: 'Top Tertiary Eye Hospitals & Institutes:',
    callNow: 'Call Now',
    getDirections: 'View on Maps',
    emergency247: '24/7 Emergency Eye Care',
    
    // Profile
    profileHeading: 'Patient Health & Clinical Record',
    profileSubheading: 'Manage patient demographics, diabetes history, and screening records for rural community outreach.',
    fullName: 'Full Patient Name:',
    age: 'Age:',
    gender: 'Gender:',
    male: 'Male',
    female: 'Female',
    other: 'Other',
    diabetesType: 'Diabetes Classification:',
    type1: 'Type 1 Diabetes',
    type2: 'Type 2 Diabetes',
    gestational: 'Gestational Diabetes',
    preDiabetes: 'Pre-Diabetes',
    durationYears: 'Years Living with Diabetes:',
    hba1c: 'Latest HbA1c Level (%):',
    bloodPressure: 'Blood Pressure (mmHg):',
    healthWorkerId: 'ASHA / Health Worker ID:',
    districtVillage: 'Village / District / PHC:',
    phone: 'Contact Number:',
    saveProfile: 'Save Patient Profile',
    profileSaved: 'Patient profile successfully updated!',
    
    // Theme and Language
    darkMode: 'Dark Mode',
    lightMode: 'Light Mode',
    changeLang: 'Language',
    changeCountry: 'Country',

    // Medical disclaimer
    disclaimer: 'Notice: This Explainable AI screening tool is built for triage assistance by community health workers and does not replace examination by a certified ophthalmologist.'
  },

  hi: {
    appTitle: 'रेटिनाएक्सएआई: ग्रामीण नेत्र जांच',
    appSubtitle: 'ग्रामीण स्वास्थ्य सेवा में डायबिटिक रेटिनोपैथी के लिए व्याख्यात्मक एआई (XAI)',
    navScreening: 'एआई जांच और व्याख्या (XAI)',
    navVoice: 'आवाज सहायक',
    navMedicine: 'दवा ट्रैकर',
    navHospitals: 'आपातकालीन और अस्पताल',
    navProfile: 'मरीज प्रोफाइल',
    navAnalytics: 'एनालिटिक्स और ट्रायज',
    navAbout: 'परियोजना के बारे में',
    
    screeningHeading: 'डायबिटिक रेटिनोपैथी जांच',
    screeningSubheading: 'रेटिना फंडस की तस्वीर अपलोड करें या व्याख्यात्मक एआई ग्रैड-सीएएम हीटमैप और जांच परिणाम देखने के लिए क्लिनिकल नमूना चुनें।',
    selectSample: 'या क्लिनिकल नमूना स्कैन चुनें:',
    sampleNormal: 'सामान्य रेटिना (कोई बीमारी नहीं)',
    sampleMild: 'हल्का डायबिटिक रेटिनोपैथी (Mild NPDR)',
    sampleModerate: 'मध्यम डायबिटिक रेटिनोपैथी (Moderate NPDR)',
    sampleSevere: 'गंभीर डायबिटिक रेटिनोपैथी (Severe NPDR)',
    samplePdr: 'अति-गंभीर प्रोलिफेरेटिव रेटिनोपैथी (PDR)',
    uploadPrompt: 'रेटिना फंडस फोटो यहां खींचें या चुनने के लिए क्लिक करें',
    uploadHint: 'उच्च रिज़ॉल्यूशन फंडस कैमरा या स्मार्टफोन ऑप्थैल्मोस्कोप से ली गई तस्वीरें समर्थित हैं (JPG, PNG)',
    runAnalysis: 'एआई और व्याख्यात्मक विश्लेषण शुरू करें',
    analyzing: 'रेटिना बायोमार्कर का विश्लेषण जारी है...',
    xaiViewMode: 'विज़ुअलाइज़ेशन परत:',
    viewOriginal: 'मूल रेटिना फोटो',
    viewGradcam: 'ग्रैड-सीएएम हीटमैप',
    viewLesions: 'घाव/क्षति पहचान मानचित्र',
    viewVessels: 'रक्त वाहिका विभाजन',
    heatmapOpacity: 'हीटमैप पारदर्शिता:',
    
    resultsHeading: 'निदान और व्याख्यात्मक मूल्यांकन',
    confidenceLabel: 'एआई विश्वास स्कोर:',
    severityGrade: 'गंभीरता ग्रेड (ICDR):',
    riskLevel: 'क्लिनिकल जोखिम:',
    biomarkersDetected: 'पहचाने गए रेटिना बायोमार्कर:',
    microaneurysms: 'माइक्रोएन्यूरिज्म (रक्त वाहिका सूजन)',
    hemorrhages: 'हेमरेज (रेटिना में रक्तस्राव)',
    hardExudates: 'हार्ड एक्सुडेट्स (वसा जमाव)',
    cottonWool: 'कॉटन वूल स्पॉट्स (तंत्रिका क्षति)',
    neovascularization: 'असामान्य नई रक्त वाहिकाएं',
    macularEdema: 'मैकुलर एडिमा जोखिम',
    
    explanationTitle: 'व्याख्यात्मक एआई तर्क (Grad-CAM अंतर्दृष्टि)',
    clinicalSummary: 'क्लिनिकल निष्कर्ष:',
    recommendationTitle: 'अनुशंसित क्लिनिकल कार्रवाई:',
    urgentReferral: 'तुरंत नेत्र विशेषज्ञ रेफरल आवश्यक (48 घंटों के भीतर)',
    moderateReferral: 'जिला नेत्र रोग विशेषज्ञ से संपर्क करें (2-4 सप्ताह के भीतर)',
    routineCheckup: 'वार्षिक नियमित डायबिटिक नेत्र जांच',
    printReport: 'चिकित्सा रिपोर्ट प्रिंट / डाउनलोड करें',
    shareWhatsApp: 'व्हाट्सएप के जरिए जिला डॉक्टर से साझा करें',
    
    assistantHeading: 'आरोग्य नेत्रा एआई आवाज सहायक',
    assistantSubheading: 'ग्रामीण मरीजों और आशा कार्यकर्ताओं के लिए संवादात्मक बहुभाषी आवाज साथी।',
    micListening: 'आपकी आवाज सुनी जा रही है...',
    micPrompt: 'बोलने के लिए माइक्रोफ़ोन पर क्लिक करें या नीचे अपना प्रश्न लिखें:',
    voiceInputPlaceholder: 'आंखों के लक्षण, खान-पान, शुगर नियंत्रण या रिपोर्ट समझने के बारे में पूछें...',
    sendBtn: 'भेजें',
    sampleQuestions: 'त्वरित प्रश्न:',
    q1: 'डायबिटिक रेटिनोपैथी क्या है और इससे कैसे बचा जाए?',
    q2: 'आशा कार्यकर्ता स्मार्टफोन से रेटिना की तस्वीर कैसे ले सकती हैं?',
    q3: 'हीटमैप के रंगों (लाल, पीला, नीला) का क्या मतलब है?',
    q4: 'डायबिटीज के मरीजों को अंधापन से बचने के लिए क्या खाना चाहिए?',
    botGreeting: 'नमस्ते! मैं आपका आरोग्य नेत्रा एआई सहायक हूँ। आज मैं आपकी आंखों के स्वास्थ्य, जांच परिणाम या मधुमेह नियंत्रण में क्या सहायता कर सकता हूँ?',

    medicineHeading: 'मरीज दवा एवं इंसुलिन ट्रैकर',
    medicineSubheading: 'दृष्टि हानि से बचने और मधुमेह को नियंत्रण में रखने के लिए दैनिक दवा सेवन की नियमित निगरानी करें।',
    addMedicine: 'नई दवा जोड़ें',
    medicineName: 'दवा का नाम',
    dosage: 'खुराक (जैसे 500mg, 10 यूनिट, 1 बूंद)',
    type: 'दवा का प्रकार',
    tablet: 'गोली / कैप्सूल',
    insulin: 'इंसुलिन इंजेक्शन',
    eyedrop: 'आई ड्रॉप (आंख की दवा)',
    syrup: 'सिरप / घोल',
    frequency: 'आवृत्ति',
    morning: 'सुबह',
    afternoon: 'दोपहर',
    night: 'रात',
    mealTiming: 'भोजन का समय',
    beforeMeal: 'भोजन से पहले',
    afterMeal: 'भोजन के बाद',
    withMeal: 'भोजन के साथ',
    saveMedicine: 'दवा सहेजें',
    medicineList: 'वर्तमान दवाएं और आज की नियमितता जांच सूची:',
    noMedicines: 'अभी तक कोई दवा दर्ज नहीं की गई है। ट्रैक करना शुरू करने के लिए "नई दवा जोड़ें" पर क्लिक करें।',
    adherenceRate: 'आज की दवा अनुपालन दर:',
    intakeStreak: 'दवा सेवन स्थिति:',
    statusOptimal: 'उत्कृष्ट (100% समय पर दवा ली)',
    statusPartial: 'आंशिक अनुपालन - ध्यान देने की आवश्यकता',
    statusLow: 'कम अनुपालन - उच्च रक्त शर्करा का गंभीर जोखिम',
    markTaken: 'ले ली',
    markMissed: 'छूट गई',
    deleteMed: 'हटाएं',
    
    hospitalHeading: 'आपातकालीन सहायता और विशेष नेत्र अस्पताल',
    hospitalSubheading: 'एम्बुलेंस नंबर, सरकारी हेल्पलाइन और शीर्ष नेत्र चिकित्सा संस्थानों के लिए देश चुनें।',
    selectCountry: 'देश / क्षेत्र चुनें:',
    ambulanceNumber: 'आपातकालीन एम्बुलेंस हेल्पलाइन:',
    helplineNumber: 'राष्ट्रीय स्वास्थ्य हेल्पलाइन:',
    specialistHospitals: 'शीर्ष विशेष नेत्र अस्पताल और केंद्र:',
    callNow: 'कॉल करें',
    getDirections: 'नक्शा देखें',
    emergency247: '24/7 आपातकालीन नेत्र देखभाल',
    
    profileHeading: 'मरीज स्वास्थ्य और क्लिनिकल रिकॉर्ड',
    profileSubheading: 'ग्रामीण स्वास्थ्य सेवा और रिकॉर्ड के लिए मरीज का विवरण, मधुमेह इतिहास और जांच जानकारी प्रबंधित करें।',
    fullName: 'मरीज का पूरा नाम:',
    age: 'उम्र:',
    gender: 'लिंग:',
    male: 'पुरुष',
    female: 'महिला',
    other: 'अन्य',
    diabetesType: 'मधुमेह का प्रकार:',
    type1: 'टाइप 1 डायबिटीज',
    type2: 'टाइप 2 डायबिटीज',
    gestational: 'गर्भकालीन डायबिटीज',
    preDiabetes: 'प्री-डायबिटीज',
    durationYears: 'मधुमेह की अवधि (वर्ष):',
    hba1c: 'नवीनतम एचबीए1सी स्तर (%):',
    bloodPressure: 'रक्तचाप (mmHg):',
    healthWorkerId: 'आशा / स्वास्थ्य कार्यकर्ता आईडी:',
    districtVillage: 'गाँव / जिला / प्राथमिक स्वास्थ्य केंद्र:',
    phone: 'संपर्क नंबर:',
    saveProfile: 'मरीज प्रोफाइल सहेजें',
    profileSaved: 'मरीज की प्रोफाइल सफलतापूर्वक सुरक्षित कर ली गई है!',
    
    darkMode: 'डार्क मोड',
    lightMode: 'लाइट मोड',
    changeLang: 'भाषा',
    changeCountry: 'देश',

    disclaimer: 'सूचना: यह व्याख्यात्मक एआई जांच टूल ग्रामीण स्वास्थ्य कार्यकर्ताओं की प्राथमिक सहायता के लिए है और प्रमाणित नेत्र रोग विशेषज्ञ की संपूर्ण जांच का विकल्प नहीं है।'
  },

  ne: {
    appTitle: 'रेटिनाएक्सएआई: ग्रामीण आँखा जाँच',
    appSubtitle: 'ग्रामीण स्वास्थ्यमा डायबिटिक रेटिनोप्याथीको लागि व्याख्यात्मक एआई (XAI)',
    navScreening: 'एआई जाँच र व्याख्या',
    navVoice: 'आवाज सहायक',
    navMedicine: 'औषधि ट्र्याकर',
    navHospitals: 'आपतकालीन र अस्पतालहरू',
    navProfile: 'बिरामी प्रोफाइल',
    navAnalytics: 'विश्लेषण र ट्रायज',
    navAbout: 'बारेमा',
    
    screeningHeading: 'डायबिटिक रेटिनोप्याथी जाँच',
    screeningSubheading: 'रेटिना फन्डस तस्बिर अपलोड गर्नुहोस् वा व्याख्यात्मक एआई ग्र्याड-क्याम ताप नक्सा र जाँच नतिजा हेर्न क्लिनिकल नमूना छान्नुहोस्।',
    selectSample: 'वा क्लिनिकल नमूना स्क्यान छान्नुहोस्:',
    sampleNormal: 'सामान्य रेटिना (कुनै रोग छैन)',
    sampleMild: 'हल्का डायबिटिक रेटिनोप्याथी (Mild NPDR)',
    sampleModerate: 'मध्यम डायबिटिक रेटिनोप्याथी (Moderate NPDR)',
    sampleSevere: 'गम्भीर डायबिटिक रेटिनोप्याथी (Severe NPDR)',
    samplePdr: 'अत्यन्त गम्भीर प्रोलिफेरेटिभ रेटिनोप्याथी (PDR)',
    uploadPrompt: 'रेटिना फन्डस तस्बिर यहाँ तान्नुहोस् वा ब्राउज गर्न थिच्नुहोस्',
    uploadHint: 'उच्च गुणस्तरको फन्डस क्यामेरा र स्मार्टफोन उपकरणबाट लिइएका तस्बिरहरू समर्थित छन् (JPG, PNG)',
    runAnalysis: 'एआई र व्याख्यात्मक विश्लेषण सुरु गर्नुहोस्',
    analyzing: 'रेटिना बायोमार्कर्सको विश्लेषण हुँदैछ...',
    xaiViewMode: 'भिजुअलाइजेशन तह:',
    viewOriginal: 'मूल रेटिना तस्बिर',
    viewGradcam: 'ग्र्याड-क्याम ताप नक्सा',
    viewLesions: 'घाउ पहिचान नक्सा',
    viewVessels: 'रक्तनली विभाजन',
    heatmapOpacity: 'ताप नक्सा स्पष्टता:',
    
    resultsHeading: 'निदान तथा व्याख्यात्मक नतिजा',
    confidenceLabel: 'एआई विश्वास स्कोर:',
    severityGrade: 'गम्भीरता स्तर (ICDR):',
    riskLevel: 'क्लिनिकल जोखिम:',
    biomarkersDetected: 'पहिचान गरिएका रेटिना बायोमार्कर्स:',
    microaneurysms: 'माइक्रोएन्युरिजम (रक्तनली सुन्निएको)',
    hemorrhages: 'हेमोरेज (रेटिनामा रगत बगेको)',
    hardExudates: 'हार्ड एक्जुडेट्स (बोसो जमेको)',
    cottonWool: 'कटन ऊल स्पट्स (स्नायु क्षति)',
    neovascularization: 'असामान्य नयाँ रक्तनलीहरू',
    macularEdema: 'म्याकुलर एडिमा जोखिम',
    
    explanationTitle: 'व्याख्यात्मक एआई तर्क (Grad-CAM विश्लेषण)',
    clinicalSummary: 'क्लिनिकल निष्कर्ष:',
    recommendationTitle: 'सिफारिस गरिएको क्लिनिकल कदम:',
    urgentReferral: 'तुरुन्त आँखा विशेषज्ञ कहाँ रिफर आवश्यक (४८ घण्टा भित्र)',
    moderateReferral: 'जिल्ला आँखा अस्पतालमा देखाउनुहोस् (२-४ हप्ता भित्र)',
    routineCheckup: 'वार्षिक नियमित मधुमेह आँखा जाँच',
    printReport: 'स्वास्थ्य रिपोर्ट प्रिन्ट / डाउनलोड गर्नुहोस्',
    shareWhatsApp: 'ह्वाट्सएप मार्फत विशेषज्ञ डाक्टरलाई पठाउनुहोस्',
    
    assistantHeading: 'आरोग्य नेत्रा एआई आवाज सहायक',
    assistantSubheading: 'ग्रामीण बिरामी र स्वास्थ्य कार्यकर्ताहरूका लागि संवादात्मक बहुभाषी आवाज साथी।',
    micListening: 'तपाईंको आवाज सुन्दैछ...',
    micPrompt: 'बोल्नको लागि माइक थिच्नुहोस् वा तल प्रश्न लेख्नुहोस्:',
    voiceInputPlaceholder: 'आँखाका लक्षण, खानपान, चिनी नियन्त्रण वा रिपोर्ट बारे सोध्नुहोस्...',
    sendBtn: 'पठाउनुहोस्',
    sampleQuestions: 'द्रुत प्रश्नहरू:',
    q1: 'डायबिटिक रेटिनोप्याथी के हो र यसबाट कसरी जोगिने?',
    q2: 'स्वास्थ्य स्वयंसेविकाले मोबाइलबाट रेटिनाको फोटो कसरी लिने?',
    q3: 'ताप नक्साको रङहरू (रातो, पहेंलो, निलो) को अर्थ के हो?',
    q4: 'मधुमेहका बिरामीले आँखाको ज्योति जोगाउन के खाने?',
    botGreeting: 'नमस्ते! म तपाईंको आरोग्य नेत्रा एआई सहायक हुँ। आज तपाईंको आँखाको स्वास्थ्य वा मधुमेह स्याहारमा के मद्दत गर्न सक्छु?',

    medicineHeading: 'बिरामी औषधि तथा इन्सुलिन ट्र्याकर',
    medicineSubheading: 'दृष्टि गुम्न नदिन र चिनीरोग नियन्त्रण गर्न दैनिक औषधि सेवनको तालिका निगरानी गर्नुहोस्।',
    addMedicine: 'नयाँ औषधि थप्नुहोस्',
    medicineName: 'औषधिको नाम',
    dosage: 'मात्रा (जस्तै 500mg, 10 युनिट, 1 थोपा)',
    type: 'औषधिको प्रकार',
    tablet: 'चक्की / क्याप्सुल',
    insulin: 'इन्सुलिन सुई',
    eyedrop: 'आँखाको थोपा',
    syrup: 'झोल औषधि',
    frequency: 'समय',
    morning: 'बिहान',
    afternoon: 'दिउँसो',
    night: 'राति',
    mealTiming: 'खाना खाने समय',
    beforeMeal: 'खाना अघि',
    afterMeal: 'खाना पछि',
    withMeal: 'खाना सँगै',
    saveMedicine: 'औषधि सुरक्षित गर्नुहोस्',
    medicineList: 'हालका औषधिहरू र आजको तालिका:',
    noMedicines: 'अहिलेसम्म कुनै औषधि थपिएको छैन। "नयाँ औषधि थप्नुहोस्" मा थिच्नुहोस्।',
    adherenceRate: 'आजको औषधि सेवन दर:',
    intakeStreak: 'औषधि स्थिति:',
    statusOptimal: 'उत्कृष्ट (१००% औषधि लिइयो)',
    statusPartial: 'आंशिक - ध्यान दिन जरुरी छ',
    statusLow: 'कम - उच्च रक्त चिनीको गम्भीर जोखिम',
    markTaken: 'खाइयो',
    markMissed: 'छुट्यो',
    deleteMed: 'हटाउनुहोस्',
    
    hospitalHeading: 'आपतकालीन सेवा र आँखा अस्पतालहरू',
    hospitalSubheading: 'एम्बुलेन्स नम्बर, सरकारी हटलाइन र प्रमुख आँखा अस्पतालहरू हेर्न देश छान्नुहोस्।',
    selectCountry: 'देश / क्षेत्र छान्नुहोस्:',
    ambulanceNumber: 'आपतकालीन एम्बुलेन्स हटलाइन:',
    helplineNumber: 'राष्ट्रिय स्वास्थ्य हटलाइन:',
    specialistHospitals: 'प्रमुख विशिष्ट आँखा अस्पतालहरू:',
    callNow: 'कल गर्नुहोस्',
    getDirections: 'नक्सा हेर्नुहोस्',
    emergency247: '२४/७ आपतकालीन आँखा सेवा',
    
    profileHeading: 'बिरामी स्वास्थ्य विवरण',
    profileSubheading: 'ग्रामीण स्वास्थ्य सेवाको लागि बिरामीको विवरण, चिनीरोग इतिहास र जाँच रेकर्ड।',
    fullName: 'बिरामीको पूरा नाम:',
    age: 'उमेर:',
    gender: 'लिङ्ग:',
    male: 'पुरुष',
    female: 'महिला',
    other: 'अन्य',
    diabetesType: 'मधुमेहको प्रकार:',
    type1: 'टाइप १ मधुमेह',
    type2: 'टाइप २ मधुमेह',
    gestational: 'गर्भावस्थाको मधुमेह',
    preDiabetes: 'प्रि-मधुमेह',
    durationYears: 'मधुमेह भएको वर्ष:',
    hba1c: 'पछिल्लो HbA1c स्तर (%):',
    bloodPressure: 'रक्तचाप (mmHg):',
    healthWorkerId: 'स्वास्थ्य कार्यकर्ता / स्वयंसेविका कोड:',
    districtVillage: 'गाउँ / नगरपालिका / स्वास्थ्य चौकी:',
    phone: 'सम्पर्क नम्बर:',
    saveProfile: 'विवरण सुरक्षित गर्नुहोस्',
    profileSaved: 'बिरामीको विवरण सफलतापूर्वक सुरक्षित गरियो!',
    
    darkMode: 'डार्क मोड',
    lightMode: 'लाइट मोड',
    changeLang: 'भाषा',
    changeCountry: 'देश',

    disclaimer: 'सूचना: यो व्याख्यात्मक एआई जाँच प्रणाली ग्रामीण स्वास्थ्य स्वयंसेविकाहरूको प्रारम्भिक सहयोगको लागि हो र नेत्र विशेषज्ञको पूर्ण परीक्षणको विकल्प होइन।'
  },

  ta: {
    appTitle: 'ரெடினாஎக்ஸ்ஏஐ: கிராமப்புற கண் பரிசோதனை',
    appSubtitle: 'கிராமப்புற சுகாதாரத்தில் நீரிழிவு விழித்திரை நோய்க்கான விளக்கக்கூடிய AI (XAI)',
    navScreening: 'AI பரிசோதனை மற்றும் விளக்கம்',
    navVoice: 'குரல் உதவியாளர்',
    navMedicine: 'மருந்து கண்காணிப்பு',
    navHospitals: 'அவசர மற்றும் மருத்துவமனைகள்',
    navProfile: 'நோயாளி விவரக்குறிப்பு',
    navAnalytics: 'பகுப்பாய்வு & அவசர நிலை',
    navAbout: 'திட்டம் பற்றி',
    
    screeningHeading: 'நீரிழிவு விழித்திரை நோய் (Diabetic Retinopathy) பரிசோதனை',
    screeningSubheading: 'விளக்கக்கூடிய AI Grad-CAM வரைபடங்கள் மற்றும் முடிவுகளைக் காண விழித்திரை புகைப்படத்தை பதிவேற்றவும் அல்லது மாதிரியைத் தேர்ந்தெடுக்கவும்.',
    selectSample: 'அல்லது மாதிரி ஸ்கேனைத் தேர்ந்தெடுக்கவும்:',
    sampleNormal: 'சாதாரண விழித்திரை (நோய் இல்லை)',
    sampleMild: 'லேசான நீரிழிவு விழித்திரை நோய் (Mild NPDR)',
    sampleModerate: 'மிதமான நீரிழிவு விழித்திரை நோய் (Moderate NPDR)',
    sampleSevere: 'தீவிர நீரிழிவு விழித்திரை நோய் (Severe NPDR)',
    samplePdr: 'அதி தீவிர விழித்திரை நோய் (Proliferative DR)',
    uploadPrompt: 'விழித்திரை புகைப்படத்தை இங்கே இழுத்துவிடவும் அல்லது கிளிக் செய்யவும்',
    uploadHint: 'உயர் தெளிவுத்திறன் கொண்ட ஃபண்டஸ் கேமரா மற்றும் ஸ்மார்ட்போன் படங்கள் ஆதரிக்கப்படுகின்றன (JPG, PNG)',
    runAnalysis: 'AI மற்றும் விளக்க பகுப்பாய்வைத் தொடங்கு',
    analyzing: 'விழித்திரை பயோமார்க்ஸ் பகுப்பாய்வு செய்யப்படுகிறது...',
    xaiViewMode: 'காட்சி அடுக்கு:',
    viewOriginal: 'அசல் விழித்திரை படம்',
    viewGradcam: 'Grad-CAM வெப்ப வரைபடம்',
    viewLesions: 'காயங்கள் கண்டறிதல் வரைபடம்',
    viewVessels: 'இரத்த நாள பிரிப்பு',
    heatmapOpacity: 'வெப்ப வரைபட ஒளிபுகாமை:',
    
    resultsHeading: 'கண்டறிதல் மற்றும் விளக்க மதிப்பீடு',
    confidenceLabel: 'AI நம்பிக்கை அளவு:',
    severityGrade: 'தீவிர நிலை (ICDR):',
    riskLevel: 'மருத்துவ ஆபத்து:',
    biomarkersDetected: 'கண்டறியப்பட்ட விழித்திரை அறிகுறிகள்:',
    microaneurysms: 'மைக்ரோஅனுரிஸம் (இரத்த நாளம் வீக்கம்)',
    hemorrhages: 'இரத்தக்கசிவு (Hemorrhages)',
    hardExudates: 'கடின கசிவுகள் (Hard Exudates)',
    cottonWool: 'பஞ்சு போன்ற புள்ளிகள் (Cotton Wool Spots)',
    neovascularization: 'அசாதாரண புதிய இரத்த நாளங்கள்',
    macularEdema: 'மாகுலர் எடிமா ஆபத்து',
    
    explanationTitle: 'விளக்கக்கூடிய AI காரணங்கள் (Grad-CAM நுண்ணறிவு)',
    clinicalSummary: 'மருத்துவ முடிவு:',
    recommendationTitle: 'பரிந்துரைக்கப்பட்ட மருத்துவ நடவடிக்கை:',
    urgentReferral: 'உடனடி கண் மருத்துவர் பரிந்துரை தேவை (48 மணி நேரத்திற்குள்)',
    moderateReferral: 'மாவட்ட கண் மருத்துவரிடம் செல்லவும் (2-4 வாரங்களுக்குள்)',
    routineCheckup: 'வருடாந்திர வழக்கமான கண் பரிசோதனை',
    printReport: 'மருத்துவ அறிக்கையை அச்சிடு / பதிவிறக்கு',
    shareWhatsApp: 'வாட்ஸ்அப் மூலம் மருத்துவரிடம் பகிரவும்',
    
    assistantHeading: 'ஆரோக்ய நேத்ரா AI குரல் உதவியாளர்',
    assistantSubheading: 'கிராமப்புற நோயாளிகள் மற்றும் ஆஷா பணியாளர்களுக்கான ஊடாடும் குரல் தோழன்.',
    micListening: 'உங்கள் குரலைக் கேட்கிறது...',
    micPrompt: 'பேச மைக்ரோஃபோனைக் கிளிக் செய்யவும் அல்லது உங்கள் கேள்வியை கீழே தட்டச்சு செய்யவும்:',
    voiceInputPlaceholder: 'கண் அறிகுறிகள், உணவுமுறை, சர்க்கரை கட்டுப்பாடு பற்றி கேளுங்கள்...',
    sendBtn: 'அனுப்பு',
    sampleQuestions: 'விரைவான கேள்விகள்:',
    q1: 'நீரிழிவு விழித்திரை நோய் என்றால் என்ன, அதை எவ்வாறு தடுப்பது?',
    q2: 'ஸ்மார்ட்போன் மூலம் கிராமப்புற சுகாதாரப் பணியாளர்கள் கண் படத்தை எடுப்பது எப்படி?',
    q3: 'வெப்ப வரைபட வண்ணங்களின் (சிவப்பு, மஞ்சள், நீலம்) அர்த்தம் என்ன?',
    q4: 'பார்வை இழப்பைத் தடுக்க நீரிழிவு நோயாளிகள் என்ன சாப்பிட வேண்டும்?',
    botGreeting: 'வணக்கம்! நான் உங்கள் ஆரோக்ய நேத்ரா AI உதவியாளர். உங்கள் கண் ஆரோக்கியம் அல்லது நீரிழிவு பராமரிப்பில் நான் இன்று எவ்வாறு உதவ முடியும்?',

    medicineHeading: 'நோயாளி மருந்து மற்றும் இன்சுலின் கண்காணிப்பு',
    medicineSubheading: 'பார்வை இழப்பைத் தடுக்க தினசரி மருந்து மற்றும் இன்சுலின் உட்கொள்ளலை துல்லியமாக கண்காணிக்கவும்.',
    addMedicine: 'புதிய மருந்தைச் சேர்க்கவும்',
    medicineName: 'மருந்தின் பெயர்',
    dosage: 'அளவு (எ.கா. 500mg, 10 அலகுகள், 1 சொட்டு)',
    type: 'மருந்து வகை',
    tablet: 'மாத்திரை / காப்ஸ்யூல்',
    insulin: 'இன்சுலின் ஊசி',
    eyedrop: 'கண் சொட்டு மருந்து',
    syrup: 'சிரப் / திரவம்',
    frequency: 'நேரம்',
    morning: 'காலை',
    afternoon: 'மதியம்',
    night: 'இரவு',
    mealTiming: 'உணவு நேரம்',
    beforeMeal: 'உணவுக்கு முன்',
    afterMeal: 'உணவுக்குப் பின்',
    withMeal: 'உணவுடன்',
    saveMedicine: 'மருந்தைச் சேமிக்கவும்',
    medicineList: 'தற்போதைய மருந்துகள் மற்றும் இன்றைய பட்டியல்:',
    noMedicines: 'இதுவரை மருந்துகள் எதுவும் சேர்க்கப்படவில்லை. தொடங்க "புதிய மருந்தைச் சேர்க்கவும்" என்பதைக் கிளிக் செய்யவும்.',
    adherenceRate: 'இன்றைய மருந்து உட்கொள்ளல் சதவீதம்:',
    intakeStreak: 'மருந்து நிலை:',
    statusOptimal: 'சிறப்பானது (100% மருந்துகள் எடுக்கப்பட்டது)',
    statusPartial: 'பகுதி உட்கொள்ளல் - கவனம் தேவை',
    statusLow: 'குறைந்த உட்கொள்ளல் - உயர் சர்க்கரை ஆபத்து',
    markTaken: 'எடுக்கப்பட்டது',
    markMissed: 'தவறியது',
    deleteMed: 'நீக்கு',
    
    hospitalHeading: 'அவசர உதவி மற்றும் சிறப்பு கண் மருத்துவமனைகள்',
    hospitalSubheading: 'ஆம்புலன்ஸ் எண்கள் மற்றும் சிறந்த கண் மருத்துவமனைகளைக் கண்டறிய நாட்டைத் தேர்ந்தெடுக்கவும்.',
    selectCountry: 'நாடு / பகுதியைத் தேர்ந்தெடுக்கவும்:',
    ambulanceNumber: 'அவசர ஆம்புலன்ஸ் எண்:',
    helplineNumber: 'தேசிய சுகாதார உதவி எண்:',
    specialistHospitals: 'சிறந்த கண் மருத்துவமனைகள் மற்றும் நிறுவனங்கள்:',
    callNow: 'அழைக்கவும்',
    getDirections: 'வரைபடத்தில் பார்க்கவும்',
    emergency247: '24/7 அவசர கண் சிகிச்சை',
    
    profileHeading: 'நோயாளி சுகாதார விவரக்குறிப்பு',
    profileSubheading: 'கிராமப்புற சமூக சேவைக்காக நோயாளியின் விவரங்கள், நீரிழிவு வரலாறு மற்றும் பதிவுகளை நிர்வகிக்கவும்.',
    fullName: 'நோயாளியின் முழுப் பெயர்:',
    age: 'வயது:',
    gender: 'பாலினம்:',
    male: 'ஆண்',
    female: 'பெண்',
    other: 'மற்றவை',
    diabetesType: 'நீரிழிவு வகை:',
    type1: 'வகை 1 நீரிழிவு',
    type2: 'வகை 2 நீரிழிவு',
    gestational: 'கர்ப்பகால நீரிழிவு',
    preDiabetes: 'முன் நீரிழிவு',
    durationYears: 'நீரிழிவு உள்ள ஆண்டுகள்:',
    hba1c: 'சமீபத்திய HbA1c அளவு (%):',
    bloodPressure: 'இரத்த அழுத்தம் (mmHg):',
    healthWorkerId: 'ஆஷா / சுகாதாரப் பணியாளர் எண்:',
    districtVillage: 'கிராமம் / மாவட்டம் / ஆரம்ப சுகாதார நிலையம்:',
    phone: 'தொலைபேசி எண்:',
    saveProfile: 'விவரக்குறிப்பைச் சேமிக்கவும்',
    profileSaved: 'நோயாளி விவரக்குறிப்பு வெற்றிகரமாக புதுப்பிக்கப்பட்டது!',
    
    darkMode: 'இருண்ட பயன்முறை',
    lightMode: 'ஒளி பயன்முறை',
    changeLang: 'மொழி',
    changeCountry: 'நாடு',

    disclaimer: 'அறிவிப்பு: இந்த விளக்கக்கூடிய AI கருவி ஆரம்பக்கட்ட உதவிக்காக மட்டுமே, கண் மருத்துவ பரிசோதனைக்கு மாற்றாகாது.'
  },

  ar: {
    appTitle: 'ريتينا إكس إيه آي: الفحص العيني الذكي',
    appSubtitle: 'الذكاء الاصطناعي القابل للتفسير (XAI) لفحص اعتلال الشبكية السكري في المناطق الريفية',
    navScreening: 'فحص الذكاء الاصطناعي والتفسير',
    navVoice: 'المساعد الصوتي',
    navMedicine: 'متتبع الأدوية',
    navHospitals: 'الطوارئ والمستشفيات',
    navProfile: 'ملف المريض',
    navAnalytics: 'التحليلات والفرز السريري',
    navAbout: 'حول المشروع',
    
    screeningHeading: 'فحص اعتلال الشبكية السكري',
    screeningSubheading: 'قم بتحميل صورة قاع العين أو اختر عينة سريرية لعرض الخريطة الحرارية Grad-CAM والتنبؤات التشخيصية.',
    selectSample: 'أو اختر عينة فحص سريرية جاهزة:',
    sampleNormal: 'شبكية طبيعية (سليمة تماماً)',
    sampleMild: 'اعتلال شبكية طفيف غير تكاثري (Mild NPDR)',
    sampleModerate: 'اعتلال شبكية متوسط غير تكاثري (Moderate NPDR)',
    sampleSevere: 'اعتلال شبكية شديد غير تكاثري (Severe NPDR)',
    samplePdr: 'اعتلال شبكية تكاثري عالي الخطورة (Proliferative DR)',
    uploadPrompt: 'اسحب وأسقط صورة قاع العين هنا أو انقر للاختيار',
    uploadHint: 'يدعم صور كاميرا قاع العين وملحقات الهواتف الذكية (JPG, PNG)',
    runAnalysis: 'بدء تحليل الذكاء الاصطناعي والتفسير',
    analyzing: 'جاري تحليل المؤشرات الحيوية للشبكية...',
    xaiViewMode: 'طبقة العرض المرئي:',
    viewOriginal: 'الصورة الأصلية',
    viewGradcam: 'خريطة Grad-CAM الحرارية',
    viewLesions: 'خريطة كشف الآفات',
    viewVessels: 'تجزئة الأوعية الدموية',
    heatmapOpacity: 'شفافية الخريطة الحرارية:',
    
    resultsHeading: 'التقييم التشخيصي والتفسيري',
    confidenceLabel: 'نسبة ثقة الذكاء الاصطناعي:',
    severityGrade: 'درجة الخطورة (ICDR):',
    riskLevel: 'الخطر السريري:',
    biomarkersDetected: 'المؤشرات الحيوية المكتشفة في الشبكية:',
    microaneurysms: 'أمهات الدم المجهرية (Microaneurysms)',
    hemorrhages: 'نزيف الشبكية (Hemorrhages)',
    hardExudates: 'النضح الصلب (Hard Exudates)',
    cottonWool: 'بقع صوف قطني (نقص تروية عصبية)',
    neovascularization: 'أوعية دموية جديدة غير طبيعية',
    macularEdema: 'خطر وذمة البقعة الصفراء',
    
    explanationTitle: 'تفسير منطق الذكاء الاصطناعي (رؤى Grad-CAM)',
    clinicalSummary: 'الانطباع السريري:',
    recommendationTitle: 'الإجراء الطبي الموصى به:',
    urgentReferral: 'إحالة عاجلة لطبيب العيون مطلوبة (خلال 48 ساعة)',
    moderateReferral: 'مراجعة أخصائي العيون بالمستشفى (خلال 2-4 أسابيع)',
    routineCheckup: 'فحص عيني دوري سنوي لمرضى السكري',
    printReport: 'طباعة / تصدير التقرير الطبي',
    shareWhatsApp: 'مشاركة التقرير عبر واتساب مع الطبيب',
    
    assistantHeading: 'المساعد الصوتي الذكي (عيون آمنة)',
    assistantSubheading: 'رفيق صوتي تفاعلي متعدد اللغات لمرضى السكري والعاملين الصحيين في الميدان.',
    micListening: 'جاري الاستماع لصوتك الآن...',
    micPrompt: 'انقر على الميكروفون للتحدث أو اكتب سؤالك أدناه:',
    voiceInputPlaceholder: 'اسأل عن أعراض العين، النظام الغذائي، أو شرح التقرير...',
    sendBtn: 'إرسال',
    sampleQuestions: 'أسئلة سريعة شائعة:',
    q1: 'ما هو اعتلال الشبكية السكري وكيف يمكنني الوقاية منه؟',
    q2: 'كيف يمكن التقاط صور الشبكية عبر الهاتف الذكي في المناطق النائية؟',
    q3: 'ماذا تعني ألوان الخريطة الحرارية (أحمر، أصفر، أزرق)؟',
    q4: 'ما هو النظام الغذائي الذي يحمي مريض السكري من فقدان البصر؟',
    botGreeting: 'أهلاً بك! أنا مساعدك الذكي لصحة العيون. كيف يمكنني مساعدتك اليوم بخصوص فحص الشبكية أو رعاية السكري؟',

    medicineHeading: 'متتبع أدوية المريض وجرعات الإنسولين',
    medicineSubheading: 'مراقبة تناول أدوية السكري والعيون يومياً لضمان الالتزام التام ومنع تدهور البصر.',
    addMedicine: 'إضافة دواء جديد',
    medicineName: 'اسم الدواء',
    dosage: 'الجرعة (مثال: 500 ملغ، 10 وحدات، قطرة واحدة)',
    type: 'نوع العلاج',
    tablet: 'حبوب / كبسولات',
    insulin: 'حقن إنسولين',
    eyedrop: 'قطرات للعين',
    syrup: 'شراب / سائل',
    frequency: 'التوقيت',
    morning: 'الصباح',
    afternoon: 'الظهيرة',
    night: 'المساء / الليل',
    mealTiming: 'وقت تناول الطعام',
    beforeMeal: 'قبل الأكل',
    afterMeal: 'بعد الأكل',
    withMeal: 'مع الأكل',
    saveMedicine: 'حفظ الدواء',
    medicineList: 'قائمة الأدوية الحالية وجدول الالتزام لليوم:',
    noMedicines: 'لم يتم تسجيل أي دواء حتى الآن. انقر على "إضافة دواء جديد" للبدء.',
    adherenceRate: 'نسبة الالتزام بالعلاج اليوم:',
    intakeStreak: 'حالة الالتزام الدوائي:',
    statusOptimal: 'ممتاز (التزام 100%)',
    statusPartial: 'التزام جزئي - يلزم التنبيه',
    statusLow: 'التزام منخفض - خطر مرتفع لارتفاع السكر',
    markTaken: 'تم الأخذ',
    markMissed: 'فاتتني',
    deleteMed: 'حذف',
    
    hospitalHeading: 'خدمات الطوارئ والمراكز التخصصية للعيون',
    hospitalSubheading: 'اختر الدولة لعرض أرقام الإسعاف ومراكز العيون المرجعية الوطنية.',
    selectCountry: 'اختر الدولة / المنطقة:',
    ambulanceNumber: 'خط الإسعاف السريع والطوارئ:',
    helplineNumber: 'الخط الساخن لوزارة الصحة:',
    specialistHospitals: 'أفضل المستشفيات والمراكز التخصصية للعيون:',
    callNow: 'اتصال مباشر',
    getDirections: 'عرض في الخرائط',
    emergency247: 'رعاية طوارئ للعين 24/7',
    
    profileHeading: 'ملف المريض والبيانات السريرية',
    profileSubheading: 'إدارة بيانات المريض وتاريخ السكري وسجلات الفحص للمراكز الصحية والميدانية.',
    fullName: 'اسم المريض بالكامل:',
    age: 'العمر:',
    gender: 'الجنس:',
    male: 'ذكر',
    female: 'أنثى',
    other: 'آخر',
    diabetesType: 'نوع مرض السكري:',
    type1: 'النوع الأول (Type 1)',
    type2: 'النوع الثاني (Type 2)',
    gestational: 'سكري الحمل',
    preDiabetes: 'مرحلة ما قبل السكري',
    durationYears: 'سنوات الإصابة بالسكري:',
    hba1c: 'آخر قراءة للسكر التراكمي HbA1c (%):',
    bloodPressure: 'ضغط الدم (ملم زئبق):',
    healthWorkerId: 'معرف الممارس الصحي الميداني:',
    districtVillage: 'القرية / الحي / المركز الصحي:',
    phone: 'رقم الهاتف:',
    saveProfile: 'حفظ ملف المريض',
    profileSaved: 'تم تحديث وحفظ ملف المريض بنجاح!',
    
    darkMode: 'الوضع الليلي',
    lightMode: 'الوضع النهاري',
    changeLang: 'اللغة',
    changeCountry: 'الدولة',

    disclaimer: 'تنبيه: تم تصميم هذا الفحص الذكي كأداة فرز أولية لدعم العاملين الصحيين في الميدان ولا يغني عن الفحص السريري لطبيب العيون المختص.'
  },

  ur: {
    appTitle: 'ریٹینا ایکس اے آئی: دیہی آنکھوں کی اسکریننگ',
    appSubtitle: 'دیہی صحت کے لیے ذیابیطس ریٹینوپیتھی کا قابل فہم مصنوعی ذہانت (XAI) نظام',
    navScreening: 'اے آئی اسکریننگ اور وضاحت',
    navVoice: 'صوتی معاون (Voice Bot)',
    navMedicine: 'ادویات ٹریکر',
    navHospitals: 'ہنگامی امداد اور ہسپتال',
    navProfile: 'مریض کا پروفائل',
    navAnalytics: 'شماریات اور کلینیکل جائزہ',
    navAbout: 'پروجیکٹ کا تعارف',
    
    screeningHeading: 'ذیابیطس ریٹینوپیتھی اسکریننگ',
    screeningSubheading: 'آنکھ کے پردے (ریٹینا) کی تصویر اپ لوڈ کریں یا مصنوعی ذہانت کے گرمائی نقشے (Grad-CAM) اور تشخیصی نتائج دیکھنے کے لیے نمونہ منتخب کریں۔',
    selectSample: 'یا کلینیکل نمونہ اسکین منتخب کریں:',
    sampleNormal: 'عام ریٹینا (کوئی بیماری نہیں)',
    sampleMild: 'ہلکی ذیابیطس ریٹینوپیتھی (Mild NPDR)',
    sampleModerate: 'درمیانی ذیابیطس ریٹینوپیتھی (Moderate NPDR)',
    sampleSevere: 'شدید ذیابیطس ریٹینوپیتھی (Severe NPDR)',
    samplePdr: 'انتہائی شدید ریٹینوپیتھی (Proliferative DR)',
    uploadPrompt: 'ریٹینا فنڈس تصویر یہاں ڈراپ کریں یا منتخب کرنے کے لیے کلک کریں',
    uploadHint: 'ہائی ریزولیوشن فنڈس کیمرہ یا اسمارٹ فون فنڈس امیجز کی حمایت کرتا ہے (JPG, PNG)',
    runAnalysis: 'اے آئی اور وضاحتی تجزیہ شروع کریں',
    analyzing: 'ریٹینا بائیو مارکرز کا تفصیلی تجزیہ جاری ہے...',
    xaiViewMode: 'تصویری پرت (Visualization Layer):',
    viewOriginal: 'اصل ریٹینا تصویر',
    viewGradcam: 'گریڈ-کیم ہیٹ میپ (Grad-CAM)',
    viewLesions: 'زخم اور خون کے دھبوں کا نقشہ',
    viewVessels: 'خون کی نالیوں کی تقسیم',
    heatmapOpacity: 'ہیٹ میپ کی شفافیت:',
    
    resultsHeading: 'تشخیصی اور وضاحتی جائزہ',
    confidenceLabel: 'اے آئی اعتمادی اسکور:',
    severityGrade: 'شدت کا درجہ (ICDR):',
    riskLevel: 'طبی خطرہ:',
    biomarkersDetected: 'دریافت شدہ ریٹینا بائیو مارکرز:',
    microaneurysms: 'مائیکرو اینیورزم (خون کی نالیوں کا ابھار)',
    hemorrhages: 'ہیمرج (پردے میں خون بہنا)',
    hardExudates: 'سخت رطوبتیں (Hard Exudates)',
    cottonWool: 'روئی نما دھبے (عصبی نقصان)',
    neovascularization: 'غیر معمولی نئی خون کی نالیاں',
    macularEdema: 'میکولر ایڈیما (سوجن) کا خطرہ',
    
    explanationTitle: 'مصنوعی ذہانت کی وضاحت (Grad-CAM رہنمائی)',
    clinicalSummary: 'طبی خلاصہ:',
    recommendationTitle: 'تجویز کردہ طبی کارروائی:',
    urgentReferral: 'آنکھوں کے ماہر ڈاکٹر سے فوری رجوع کریں (48 گھنٹوں کے اندر)',
    moderateReferral: 'ضلعی آنکھوں کے ماہر سے معائنہ کروائیں (2-4 ہفتوں کے اندر)',
    routineCheckup: 'سالانہ معمول کا ذیابیطس آنکھوں کا معائنہ',
    printReport: 'میڈیکل رپورٹ پرنٹ / ڈاؤن لوڈ کریں',
    shareWhatsApp: 'واٹس ایپ کے ذریعے ضلعی ڈاکٹر سے شیئر کریں',
    
    assistantHeading: 'صوتی معاون: آروگیہ نیترا اے آئی',
    assistantSubheading: 'دیہی مریضوں اور بنیادی ہیلتھ ورکرز کے لیے انٹرایکٹو کثیر لسانی صوتی ساتھی۔',
    micListening: 'آپ کی آواز سنی جا رہی ہے...',
    micPrompt: 'بولنے کے لیے مائیک پر کلک کریں یا نیچے اپنا سوال ٹائپ کریں:',
    voiceInputPlaceholder: 'آنکھوں کی علامات، غذا، شوگر کنٹرول یا رپورٹ کے بارے میں پوچھیں...',
    sendBtn: 'ارسال کریں',
    sampleQuestions: 'اہم سوالات:',
    q1: 'ذیابیطس ریٹینوپیتھی کیا ہے اور اس سے کیسے بچا جا سکتا ہے؟',
    q2: 'دیہی ورکرز اسمارٹ فون سے آنکھ کے پردے کی تصویر کیسے لیں؟',
    q3: 'ہیٹ میپ کے رنگوں (سرخ، پیلا، نیلا) کا کیا مطلب ہے؟',
    q4: 'شوگر کے مریضوں کو بینائی محفوظ رکھنے کے لیے کیا کھانا چاہیے؟',
    botGreeting: 'السلام علیکم! میں آپ کا آروگیہ نیترا اے آئی صوتی معاون ہوں۔ آج میں آپ کی آنکھوں کی صحت، معائنے یا شوگر کی دیکھ بھال میں کیا مدد کر سکتا ہوں؟',

    medicineHeading: 'مریض کی ادویات اور انسولین ٹریکر',
    medicineSubheading: 'بینائی کے نقصان کو روکنے کے لیے روزانہ شوگر اور آنکھوں کی دوائیوں کے وقت پر لینے کی نگرانی کریں۔',
    addMedicine: 'نئی دوا شامل کریں',
    medicineName: 'دوا کا نام',
    dosage: 'خوراک (مثال: 500 ملی گرام، 10 یونٹ، 1 قطرہ)',
    type: 'دوا کی قسم',
    tablet: 'گولی / کیپسول',
    insulin: 'انسولین انجکشن',
    eyedrop: 'آنکھوں کے قطرے (Eye Drops)',
    syrup: 'شربت / مائع',
    frequency: 'اوقات',
    morning: 'صبح',
    afternoon: 'دوپہر',
    night: 'رات',
    mealTiming: 'کھانے کا وقت',
    beforeMeal: 'کھانے سے پہلے',
    afterMeal: 'کھانے کے بعد',
    withMeal: 'کھانے کے ساتھ',
    saveMedicine: 'دوا محفوظ کریں',
    medicineList: 'موجودہ ادویات اور آج کا شیڈول:',
    noMedicines: 'ابھی تک کوئی دوا شامل نہیں کی گئی۔ ٹریکنگ شروع کرنے کے لیے "نئی دوا شامل کریں" پر کلک کریں۔',
    adherenceRate: 'آج ادویات لینے کی شرح:',
    intakeStreak: 'دوا کے استعمال کی حالت:',
    statusOptimal: 'شاندار (100% ادویات وقت پر لی گئیں)',
    statusPartial: 'جزوی استعمال - توجہ کی ضرورت ہے',
    statusLow: 'کم استعمال - شوگر میں خطرناک اضافے کا خدشہ',
    markTaken: 'لے لی',
    markMissed: 'رہ گئی',
    deleteMed: 'حذف کریں',
    
    hospitalHeading: 'ہنگامی مدد اور آنکھوں کے مخصوص ہسپتال',
    hospitalSubheading: 'ایمبولینس نمبرز، ہیلپ لائن اور آنکھوں کے بہترین ہسپتالوں کے لیے ملک منتخب کریں۔',
    selectCountry: 'ملک / علاقہ منتخب کریں:',
    ambulanceNumber: 'ہنگامی ایمبولینس نمبر:',
    helplineNumber: 'قومی ہیلتھ ہیلپ لائن:',
    specialistHospitals: 'آنکھوں کے اعلیٰ ہسپتال اور ادارے:',
    callNow: 'کال کریں',
    getDirections: 'نقشہ دیکھیں',
    emergency247: '24/7 ہنگامی امراضِ چشم کی دیکھ بھال',
    
    profileHeading: 'مریض کی صحت کا ریکارڈ',
    profileSubheading: 'دیہی علاقوں کے مریضوں کے کوائف، شوگر کی تاریخ اور اسکریننگ کے ریکارڈ کا انتظام کریں۔',
    fullName: 'مریض کا پورا نام:',
    age: 'عمر:',
    gender: 'جنس:',
    male: 'مرد',
    female: 'خواتین',
    other: 'دیگر',
    diabetesType: 'شوگر کی قسم:',
    type1: 'ٹائپ 1 ذیابیطس',
    type2: 'ٹائپ 2 ذیابیطس',
    gestational: 'حمل کے دوران ذیابیطس',
    preDiabetes: 'قبل از ذیابیطس (Pre-Diabetes)',
    durationYears: 'ذیابیطس کے سال:',
    hba1c: 'تازہ ترین HbA1c سطح (%):',
    bloodPressure: 'بلڈ پریشر (mmHg):',
    healthWorkerId: 'ہیلتھ ورکر / آشا ورکر شناختی کوڈ:',
    districtVillage: 'گاؤں / ضلع / بنیادی مرکز صحت:',
    phone: 'رابطہ نمبر:',
    saveProfile: 'پروفائل محفوظ کریں',
    profileSaved: 'مریض کا پروفائل کامیابی کے ساتھ محفوظ ہو گیا ہے!',
    
    darkMode: 'ڈارک موڈ',
    lightMode: 'لائٹ موڈ',
    changeLang: 'زبان',
    changeCountry: 'ملک',

    disclaimer: 'انتباہ: یہ وضاحتی اے آئی نظام دیہی ہیلتھ ورکرز کی ابتدائی رہنمائی کے لیے ہے اور آنکھوں کے ماہر ڈاکٹر کے تفصیلی معائنے کا نعم البدل نہیں ہے۔'
  }
};

let currentLanguage = 'en';

export function getLanguage() {
  return currentLanguage;
}

export function setLanguage(langCode) {
  if (TRANSLATIONS[langCode]) {
    currentLanguage = langCode;
    localStorage.setItem('retinaxai_language', langCode);
    applyLanguageToDOM();
    return true;
  }
  return false;
}

export function t(key) {
  const dict = TRANSLATIONS[currentLanguage] || TRANSLATIONS['en'];
  return dict[key] || TRANSLATIONS['en'][key] || key;
}

export function applyLanguageToDOM() {
  const langConfig = LANGUAGES[currentLanguage] || LANGUAGES.en;
  const isRTL = langConfig.dir === 'rtl';

  // Set document dir and lang attributes
  document.documentElement.setAttribute('dir', langConfig.dir);
  document.documentElement.setAttribute('lang', currentLanguage);
  document.body.setAttribute('lang', currentLanguage);

  // Remove previous font classes
  document.body.classList.remove('font-en', 'font-hi', 'font-ne', 'font-ta', 'font-ar', 'font-ur');
  document.body.classList.add(`font-${currentLanguage}`);

  // Dynamic Typography Fonts per language
  const FONT_MAP = {
    en: "'Plus Jakarta Sans', system-ui, -apple-system, sans-serif",
    hi: "'Noto Sans Devanagari', 'Mukta', sans-serif",
    ne: "'Mukta', 'Noto Sans Devanagari', sans-serif",
    ta: "'Noto Sans Tamil', 'Mukta Malar', sans-serif",
    ar: "'Cairo', 'Noto Sans Arabic', sans-serif",
    ur: "'Noto Nastaliq Urdu', 'Gulzar', 'Noto Sans Arabic', serif"
  };
  const activeFont = FONT_MAP[currentLanguage] || FONT_MAP.en;
  document.documentElement.style.setProperty('--font-current-lang', activeFont);
  document.body.style.fontFamily = activeFont;

  if (isRTL) {
    document.body.classList.add('rtl-layout');
    document.body.classList.remove('ltr-layout');
  } else {
    document.body.classList.add('ltr-layout');
    document.body.classList.remove('rtl-layout');
  }

  // Update all elements with data-i18n attribute
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.getAttribute('data-i18n');
    const translation = t(key);
    if (translation) {
      if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
        if (el.hasAttribute('placeholder')) {
          el.placeholder = translation;
        }
      } else {
        el.textContent = translation;
      }
    }
  });

  // Update elements with data-i18n-placeholder
  document.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
    const key = el.getAttribute('data-i18n-placeholder');
    const translation = t(key);
    if (translation) {
      el.placeholder = translation;
    }
  });

  // Update elements with data-i18n-title
  document.querySelectorAll('[data-i18n-title]').forEach(el => {
    const key = el.getAttribute('data-i18n-title');
    const translation = t(key);
    if (translation) {
      el.title = translation;
    }
  });

  // Dispatch custom event so other components can react
  window.dispatchEvent(new CustomEvent('languageChanged', { detail: { lang: currentLanguage, isRTL } }));
}

export function initLanguage() {
  const savedLang = localStorage.getItem('retinaxai_language') || 'en';
  setLanguage(savedLang);
}
