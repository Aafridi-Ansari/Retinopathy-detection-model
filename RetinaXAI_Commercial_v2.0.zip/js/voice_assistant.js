/**
 * voice_assistant.js - Arogya Netra Multilingual Voice Assistant & Interactive Clinical AI
 * Powered by Clinical Natural Language Processing (NLP) Engine (nlp_engine.js)
 * Features:
 *  - Strict Domain Guardrails ("Sorry, ask me about the disease only. I am trained for that only.")
 *  - Socratic Clinical Interviewing (Gemini-like interactive triage questioning)
 *  - High-Resolution Medical Image & Anatomical Diagram Generation inside Chat
 *  - Dynamic Quick-Response Chips & Web Speech Synthesis/Recognition
 */

import { t, getLanguage } from './i18n.js';
import { processMedicalNLPQuery } from './nlp_engine.js';

let recognition = null;
let isListening = false;

export function initVoiceAssistant() {
  setupSpeechRecognition();
  renderBotGreeting();
}

function setupSpeechRecognition() {
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SpeechRecognition) {
    console.warn('Speech Recognition API not supported in this browser.');
    return;
  }

  recognition = new SpeechRecognition();
  recognition.continuous = false;
  recognition.interimResults = false;

  recognition.onstart = () => {
    isListening = true;
    updateMicButtonUI(true);
  };

  recognition.onresult = (event) => {
    const transcript = event.results[0][0].transcript;
    const inputEl = document.getElementById('voice-chat-input');
    if (inputEl) {
      inputEl.value = transcript;
    }
    handleUserChatMessage(transcript);
  };

  recognition.onerror = (err) => {
    console.error('Speech recognition error:', err);
    isListening = false;
    updateMicButtonUI(false);
  };

  recognition.onend = () => {
    isListening = false;
    updateMicButtonUI(false);
  };
}

export function toggleVoiceListening() {
  if (!recognition) {
    alert('Voice input is not supported on this browser. Please type your question in the chat box.');
    return;
  }

  if (isListening) {
    recognition.stop();
  } else {
    const lang = getLanguage();
    const langMap = {
      en: 'en-US',
      hi: 'hi-IN',
      ne: 'ne-NP',
      ta: 'ta-IN',
      ar: 'ar-SA',
      ur: 'ur-PK'
    };
    recognition.lang = langMap[lang] || 'en-US';
    try {
      recognition.start();
    } catch (e) {
      console.warn('Recognition start exception:', e);
    }
  }
}

function updateMicButtonUI(listening) {
  const micBtn = document.getElementById('voice-mic-trigger');
  const listeningBadge = document.getElementById('mic-listening-indicator');
  
  if (micBtn) {
    if (listening) {
      micBtn.classList.add('bg-danger', 'animate-pulse', 'text-white');
      micBtn.classList.remove('bg-primary');
    } else {
      micBtn.classList.remove('bg-danger', 'animate-pulse', 'text-white');
      micBtn.classList.add('bg-primary');
    }
  }

  if (listeningBadge) {
    if (listening) {
      listeningBadge.classList.remove('hidden');
    } else {
      listeningBadge.classList.add('hidden');
    }
  }
}

export function speakText(text) {
  if (!('speechSynthesis' in window)) return;

  window.speechSynthesis.cancel();
  // Strip markdown, HTML, and extra symbols for natural speech
  const cleanSpeechText = text
    .replace(/<[^>]*>/g, '')
    .replace(/[*#_`]/g, '')
    .replace(/🚨|👁️|🌫️|🌓|🔴|🟡|🔵|✅|🩺|📱|🥗|👇/g, '')
    .trim();

  const utterance = new SpeechSynthesisUtterance(cleanSpeechText);
  const lang = getLanguage();
  const langMap = {
    en: 'en-US',
    hi: 'hi-IN',
    ne: 'ne-NP',
    ta: 'ta-IN',
    ar: 'ar-SA',
    ur: 'ur-PK'
  };
  utterance.lang = langMap[lang] || 'en-US';
  utterance.rate = 0.95;
  utterance.pitch = 1.0;

  window.speechSynthesis.speak(utterance);
}

export function stopSpeaking() {
  if ('speechSynthesis' in window) {
    window.speechSynthesis.cancel();
  }
}

export function handleUserChatMessage(userText) {
  const query = (userText || '').trim();
  if (!query) return;

  // Add User message bubble
  appendChatMessage(query, 'user');

  // Clear input box
  const inputEl = document.getElementById('voice-chat-input');
  if (inputEl) inputEl.value = '';

  // Process via Clinical NLP Engine
  setTimeout(() => {
    const nlpResult = processMedicalNLPQuery(query);
    appendChatMessage(nlpResult.reply, 'bot', nlpResult.diagram);

    // Update dynamic quick suggestion chips
    if (nlpResult.suggestedQuestions && nlpResult.suggestedQuestions.length > 0) {
      updateSuggestionChips(nlpResult.suggestedQuestions);
    }

    // Audio readout
    speakText(nlpResult.reply);
  }, 400);
}

function updateSuggestionChips(questions) {
  const chipsContainer = document.querySelector('#panel-voice .quick-inquiry-btn')?.parentElement;
  if (!chipsContainer) return;

  chipsContainer.innerHTML = questions.map(q => `
    <button type="button" class="quick-inquiry-btn text-[11px] whitespace-nowrap bg-surface hover:bg-surface-hover border border-theme text-secondary px-3 py-1 rounded-full font-medium transition-colors shadow-sm" data-query="${q}">
      ${q}
    </button>
  `).join('');

  // Re-bind click events
  chipsContainer.querySelectorAll('.quick-inquiry-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const q = btn.getAttribute('data-query');
      handleUserChatMessage(q);
    });
  });
}

export function appendChatMessage(text, sender, diagramHtml = '') {
  const container = document.getElementById('voice-chat-messages');
  if (!container) return;

  const isBot = sender === 'bot';
  const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  // Format simple markdown into bold and paragraphs
  const formattedContent = text
    .replace(/\n\n/g, '<br><br>')
    .replace(/\n/g, '<br>')
    .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');

  const messageHtml = `
    <div class="chat-message flex items-start gap-3 ${isBot ? '' : 'flex-row-reverse'} mb-4 animate-fade-in">
      <div class="w-9 h-9 rounded-full flex items-center justify-center shrink-0 ${
        isBot ? 'bg-primary text-white shadow-md' : 'bg-accent text-white shadow-md'
      }">
        <i class="fa-solid ${isBot ? 'fa-user-doctor' : 'fa-user'} text-sm"></i>
      </div>
      <div class="max-w-[85%]">
        <div class="p-4 rounded-2xl text-xs sm:text-sm leading-relaxed ${
          isBot 
            ? 'bg-surface border border-theme text-primary shadow-sm rounded-tl-sm' 
            : 'bg-primary text-white shadow-sm rounded-tr-sm'
        }">
          <div>${formattedContent}</div>
          ${diagramHtml ? `<div class="mt-2">${diagramHtml}</div>` : ''}
        </div>
        <div class="flex items-center gap-2 mt-1 px-1 text-[11px] text-muted ${isBot ? '' : 'justify-end'}">
          <span>${time}</span>
          ${isBot ? `
            <button type="button" onclick="window.replaySpeech('${encodeURIComponent(text)}')" class="hover:text-primary transition-colors inline-flex items-center gap-1">
              <i class="fa-solid fa-volume-high text-xs"></i>
              <span>Listen</span>
            </button>
          ` : ''}
        </div>
      </div>
    </div>
  `;

  container.insertAdjacentHTML('beforeend', messageHtml);
  container.scrollTop = container.scrollHeight;
}

export function renderBotGreeting() {
  const container = document.getElementById('voice-chat-messages');
  if (!container) return;

  container.innerHTML = '';
  // Start with Socratic Step 1 NLP Assessment
  const initialNLP = processMedicalNLPQuery('start assessment');
  appendChatMessage(initialNLP.reply, 'bot', initialNLP.diagram);

  if (initialNLP.suggestedQuestions) {
    updateSuggestionChips(initialNLP.suggestedQuestions);
  }
}

window.replaySpeech = function(encodedText) {
  const text = decodeURIComponent(encodedText);
  speakText(text);
};
