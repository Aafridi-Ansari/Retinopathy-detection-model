/**
 * auth.js - Enterprise Authentication & Role-Based Access Control
 * Supports: ASHA Worker, Ophthalmologist / Doctor, and Patient roles.
 * Integrates with the backend SQLite database API with offline session fallback.
 */

const STORAGE_USER_KEY = 'retinaxai_auth_user';
const STORAGE_TOKEN_KEY = 'retinaxai_auth_token';

// Predefined Demo Profiles for 1-Click Evaluation
export const DEMO_CREDENTIALS = {
  asha: {
    email: 'asha@retinaxai.org',
    password: 'asha123',
    role: 'asha_worker',
    fullName: 'Shanti Devi (ASHA)',
    district: 'Pindra PHC, Varanasi',
    badgeText: 'ASHA Health Worker',
    badgeClass: 'bg-emerald-500/10 text-emerald-600 border-emerald-500/30'
  },
  doctor: {
    email: 'dr.varma@aiims.edu',
    password: 'doctor123',
    role: 'doctor',
    fullName: 'Dr. Rajesh Varma, MS',
    district: 'AIIMS Apex Retina Dept',
    badgeText: 'Retinal Specialist / Doctor',
    badgeClass: 'bg-sky-500/10 text-sky-600 border-sky-500/30'
  },
  patient: {
    email: 'patient@retinaxai.org',
    password: 'patient123',
    role: 'patient',
    fullName: 'Rameshwar Devi',
    district: 'Varanasi District',
    badgeText: 'Registered Patient',
    badgeClass: 'bg-purple-500/10 text-purple-600 border-purple-500/30'
  }
};

let currentUser = null;
let currentToken = null;

export function initAuth() {
  const savedUser = localStorage.getItem(STORAGE_USER_KEY);
  const savedToken = localStorage.getItem(STORAGE_TOKEN_KEY);

  if (savedUser && savedToken) {
    try {
      currentUser = JSON.parse(savedUser);
      currentToken = savedToken;
    } catch (e) {
      logout();
    }
  } else {
    // Default to ASHA Worker demo session for immediate readiness
    loginWithDemo('asha');
  }

  updateAuthUI();
}

export function getCurrentUser() {
  return currentUser;
}

export function getAuthToken() {
  return currentToken;
}

export function isAuthenticated() {
  return Boolean(currentUser && currentToken);
}

export function isDoctor() {
  return currentUser?.role === 'doctor';
}

export function isAshaWorker() {
  return currentUser?.role === 'asha_worker';
}

export function isPatient() {
  return currentUser?.role === 'patient';
}

export async function login(email, password) {
  try {
    const response = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    });

    if (response.ok) {
      const data = await response.json();
      if (data.success && data.user) {
        setSession(data.user, data.user.token);
        return { success: true, user: data.user };
      }
    }
  } catch (err) {
    console.warn('API unavailable, falling back to local demo auth:', err);
  }

  // Offline / Demo fallback
  const demoMatch = Object.values(DEMO_CREDENTIALS).find(
    d => d.email.toLowerCase() === email.toLowerCase() && d.password === password
  );

  if (demoMatch) {
    const userObj = {
      id: `usr-${demoMatch.role}`,
      email: demoMatch.email,
      full_name: demoMatch.fullName,
      role: demoMatch.role,
      district: demoMatch.district
    };
    setSession(userObj, `local_token_${Date.now()}`);
    return { success: true, user: userObj };
  }

  return { success: false, error: 'Invalid email or password' };
}

export async function register(userData) {
  try {
    const response = await fetch('/api/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(userData)
    });

    if (response.ok) {
      const data = await response.json();
      if (data.success && data.user) {
        setSession(data.user, data.user.token);
        return { success: true, user: data.user };
      }
    }
  } catch (err) {
    console.warn('API register error, falling back locally:', err);
  }

  // Local fallback
  const userObj = {
    id: `usr-${Date.now()}`,
    email: userData.email,
    full_name: userData.full_name,
    role: userData.role || 'asha_worker',
    district: userData.district || 'Rural Center'
  };
  setSession(userObj, `local_token_${Date.now()}`);
  return { success: true, user: userObj };
}

export function loginWithDemo(roleKey) {
  const demo = DEMO_CREDENTIALS[roleKey] || DEMO_CREDENTIALS.asha;
  const userObj = {
    id: `usr-${demo.role}`,
    email: demo.email,
    full_name: demo.fullName,
    role: demo.role,
    district: demo.district
  };
  setSession(userObj, `demo_token_${roleKey}`);
  return userObj;
}

export function logout() {
  currentUser = null;
  currentToken = null;
  localStorage.removeItem(STORAGE_USER_KEY);
  localStorage.removeItem(STORAGE_TOKEN_KEY);
  updateAuthUI();
  window.dispatchEvent(new CustomEvent('authChanged', { detail: { user: null } }));
}

function setSession(user, token) {
  currentUser = user;
  currentToken = token;
  localStorage.setItem(STORAGE_USER_KEY, JSON.stringify(user));
  localStorage.setItem(STORAGE_TOKEN_KEY, token);
  updateAuthUI();
  window.dispatchEvent(new CustomEvent('authChanged', { detail: { user } }));
}

export function updateAuthUI() {
  const userNameEl = document.getElementById('auth-user-name');
  const userRoleEl = document.getElementById('auth-user-role');
  const userAvatarEl = document.getElementById('auth-user-avatar');
  const doctorOnlyElements = document.querySelectorAll('.doctor-only-view');
  const ashaOnlyElements = document.querySelectorAll('.asha-only-view');

  if (currentUser) {
    if (userNameEl) userNameEl.textContent = currentUser.full_name;
    if (userRoleEl) {
      const roleNames = {
        doctor: '👨‍⚕️ Retinal Specialist',
        asha_worker: '👩‍⚕️ ASHA Health Worker',
        patient: '👤 Patient'
      };
      userRoleEl.textContent = roleNames[currentUser.role] || currentUser.role;
    }
    if (userAvatarEl) {
      userAvatarEl.innerHTML = currentUser.role === 'doctor' 
        ? '<i class="fa-solid fa-user-doctor"></i>' 
        : currentUser.role === 'asha_worker'
        ? '<i class="fa-solid fa-user-nurse"></i>'
        : '<i class="fa-solid fa-user"></i>';
    }

    // Role visibility
    doctorOnlyElements.forEach(el => {
      el.classList.toggle('hidden', currentUser.role !== 'doctor');
    });
    ashaOnlyElements.forEach(el => {
      el.classList.toggle('hidden', currentUser.role === 'doctor');
    });
  }
}
