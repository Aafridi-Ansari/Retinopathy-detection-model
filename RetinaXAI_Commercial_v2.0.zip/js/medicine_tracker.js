/**
 * medicine_tracker.js - Patient Medication Adherence & Insulin Tracker
 * Allows rural health workers and patients to log medications, record daily doses,
 * calculate real-time adherence rates, and visualize compliance streaks.
 */

import { t } from './i18n.js';

const STORAGE_KEY = 'retinaxai_medicines_data';

// Default starter medications for diabetic patient demo
const INITIAL_MEDICINES = [
  {
    id: 'med-1',
    name: 'Metformin Hydrochloride',
    dosage: '500 mg',
    type: 'tablet',
    timing: 'afterMeal',
    frequency: { morning: true, afternoon: false, night: true },
    takenToday: { morning: true, afternoon: false, night: true },
    dateAdded: '2026-03-01'
  },
  {
    id: 'med-2',
    name: 'Glimepiride',
    dosage: '1 mg',
    type: 'tablet',
    timing: 'beforeMeal',
    frequency: { morning: true, afternoon: false, night: false },
    takenToday: { morning: true, afternoon: false, night: false },
    dateAdded: '2026-03-01'
  },
  {
    id: 'med-3',
    name: 'Insulin Glargine (Lantus)',
    dosage: '14 Units SubQ',
    type: 'insulin',
    timing: 'night',
    frequency: { morning: false, afternoon: false, night: true },
    takenToday: { morning: false, afternoon: false, night: false },
    dateAdded: '2026-03-05'
  },
  {
    id: 'med-4',
    name: 'Nepafenac 0.1% Ophthalmic Drops',
    dosage: '1 Drop Both Eyes',
    type: 'eyedrop',
    timing: 'afterMeal',
    frequency: { morning: true, afternoon: true, night: true },
    takenToday: { morning: true, afternoon: true, night: false },
    dateAdded: '2026-03-10'
  }
];

let medicines = [];

export function initMedicineTracker() {
  const saved = localStorage.getItem(STORAGE_KEY);
  if (saved) {
    try {
      medicines = JSON.parse(saved);
    } catch (e) {
      medicines = [...INITIAL_MEDICINES];
    }
  } else {
    medicines = [...INITIAL_MEDICINES];
    saveMedicines();
  }
  renderMedicineList();
  updateAdherenceStats();
}

export function saveMedicines() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(medicines));
}

export function getMedicines() {
  return medicines;
}

export function addMedicine(medData) {
  const newMed = {
    id: 'med-' + Date.now(),
    name: medData.name.trim(),
    dosage: medData.dosage.trim(),
    type: medData.type || 'tablet',
    timing: medData.timing || 'afterMeal',
    frequency: {
      morning: Boolean(medData.frequency?.morning),
      afternoon: Boolean(medData.frequency?.afternoon),
      night: Boolean(medData.frequency?.night)
    },
    takenToday: {
      morning: false,
      afternoon: false,
      night: false
    },
    dateAdded: new Date().toISOString().split('T')[0]
  };

  medicines.unshift(newMed);
  saveMedicines();
  renderMedicineList();
  updateAdherenceStats();
  return newMed;
}

export function removeMedicine(id) {
  medicines = medicines.filter(m => m.id !== id);
  saveMedicines();
  renderMedicineList();
  updateAdherenceStats();
}

export function toggleDoseTaken(id, slot) {
  const med = medicines.find(m => m.id === id);
  if (!med) return;

  if (med.frequency[slot]) {
    med.takenToday[slot] = !med.takenToday[slot];
    saveMedicines();
    renderMedicineList();
    updateAdherenceStats();
  }
}

/**
 * Calculates today's compliance score:
 * (Total Doses Taken Today) / (Total Doses Scheduled Today) * 100
 */
export function calculateAdherence() {
  let scheduledTotal = 0;
  let takenTotal = 0;

  medicines.forEach(m => {
    ['morning', 'afternoon', 'night'].forEach(slot => {
      if (m.frequency[slot]) {
        scheduledTotal++;
        if (m.takenToday[slot]) {
          takenTotal++;
        }
      }
    });
  });

  if (scheduledTotal === 0) {
    return { rate: 100, scheduledTotal: 0, takenTotal: 0, status: 'optimal' };
  }

  const rate = Math.round((takenTotal / scheduledTotal) * 100);
  let status = 'optimal';
  if (rate < 50) {
    status = 'low';
  } else if (rate < 85) {
    status = 'partial';
  }

  return { rate, scheduledTotal, takenTotal, status };
}

export function updateAdherenceStats() {
  const { rate, scheduledTotal, takenTotal, status } = calculateAdherence();

  const rateEl = document.getElementById('adherence-percentage-value');
  if (rateEl) rateEl.textContent = `${rate}%`;

  const barEl = document.getElementById('adherence-progress-bar');
  if (barEl) {
    barEl.style.width = `${rate}%`;
    barEl.className = `h-full rounded-full transition-all duration-500 ${
      status === 'optimal' ? 'bg-success' : status === 'partial' ? 'bg-warning' : 'bg-danger'
    }`;
  }

  const countEl = document.getElementById('adherence-fraction-display');
  if (countEl) {
    countEl.textContent = `${takenTotal} / ${scheduledTotal} doses taken today`;
  }

  const statusBadge = document.getElementById('adherence-status-badge');
  if (statusBadge) {
    if (status === 'optimal') {
      statusBadge.textContent = t('statusOptimal');
      statusBadge.className = 'px-3 py-1 rounded-full text-xs font-bold badge-success';
    } else if (status === 'partial') {
      statusBadge.textContent = t('statusPartial');
      statusBadge.className = 'px-3 py-1 rounded-full text-xs font-bold badge-warning';
    } else {
      statusBadge.textContent = t('statusLow');
      statusBadge.className = 'px-3 py-1 rounded-full text-xs font-bold badge-danger';
    }
  }
}

function getTypeIcon(type) {
  switch (type) {
    case 'insulin': return 'fa-syringe text-purple-500';
    case 'eyedrop': return 'fa-eye-dropper text-blue-500';
    case 'syrup': return 'fa-prescription-bottle text-amber-500';
    default: return 'fa-pills text-emerald-500';
  }
}

export function renderMedicineList() {
  const container = document.getElementById('medicine-items-container');
  if (!container) return;

  if (medicines.length === 0) {
    container.innerHTML = `
      <div class="text-center py-10 px-4 border-2 border-dashed border-theme rounded-2xl">
        <i class="fa-solid fa-pills text-4xl text-muted mb-3 opacity-60"></i>
        <p class="text-secondary text-sm" data-i18n="noMedicines">${t('noMedicines')}</p>
      </div>
    `;
    return;
  }

  container.innerHTML = medicines.map(med => {
    const iconClass = getTypeIcon(med.type);
    return `
      <div class="med-item-card bg-surface border border-theme rounded-2xl p-4 shadow-sm hover:border-primary/40 transition-all mb-3">
        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-3">
          <div class="flex items-start gap-3">
            <div class="w-10 h-10 rounded-xl bg-primary/10 border border-primary/20 flex items-center justify-center shrink-0">
              <i class="fa-solid ${iconClass} text-lg"></i>
            </div>
            <div>
              <h4 class="font-bold text-base text-primary">${med.name}</h4>
              <div class="flex items-center gap-2 mt-0.5 text-xs text-muted">
                <span class="font-semibold text-secondary">${med.dosage}</span>
                <span>•</span>
                <span class="capitalize">${med.type}</span>
                <span>•</span>
                <span class="text-accent font-medium">${t(med.timing) || med.timing}</span>
              </div>
            </div>
          </div>
          <button 
            type="button" 
            onclick="window.removeMedicineItem('${med.id}')" 
            class="text-xs text-danger hover:text-danger/80 p-1.5 rounded-lg hover:bg-danger/10 self-end sm:self-auto transition-colors"
            title="Remove medication"
          >
            <i class="fa-solid fa-trash-can me-1"></i>
            <span>${t('deleteMed')}</span>
          </button>
        </div>

        <!-- Dose Checkboxes for Today -->
        <div class="bg-surface-subtle p-3 rounded-xl border border-theme flex flex-wrap items-center justify-between gap-2">
          <span class="text-xs font-semibold text-muted uppercase tracking-wider">Today's Schedule:</span>
          <div class="flex items-center gap-3">
            ${renderSlotCheckbox(med, 'morning', 'Morning (AM)', 'fa-sun text-amber-500')}
            ${renderSlotCheckbox(med, 'afternoon', 'Noon (PM)', 'fa-cloud-sun text-orange-500')}
            ${renderSlotCheckbox(med, 'night', 'Night (PM)', 'fa-moon text-indigo-500')}
          </div>
        </div>
      </div>
    `;
  }).join('');
}

function renderSlotCheckbox(med, slot, label, icon) {
  const isScheduled = med.frequency[slot];
  if (!isScheduled) return '';

  const isTaken = med.takenToday[slot];
  return `
    <button 
      type="button"
      onclick="window.toggleMedicineDose('${med.id}', '${slot}')"
      class="dose-btn flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all ${
        isTaken 
          ? 'bg-success/15 text-success-text border-success/40 shadow-sm' 
          : 'bg-surface text-muted border-theme hover:border-primary/50'
      }"
    >
      <i class="fa-solid ${isTaken ? 'fa-circle-check text-success' : 'fa-circle-dot text-muted'}"></i>
      <i class="fa-solid ${icon} text-[10px]"></i>
      <span>${slot.charAt(0).toUpperCase() + slot.slice(1)}</span>
    </button>
  `;
}
