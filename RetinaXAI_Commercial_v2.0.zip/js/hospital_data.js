/**
 * hospital_data.js - Multi-Country Emergency Directory & Specialized Eye Hospitals
 * Provides emergency ambulance numbers, national helplines, tele-ophthalmology contacts,
 * and premier tertiary eye care centers by selected country.
 */

export const COUNTRY_DATA = {
  IN: {
    countryCode: 'IN',
    name: 'India',
    flag: '🇮🇳',
    ambulance: '108 / 102',
    ambulanceAlt: '112 (National Emergency Number)',
    helpline: '1075 (National Health Mission) / 104',
    teleOphthalmology: '1800-102-1200 (National Blindness Control Programme)',
    ruralSupport: 'ASHA Rural Community Health Link: Dial PHC / 104',
    hospitals: [
      {
        id: 'in-1',
        name: 'Aravind Eye Care System',
        region: 'Madurai / Coimbatore / Chennai, Tamil Nadu',
        address: '1, Anna Nagar, Madurai, Tamil Nadu 625020',
        phone: '+91 452 435 6100',
        emergencyPhone: '0452-4356100',
        rating: '4.9 ★★★★★',
        specialties: ['Diabetic Retinopathy', 'Vitreoretinal Surgery', 'Tele-Ophthalmology Rural Network'],
        services247: true,
        mapQuery: 'Aravind Eye Hospital Madurai'
      },
      {
        id: 'in-2',
        name: 'Sankara Nethralaya',
        region: 'Chennai, Tamil Nadu & Kolkata, West Bengal',
        address: 'No. 41/18, College Road, Nungambakkam, Chennai 600006',
        phone: '+91 44 4227 1500',
        emergencyPhone: '+91 44 4227 1800',
        rating: '4.8 ★★★★★',
        specialties: ['Retina & Vitreous Clinic', 'Macular Edema Laser Therapy', 'Mobile Eye Surgical Units'],
        services247: true,
        mapQuery: 'Sankara Nethralaya Chennai'
      },
      {
        id: 'in-3',
        name: 'L V Prasad Eye Institute (LVPEI)',
        region: 'Hyderabad, Telangana & Bhubaneswar, Odisha',
        address: 'Kallam Anji Reddy Campus, Banjara Hills, Hyderabad 500034',
        phone: '+91 40 6810 2020',
        emergencyPhone: '+91 40 3061 2345',
        rating: '4.9 ★★★★★',
        specialties: ['Vitreoretinal Diseases', 'Rural Secondary Eye Care Centers', 'Anti-VEGF Injections'],
        services247: true,
        mapQuery: 'LV Prasad Eye Institute Hyderabad'
      },
      {
        id: 'in-4',
        name: 'Dr. Rajendra Prasad Centre for Ophthalmic Sciences (AIIMS)',
        region: 'New Delhi, NCR',
        address: 'Ansari Nagar, New Delhi 110029',
        phone: '+91 11 2658 8500',
        emergencyPhone: '+91 11 2659 3101',
        rating: '4.8 ★★★★★',
        specialties: ['Apex Government Eye Center', 'Diabetic Retinopathy Screening', 'Subsidized Rural Referrals'],
        services247: true,
        mapQuery: 'Dr RP Centre AIIMS New Delhi'
      },
      {
        id: 'in-5',
        name: 'Dr. Shroff’s Charity Eye Hospital',
        region: 'Daryaganj, Delhi & Northern India Outreach',
        address: '5027, Kedar Nath Road, Daryaganj, New Delhi 110002',
        phone: '+91 11 4352 4444',
        emergencyPhone: '+91 11 4352 8888',
        rating: '4.7 ★★★★★',
        specialties: ['Community Eye Outreach', 'Rural Vision Centers', 'Retinal Laser Photocoagulation'],
        services247: true,
        mapQuery: 'Dr Shroff Charity Eye Hospital Delhi'
      }
    ]
  },

  NP: {
    countryCode: 'NP',
    name: 'Nepal',
    flag: '🇳🇵',
    ambulance: '102 (National Ambulance Service)',
    ambulanceAlt: '1144 (Traffic/Disaster Support) / 100 (Police)',
    helpline: '1115 (Ministry of Health and Population)',
    teleOphthalmology: '+977 1 4493775 (Tilganga Tele-Eye Health)',
    ruralSupport: 'FCHV (Female Community Health Volunteer) Network via Local Health Post',
    hospitals: [
      {
        id: 'np-1',
        name: 'Tilganga Institute of Ophthalmology',
        region: 'Kathmandu, Bagmati Province',
        address: 'Gaushala, Bagmati Bridge, Kathmandu 44600',
        phone: '+977 1 4493775',
        emergencyPhone: '+977 1 4493684',
        rating: '4.9 ★★★★★',
        specialties: ['WHO Collaborating Centre', 'Vitreoretinal Surgery', 'Remote Hilly Community Eye Clinics'],
        services247: true,
        mapQuery: 'Tilganga Institute of Ophthalmology Kathmandu'
      },
      {
        id: 'np-2',
        name: 'Nepal Eye Hospital (Tripureshwor)',
        region: 'Tripureshwor, Kathmandu',
        address: 'Tripureshwor, Kathmandu 44600',
        phone: '+977 1 4260813',
        emergencyPhone: '+977 1 4260813',
        rating: '4.7 ★★★★★',
        specialties: ['Oldest Eye Hospital in Nepal', 'Diabetic Retinopathy Diagnosis', 'Laser Therapy'],
        services247: true,
        mapQuery: 'Nepal Eye Hospital Tripureshwor Kathmandu'
      },
      {
        id: 'np-3',
        name: 'Lumbini Eye Institute & Research Center',
        region: 'Siddharthanagar, Bhairahawa, Lumbini Province',
        address: 'Bhairahawa, Siddharthanagar 32900',
        phone: '+977 71 520286',
        emergencyPhone: '+977 71 521406',
        rating: '4.8 ★★★★★',
        specialties: ['Western Terai Eye Care Leader', 'Diabetic Retinal Treatment', 'Cross-border Referral Hub'],
        services247: true,
        mapQuery: 'Lumbini Eye Institute Bhairahawa'
      },
      {
        id: 'np-4',
        name: 'Biratnagar Eye Hospital',
        region: 'Biratnagar, Koshi Province',
        address: 'Rani, Biratnagar 56613',
        phone: '+977 21 436358',
        emergencyPhone: '+977 21 436359',
        rating: '4.7 ★★★★★',
        specialties: ['Eastern Nepal High-Volume Retinal Center', 'Fundus Angiography', 'Camps for Remote Villages'],
        services247: true,
        mapQuery: 'Biratnagar Eye Hospital Rani'
      }
    ]
  },

  AE: {
    countryCode: 'AE',
    name: 'United Arab Emirates',
    flag: '🇦🇪',
    ambulance: '998 (National Ambulance)',
    ambulanceAlt: '999 (Police Emergency)',
    helpline: '800 342 (Dubai Health Authority) / 800 50 (DoH Abu Dhabi)',
    teleOphthalmology: '800-EYE-CARE (Moorfields Helpline)',
    ruralSupport: 'Mobile Health Units & Community Outreach Program',
    hospitals: [
      {
        id: 'ae-1',
        name: 'Moorfields Eye Hospital Dubai',
        region: 'Dubai Healthcare City, Dubai',
        address: 'Building 19, Al Razi Building, Dubai Healthcare City',
        phone: '+971 4 429 7888',
        emergencyPhone: '+971 4 429 7888',
        rating: '4.9 ★★★★★',
        specialties: ['Branch of Moorfields London', 'Diabetic Maculopathy', 'Advanced Vitreoretinal Surgery'],
        services247: true,
        mapQuery: 'Moorfields Eye Hospital Dubai Healthcare City'
      },
      {
        id: 'ae-2',
        name: 'Cleveland Clinic Abu Dhabi - Eye Institute',
        region: 'Al Maryah Island, Abu Dhabi',
        address: 'Al Maryah Island, Abu Dhabi',
        phone: '+971 2 659 0200',
        emergencyPhone: '+971 2 659 9999',
        rating: '4.9 ★★★★★',
        specialties: ['Specialized Retina Department', 'Intravitreal Anti-VEGF Injections', 'Diabetic Eye Monitoring'],
        services247: true,
        mapQuery: 'Cleveland Clinic Abu Dhabi Eye Institute'
      },
      {
        id: 'ae-3',
        name: 'Magrabi Eye & Ear Hospital Dubai',
        region: 'Dubai Festival City & Jumeirah',
        address: 'Dubai Festival City, Al Badia, Dubai',
        phone: '+971 4 236 6777',
        emergencyPhone: '+971 4 236 6777',
        rating: '4.7 ★★★★★',
        specialties: ['Diabetic Eye Center', 'Laser Photocoagulation', 'Fluorescein Retinal Angiography'],
        services247: true,
        mapQuery: 'Magrabi Eye Hospital Dubai Festival City'
      }
    ]
  },

  SA: {
    countryCode: 'SA',
    name: 'Saudi Arabia',
    flag: '🇸🇦',
    ambulance: '997 (Saudi Red Crescent)',
    ambulanceAlt: '911 (Unified Emergency Hotline)',
    helpline: '937 (Ministry of Health Emergency Consultation)',
    teleOphthalmology: '800-124-0012 (KKESH Tele-Eye Consultation)',
    ruralSupport: 'Seha Virtual Hospital (Tele-retina Rural Screening)',
    hospitals: [
      {
        id: 'sa-1',
        name: 'King Khaled Eye Specialist Hospital (KKESH)',
        region: 'Riyadh, Central Region',
        address: 'Umm Al Hamam Al Gharbi, Riyadh 12329',
        phone: '+966 11 482 1234',
        emergencyPhone: '+966 11 482 1234 Ext 3333',
        rating: '4.9 ★★★★★',
        specialties: ['Leading Tertiary Eye Hospital in Middle East', 'Vitreoretinal Surgery', 'Diabetic Retinopathy Registry'],
        services247: true,
        mapQuery: 'King Khaled Eye Specialist Hospital Riyadh'
      },
      {
        id: 'sa-2',
        name: 'Magrabi Eye Hospital Jeddah',
        region: 'Jeddah, Western Region',
        address: 'Madinah Road, Al Bawadi, Jeddah 21452',
        phone: '+966 12 665 5200',
        emergencyPhone: '+966 12 665 5200',
        rating: '4.8 ★★★★★',
        specialties: ['Pioneer Retinal Care Center', 'Diabetic Retinal Laser Treatment', 'OCT & Angiography Suite'],
        services247: true,
        mapQuery: 'Magrabi Eye Hospital Madinah Road Jeddah'
      },
      {
        id: 'sa-3',
        name: 'Dhahran Eye Specialist Hospital',
        region: 'Dhahran / Khobar, Eastern Province',
        address: 'Al Jamiah District, Dhahran 34455',
        phone: '+966 13 891 3000',
        emergencyPhone: '+966 13 891 3000',
        rating: '4.7 ★★★★★',
        specialties: ['Eastern Province Regional Eye Center', 'Diabetic Screening Clinics', 'Vitrectomy'],
        services247: true,
        mapQuery: 'Dhahran Eye Specialist Hospital'
      }
    ]
  },

  BD: {
    countryCode: 'BD',
    name: 'Bangladesh',
    flag: '🇧🇩',
    ambulance: '999 (National Emergency Service) / 199',
    ambulanceAlt: '16263 (Shastho Batayan National Health Line)',
    helpline: '16263 (Ministry of Health and Family Welfare)',
    teleOphthalmology: '+880 2 9118335 (National Eye Helpline)',
    ruralSupport: 'Community Clinic Linkage & Upazila Health Complex Care',
    hospitals: [
      {
        id: 'bd-1',
        name: 'National Institute of Ophthalmology & Hospital (NIO&H)',
        region: 'Sher-e-Bangla Nagar, Dhaka',
        address: 'Sher-e-Bangla Nagar, Agargaon, Dhaka 1207',
        phone: '+880 2 9118335',
        emergencyPhone: '+880 2 9118335',
        rating: '4.7 ★★★★★',
        specialties: ['Apex National Government Eye Center', 'Vitreoretinal Division', 'Rural Patient Subsidized Care'],
        services247: true,
        mapQuery: 'National Institute of Ophthalmology Agargaon Dhaka'
      },
      {
        id: 'bd-2',
        name: 'Ispahani Islamia Eye Institute and Hospital',
        region: 'Farmgate, Dhaka',
        address: 'Khamarbari Road, Farmgate, Dhaka 1215',
        phone: '+880 2 8141969',
        emergencyPhone: '+880 2 8141969',
        rating: '4.8 ★★★★★',
        specialties: ['High-Volume Retinal Laser Clinic', 'Mobile Rural Eye Outreach', 'Diabetic Retinopathy Care'],
        services247: true,
        mapQuery: 'Ispahani Islamia Eye Hospital Farmgate Dhaka'
      },
      {
        id: 'bd-3',
        name: 'Chittagong Eye Infirmary and Training Complex (CEITC)',
        region: 'Pahartali, Chittagong',
        address: 'Eye Hospital Road, Pahartali, Chittagong 4202',
        phone: '+880 31 659017',
        emergencyPhone: '+880 31 659017',
        rating: '4.7 ★★★★★',
        specialties: ['Leading Regional Eye Institute', 'Diabetic Eye Care', 'Tele-consultation with Rural Clinics'],
        services247: true,
        mapQuery: 'Chittagong Eye Infirmary Pahartali Chittagong'
      }
    ]
  }
};

let currentCountry = 'IN';

export function getSelectedCountry() {
  return currentCountry;
}

export function setSelectedCountry(countryCode) {
  if (COUNTRY_DATA[countryCode]) {
    currentCountry = countryCode;
    localStorage.setItem('retinaxai_country', countryCode);
    renderHospitals();
    return true;
  }
  return false;
}

export function initHospitalDirectory() {
  const savedCountry = localStorage.getItem('retinaxai_country') || 'IN';
  setSelectedCountry(savedCountry);
}

export function renderHospitals() {
  const data = COUNTRY_DATA[currentCountry] || COUNTRY_DATA['IN'];
  
  // Update Emergency Numbers in DOM
  const ambulanceEl = document.getElementById('ambulance-phone-display');
  if (ambulanceEl) ambulanceEl.textContent = data.ambulance;

  const ambulanceLink = document.getElementById('ambulance-call-btn');
  if (ambulanceLink) {
    const rawNumber = data.ambulance.split('/')[0].trim().replace(/\D/g, '');
    ambulanceLink.href = `tel:${rawNumber}`;
  }

  const helplineEl = document.getElementById('helpline-phone-display');
  if (helplineEl) helplineEl.textContent = data.helpline;

  const helplineLink = document.getElementById('helpline-call-btn');
  if (helplineLink) {
    const rawNumber = data.helpline.split('/')[0].trim().replace(/\D/g, '');
    helplineLink.href = `tel:${rawNumber}`;
  }

  const teleEl = document.getElementById('tele-phone-display');
  if (teleEl) teleEl.textContent = data.teleOphthalmology;

  const ruralEl = document.getElementById('rural-support-display');
  if (ruralEl) ruralEl.textContent = data.ruralSupport;

  // Render Hospital Cards
  const container = document.getElementById('hospital-cards-grid');
  if (!container) return;

  container.innerHTML = data.hospitals.map(hospital => `
    <div class="hospital-card bg-surface border border-theme rounded-2xl p-5 shadow-sm hover:shadow-md transition-all">
      <div class="flex items-start justify-between gap-3 mb-2">
        <div>
          <h4 class="font-bold text-lg text-primary flex items-center gap-2">
            <i class="fa-solid fa-hospital text-accent"></i>
            <span>${hospital.name}</span>
          </h4>
          <p class="text-xs text-muted font-medium mt-1">
            <i class="fa-solid fa-location-dot me-1 text-danger"></i>${hospital.region}
          </p>
        </div>
        <span class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold bg-warning/15 text-warning-text border border-warning/30 shrink-0">
          ${hospital.rating}
        </span>
      </div>

      <p class="text-xs text-secondary mb-3 mt-1 flex items-start gap-1.5">
        <i class="fa-solid fa-map-pin text-muted mt-0.5 shrink-0"></i>
        <span>${hospital.address}</span>
      </p>

      <div class="mb-4 flex flex-wrap gap-1.5">
        ${hospital.specialties.map(tag => `
          <span class="inline-block px-2 py-0.5 rounded-md text-[11px] font-medium bg-primary/10 text-primary border border-primary/20">
            ${tag}
          </span>
        `).join('')}
      </div>

      <div class="pt-3 border-t border-theme flex items-center justify-between gap-2">
        <a href="tel:${hospital.phone.replace(/[^0-9+]/g, '')}" class="btn-sm btn-primary inline-flex items-center gap-1.5 text-xs">
          <i class="fa-solid fa-phone"></i>
          <span>Call: ${hospital.phone}</span>
        </a>
        <a href="https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(hospital.mapQuery)}" target="_blank" rel="noopener noreferrer" class="btn-sm btn-secondary inline-flex items-center gap-1.5 text-xs">
          <i class="fa-solid fa-arrow-up-right-from-square"></i>
          <span>Directions</span>
        </a>
      </div>
    </div>
  `).join('');
}
