/**
 * app.js - Main Application Orchestrator for RetinaXAI
 * Initializes themes, localization, multi-role auth, SQLite database sync,
 * XAI engine, medicine tracker, voice assistant, and analytics tele-triage.
 */

import { initLanguage, setLanguage, getLanguage, applyLanguageToDOM, t, LANGUAGES } from './i18n.js';
import { 
  initAuth, 
  login, 
  register, 
  loginWithDemo, 
  logout, 
  getCurrentUser, 
  isDoctor, 
  isAshaWorker, 
  isPatient 
} from './auth.js';
import { 
  checkBackendHealth, 
  fetchPatients, 
  savePatient, 
  fetchScreenings, 
  saveScreening, 
  signScreeningByDoctor, 
  fetchDashboardStats 
} from './db_client.js';
import { 
  initXaiEngine, 
  loadSampleScan, 
  handleFundusImageUpload, 
  setViewLayer, 
  setHeatmapOpacity, 
  getCurrentAnalysis,
  renderRetinaCanvas,
  updateAnalysisResultsUI
} from './xai_engine.js';
import { 
  initMedicineTracker, 
  addMedicine, 
  removeMedicine, 
  toggleDoseTaken, 
  renderMedicineList 
} from './medicine_tracker.js';
import { 
  initHospitalDirectory, 
  setSelectedCountry, 
  getSelectedCountry, 
  COUNTRY_DATA 
} from './hospital_data.js';
import { 
  initVoiceAssistant, 
  toggleVoiceListening, 
  handleUserChatMessage, 
  renderBotGreeting,
  speakText
} from './voice_assistant.js';

// Global window bindings for inline HTML handlers
window.removeMedicineItem = (id) => removeMedicine(id);
window.toggleMedicineDose = (id, slot) => toggleDoseTaken(id, slot);

// Default patient profile record
const DEFAULT_PATIENT_PROFILE = {
  fullName: 'Rameshwar Devi',
  age: '54',
  gender: 'female',
  diabetesType: 'type2',
  durationYears: '9',
  hba1c: '9.2',
  bloodPressure: '142/90',
  healthWorkerId: 'ASHA-UP-VNS-042',
  districtVillage: 'Pindra PHC, Varanasi, Uttar Pradesh',
  phone: '+91 98765 43210'
};

document.addEventListener('DOMContentLoaded', () => {
  initTheme();
  initLanguage();
  initAuth();
  initHospitalDirectory();
  initPatientProfile();
  initMedicineTracker();
  initXaiEngine();
  initVoiceAssistant();
  bindUIEvents();
  renderRetinaCanvas();

  // Check backend health & sync status
  checkBackendHealth();
  setInterval(checkBackendHealth, 15000);

  // Load initial analytics stats
  loadAndRenderAnalytics();
});

/* -------------------------------------------------------------------------- */
/* THEME MANAGEMENT (Dark / Light Mode)                                      */
/* -------------------------------------------------------------------------- */
function initTheme() {
  const savedTheme = localStorage.getItem('retinaxai_theme') || 'light';
  applyTheme(savedTheme);

  const themeToggleBtn = document.getElementById('theme-toggle-btn');
  if (themeToggleBtn) {
    themeToggleBtn.addEventListener('click', () => {
      const current = document.documentElement.getAttribute('data-theme') || 'light';
      const nextTheme = current === 'dark' ? 'light' : 'dark';
      applyTheme(nextTheme);
    });
  }
}

function applyTheme(theme) {
  document.documentElement.setAttribute('data-theme', theme);
  localStorage.setItem('retinaxai_theme', theme);

  const icon = document.getElementById('theme-toggle-icon');
  const text = document.getElementById('theme-toggle-text');

  if (icon) {
    icon.className = theme === 'dark' ? 'fa-solid fa-sun text-warning' : 'fa-solid fa-moon text-indigo-500';
  }
  if (text) {
    text.textContent = theme === 'dark' ? t('lightMode') : t('darkMode');
  }

  // Redraw canvas with theme updates if needed
  renderRetinaCanvas();
}

/* -------------------------------------------------------------------------- */
/* TAB NAVIGATION                                                             */
/* -------------------------------------------------------------------------- */
function setupTabNavigation() {
  const tabButtons = document.querySelectorAll('.nav-tab-btn');
  const tabPanels = document.querySelectorAll('.tab-panel');

  tabButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      const targetId = btn.getAttribute('data-tab');

      tabButtons.forEach(b => b.classList.remove('active'));
      tabPanels.forEach(p => p.classList.add('hidden'));

      btn.classList.add('active');
      const activePanel = document.getElementById(targetId);
      if (activePanel) {
        activePanel.classList.remove('hidden');
      }

      // Refresh canvas or stats on tab change
      if (targetId === 'panel-screening') {
        setTimeout(() => renderRetinaCanvas(), 50);
      } else if (targetId === 'panel-analytics') {
        loadAndRenderAnalytics();
      }
    });
  });
}

/* -------------------------------------------------------------------------- */
/* PATIENT PROFILE MANAGEMENT                                                 */
/* -------------------------------------------------------------------------- */
function initPatientProfile() {
  const savedProfile = localStorage.getItem('retinaxai_patient_profile');
  let profile = DEFAULT_PATIENT_PROFILE;

  if (savedProfile) {
    try {
      profile = { ...DEFAULT_PATIENT_PROFILE, ...JSON.parse(savedProfile) };
    } catch (e) {
      profile = DEFAULT_PATIENT_PROFILE;
    }
  }

  // Populate Profile Form fields
  const setVal = (id, val) => {
    const el = document.getElementById(id);
    if (el) el.value = val || '';
  };

  setVal('profile-fullname', profile.fullName);
  setVal('profile-age', profile.age);
  setVal('profile-gender', profile.gender);
  setVal('profile-diabetes-type', profile.diabetesType);
  setVal('profile-duration', profile.durationYears);
  setVal('profile-hba1c', profile.hba1c);
  setVal('profile-bp', profile.bloodPressure);
  setVal('profile-worker-id', profile.healthWorkerId);
  setVal('profile-village', profile.districtVillage);
  setVal('profile-phone', profile.phone);

  // Update header patient badge
  updatePatientHeaderBadge(profile);

  // Save profile form submission
  const profileForm = document.getElementById('patient-profile-form');
  if (profileForm) {
    profileForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const updatedProfile = {
        fullName: document.getElementById('profile-fullname')?.value || '',
        age: document.getElementById('profile-age')?.value || '',
        gender: document.getElementById('profile-gender')?.value || 'female',
        diabetesType: document.getElementById('profile-diabetes-type')?.value || 'type2',
        durationYears: document.getElementById('profile-duration')?.value || '',
        hba1c: document.getElementById('profile-hba1c')?.value || '',
        bloodPressure: document.getElementById('profile-bp')?.value || '',
        healthWorkerId: document.getElementById('profile-worker-id')?.value || '',
        districtVillage: document.getElementById('profile-village')?.value || '',
        phone: document.getElementById('profile-phone')?.value || ''
      };

      localStorage.setItem('retinaxai_patient_profile', JSON.stringify(updatedProfile));
      updatePatientHeaderBadge(updatedProfile);

      // Also persist to SQLite backend
      await savePatient({
        full_name: updatedProfile.fullName,
        age: updatedProfile.age,
        gender: updatedProfile.gender,
        diabetes_type: updatedProfile.diabetesType,
        duration_years: updatedProfile.durationYears,
        hba1c: updatedProfile.hba1c,
        blood_pressure: updatedProfile.bloodPressure,
        district_village: updatedProfile.districtVillage,
        phone: updatedProfile.phone
      });

      showToast(t('profileSaved') || 'Patient profile successfully saved to SQLite Database!');
    });
  }
}

function updatePatientHeaderBadge(profile) {
  const badgeName = document.getElementById('header-patient-name');
  const badgeDetails = document.getElementById('header-patient-details');

  if (badgeName) badgeName.textContent = profile.fullName;
  if (badgeDetails) {
    badgeDetails.textContent = `${profile.age} yrs • HbA1c ${profile.hba1c}% • ${profile.districtVillage.split(',')[0]}`;
  }
}

export function getPatientProfile() {
  const saved = localStorage.getItem('retinaxai_patient_profile');
  if (saved) {
    try {
      return JSON.parse(saved);
    } catch (e) {
      return DEFAULT_PATIENT_PROFILE;
    }
  }
  return DEFAULT_PATIENT_PROFILE;
}

/* -------------------------------------------------------------------------- */
/* UI EVENT BINDINGS                                                          */
/* -------------------------------------------------------------------------- */
function bindUIEvents() {
  setupTabNavigation();

  // Authentication & Portal Modal Controls
  const openLoginBtn = document.getElementById('open-login-modal-btn');
  const closeLoginBtn = document.getElementById('close-login-modal-btn');
  const loginModal = document.getElementById('login-modal');
  const logoutBtn = document.getElementById('auth-logout-btn');

  if (openLoginBtn && loginModal) {
    openLoginBtn.addEventListener('click', () => loginModal.classList.remove('hidden'));
  }
  if (closeLoginBtn && loginModal) {
    closeLoginBtn.addEventListener('click', () => loginModal.classList.add('hidden'));
  }
  if (logoutBtn) {
    logoutBtn.addEventListener('click', () => {
      logout();
      showToast('Logged out successfully. Redirecting to portal...');
      setTimeout(() => {
        window.location.href = 'login.html';
      }, 500);
    });
  }

  // 1-Click Demo Login Buttons for Judges
  document.querySelectorAll('.demo-login-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const role = btn.getAttribute('data-role');
      const user = loginWithDemo(role);
      loginModal.classList.add('hidden');
      showToast(`Switched to Demo Session: ${user.full_name} (${user.role.toUpperCase()})`);
    });
  });

  // Auth Tabs (Sign In vs Register)
  const tabSignin = document.getElementById('auth-tab-signin');
  const tabSignup = document.getElementById('auth-tab-signup');
  const formSignin = document.getElementById('signin-form');
  const formSignup = document.getElementById('signup-form');

  if (tabSignin && tabSignup && formSignin && formSignup) {
    tabSignin.addEventListener('click', () => {
      tabSignin.className = 'flex-1 pb-2 font-bold text-xs text-primary border-b-2 border-primary';
      tabSignup.className = 'flex-1 pb-2 font-bold text-xs text-muted border-b-2 border-transparent';
      formSignin.classList.remove('hidden');
      formSignup.classList.add('hidden');
    });

    tabSignup.addEventListener('click', () => {
      tabSignup.className = 'flex-1 pb-2 font-bold text-xs text-primary border-b-2 border-primary';
      tabSignin.className = 'flex-1 pb-2 font-bold text-xs text-muted border-b-2 border-transparent';
      formSignup.classList.remove('hidden');
      formSignin.classList.add('hidden');
    });

    formSignin.addEventListener('submit', async (e) => {
      e.preventDefault();
      const email = document.getElementById('signin-email')?.value || '';
      const password = document.getElementById('signin-password')?.value || '';
      const res = await login(email, password);
      if (res.success) {
        loginModal.classList.add('hidden');
        showToast(`Welcome, ${res.user.full_name}!`);
      } else {
        alert(res.error || 'Login failed. Please check credentials.');
      }
    });

    formSignup.addEventListener('submit', async (e) => {
      e.preventDefault();
      const userData = {
        full_name: document.getElementById('signup-name')?.value || '',
        email: document.getElementById('signup-email')?.value || '',
        role: document.getElementById('signup-role')?.value || 'asha_worker',
        district: document.getElementById('signup-district')?.value || '',
        password: document.getElementById('signup-password')?.value || ''
      };
      const res = await register(userData);
      if (res.success) {
        loginModal.classList.add('hidden');
        showToast(`Account registered and logged in as ${res.user.full_name}!`);
      } else {
        alert(res.error || 'Registration failed.');
      }
    });
  }

  // Save Screening to Database Button
  const saveScreeningBtn = document.getElementById('save-screening-db-btn');
  if (saveScreeningBtn) {
    saveScreeningBtn.addEventListener('click', async () => {
      const analysis = getCurrentAnalysis();
      const profile = getPatientProfile();
      saveScreeningBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i><span>Saving...</span>';

      await saveScreening({
        patient_id: 'pat-1001',
        stage: analysis.stage,
        grade_name: analysis.gradeName,
        confidence: analysis.confidence,
        risk: analysis.risk,
        biomarkers: analysis.biomarkers,
        explanation: analysis.explanation[getLanguage()] || analysis.explanation.en,
        recommendation: analysis.recommendation[getLanguage()] || analysis.recommendation.en,
        doctor_signature: analysis.doctorSignature || null
      });

      saveScreeningBtn.innerHTML = '<i class="fa-solid fa-cloud-arrow-up text-accent"></i><span>Saved!</span>';
      setTimeout(() => {
        saveScreeningBtn.innerHTML = '<i class="fa-solid fa-cloud-arrow-up text-accent"></i><span>Save to Database</span>';
      }, 2000);

      showToast('Clinical screening record persisted to SQLite Database!');
      loadAndRenderAnalytics();
    });
  }

  // Doctor Review & Digital Signature Modal
  const docSignBtn = document.getElementById('doctor-sign-btn');
  const docSignModal = document.getElementById('doctor-sign-modal');
  const closeDocSignModal = document.getElementById('close-doc-sign-modal');
  const cancelDocSign = document.getElementById('cancel-doc-sign');
  const docSignForm = document.getElementById('doctor-sign-form');

  if (docSignBtn && docSignModal) {
    docSignBtn.addEventListener('click', () => {
      const user = getCurrentUser();
      const docNameEl = document.getElementById('doc-sign-doctor-name');
      if (docNameEl && user) {
        docNameEl.textContent = `${user.full_name} (${user.district || 'Ophthalmology Dept'})`;
      }
      docSignModal.classList.remove('hidden');
    });
  }

  if (closeDocSignModal && docSignModal) {
    closeDocSignModal.addEventListener('click', () => docSignModal.classList.add('hidden'));
  }
  if (cancelDocSign && docSignModal) {
    cancelDocSign.addEventListener('click', () => docSignModal.classList.add('hidden'));
  }

  if (docSignForm) {
    docSignForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const user = getCurrentUser();
      const notes = document.getElementById('doc-clinical-notes')?.value || 'Validated by specialist.';
      const stamp = `Verified by ${user?.full_name || 'Dr. Rajesh Varma, MS (AIIMS)'} [Seal: #MCI-RET-94281]`;

      const analysis = getCurrentAnalysis();
      analysis.doctorSignature = stamp;
      analysis.doctorNotes = notes;

      docSignModal.classList.add('hidden');
      showToast('Doctor Digital Signature affixed to medical report.');

      // Persist signature to DB
      await signScreeningByDoctor('scr-2001', stamp, notes);
      loadAndRenderAnalytics();
    });
  }

  // Refresh Analytics Button
  const refreshAnalyticsBtn = document.getElementById('refresh-analytics-btn');
  if (refreshAnalyticsBtn) {
    refreshAnalyticsBtn.addEventListener('click', () => {
      loadAndRenderAnalytics();
      showToast('Analytics & Triage Queue refreshed.');
    });
  }

  // Language Selector
  const langSelect = document.getElementById('language-selector');
  if (langSelect) {
    langSelect.value = getLanguage();
    langSelect.addEventListener('change', (e) => {
      setLanguage(e.target.value);
      updateAnalysisResultsUI();
      renderMedicineList();
      renderBotGreeting();
    });
  }

  // Country Selector
  const countrySelect = document.getElementById('country-selector');
  if (countrySelect) {
    countrySelect.value = getSelectedCountry();
    countrySelect.addEventListener('change', (e) => {
      setSelectedCountry(e.target.value);
    });
  }

  // Sample Scan Selector Buttons
  const sampleButtons = document.querySelectorAll('.sample-scan-btn');
  sampleButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      const sampleKey = btn.getAttribute('data-sample');
      sampleButtons.forEach(b => b.classList.remove('active-sample', 'ring-2', 'ring-primary'));
      btn.classList.add('active-sample', 'ring-2', 'ring-primary');

      // Visual scanline feedback
      triggerScanAnimation();
      loadSampleScan(sampleKey);
    });
  });

  // File Upload Handling
  const fileInput = document.getElementById('fundus-file-input');
  const dropZone = document.getElementById('fundus-dropzone');

  if (fileInput) {
    fileInput.addEventListener('change', (e) => {
      if (e.target.files && e.target.files[0]) {
        triggerScanAnimation();
        handleFundusImageUpload(e.target.files[0]);
      }
    });
  }

  if (dropZone) {
    ['dragenter', 'dragover'].forEach(eventName => {
      dropZone.addEventListener(eventName, (e) => {
        e.preventDefault();
        dropZone.classList.add('border-primary', 'bg-primary/5');
      });
    });

    ['dragleave', 'drop'].forEach(eventName => {
      dropZone.addEventListener(eventName, (e) => {
        e.preventDefault();
        dropZone.classList.remove('border-primary', 'bg-primary/5');
      });
    });

    dropZone.addEventListener('drop', (e) => {
      if (e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0]) {
        triggerScanAnimation();
        handleFundusImageUpload(e.dataTransfer.files[0]);
      }
    });
  }

  // Visualization Layer Buttons
  const layerButtons = document.querySelectorAll('.layer-btn');
  layerButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      const layer = btn.getAttribute('data-layer');
      layerButtons.forEach(b => b.classList.remove('active', 'bg-primary', 'text-white'));
      btn.classList.add('active', 'bg-primary', 'text-white');
      setViewLayer(layer);
    });
  });

  // Heatmap Opacity Slider
  const opacitySlider = document.getElementById('heatmap-opacity-slider');
  const opacityDisplay = document.getElementById('heatmap-opacity-display');
  if (opacitySlider) {
    opacitySlider.addEventListener('input', (e) => {
      const val = parseFloat(e.target.value);
      if (opacityDisplay) opacityDisplay.textContent = `${Math.round(val * 100)}%`;
      setHeatmapOpacity(val);
    });
  }

  // Voice Assistant Mic & Input
  const micBtn = document.getElementById('voice-mic-trigger');
  if (micBtn) {
    micBtn.addEventListener('click', () => {
      toggleVoiceListening();
    });
  }

  const voiceForm = document.getElementById('voice-chat-form');
  const voiceInput = document.getElementById('voice-chat-input');
  if (voiceForm && voiceInput) {
    voiceForm.addEventListener('submit', (e) => {
      e.preventDefault();
      handleUserChatMessage(voiceInput.value);
    });
  }

  // Quick Inquiries Chips
  const inquiryChips = document.querySelectorAll('.quick-inquiry-btn');
  inquiryChips.forEach(chip => {
    chip.addEventListener('click', () => {
      const query = chip.getAttribute('data-query') || chip.textContent.trim();
      handleUserChatMessage(query);
    });
  });

  // Add Medicine Form
  const addMedForm = document.getElementById('add-medicine-form');
  if (addMedForm) {
    addMedForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const name = document.getElementById('med-name-input')?.value || '';
      const dosage = document.getElementById('med-dosage-input')?.value || '';
      const type = document.getElementById('med-type-input')?.value || 'tablet';
      const timing = document.getElementById('med-timing-input')?.value || 'afterMeal';

      const freqMorning = document.getElementById('med-slot-morning')?.checked || false;
      const freqNoon = document.getElementById('med-slot-afternoon')?.checked || false;
      const freqNight = document.getElementById('med-slot-night')?.checked || false;

      if (!name.trim()) return;

      addMedicine({
        name,
        dosage,
        type,
        timing,
        frequency: {
          morning: freqMorning,
          afternoon: freqNoon,
          night: freqNight
        }
      });

      // Reset form
      addMedForm.reset();
      showToast('Medication added successfully to Tracker & Database!');
      // Close modal
      const modal = document.getElementById('add-medicine-modal');
      if (modal) modal.classList.add('hidden');
    });
  }

  // Modal Open / Close buttons
  const openMedModalBtn = document.getElementById('open-add-med-modal');
  const closeMedModalBtn = document.getElementById('close-med-modal');
  const medModal = document.getElementById('add-medicine-modal');

  if (openMedModalBtn && medModal) {
    openMedModalBtn.addEventListener('click', () => medModal.classList.remove('hidden'));
  }
  if (closeMedModalBtn && medModal) {
    closeMedModalBtn.addEventListener('click', () => medModal.classList.add('hidden'));
  }

  // Report Generation & WhatsApp Sharing
  const printReportBtn = document.getElementById('print-report-btn');
  if (printReportBtn) {
    printReportBtn.addEventListener('click', () => {
      openReportModal();
    });
  }

  const shareWhatsAppBtn = document.getElementById('share-whatsapp-btn');
  if (shareWhatsAppBtn) {
    shareWhatsAppBtn.addEventListener('click', () => {
      shareReportViaWhatsApp();
    });
  }

  // Listen to custom events
  window.addEventListener('languageChanged', () => {
    updateAnalysisResultsUI();
    renderRetinaCanvas();
  });

  window.addEventListener('authChanged', () => {
    updateAnalysisResultsUI();
  });
}

function triggerScanAnimation() {
  const scanLine = document.getElementById('retina-scan-animation');
  if (scanLine) {
    scanLine.classList.remove('hidden');
    setTimeout(() => {
      scanLine.classList.add('hidden');
    }, 2400);
  }
}

/* -------------------------------------------------------------------------- */
/* ANALYTICS & TELE-TRIAGE DATA LOADER                                        */
/* -------------------------------------------------------------------------- */
async function loadAndRenderAnalytics() {
  const stats = await fetchDashboardStats();
  if (!stats) return;

  const setEl = (id, val) => {
    const el = document.getElementById(id);
    if (el) el.textContent = val;
  };

  setEl('kpi-total-screenings', stats.totalScreenings);
  setEl('kpi-high-risk', stats.highRiskIdentified);
  setEl('kpi-rural-reach', `${stats.villagesCovered} Villages`);
  setEl('kpi-adherence', stats.adherenceAverage);

  // Render Tele-Triage Table
  const tableBody = document.getElementById('tele-triage-table-body');
  if (!tableBody) return;

  const screenings = await fetchScreenings();
  const sampleTriageQueue = screenings.length > 0 ? screenings : [
    {
      patient_name: 'Rameshwar Devi',
      age: 54,
      district_village: 'Pindra Village, Varanasi',
      grade_name: 'ICDR Grade 2 - Moderate NPDR',
      risk: 'High Risk',
      doctor_signature: 'Verified by Dr. Rajesh Varma (AIIMS)',
      status: 'verified_by_doctor'
    },
    {
      patient_name: 'Maheshwar Prasad',
      age: 62,
      district_village: 'Cholapur Sub-Center, UP',
      grade_name: 'ICDR Grade 3 - Severe NPDR',
      risk: 'Critical',
      doctor_signature: null,
      status: 'pending_review'
    },
    {
      patient_name: 'Sushila Kumari',
      age: 49,
      district_village: 'Kashi Rural PHC, UP',
      grade_name: 'ICDR Grade 4 - Proliferative DR',
      risk: 'Critical Emergency',
      doctor_signature: null,
      status: 'pending_review'
    },
    {
      patient_name: 'Abdul Rehman',
      age: 58,
      district_village: 'Sewapuri District, UP',
      grade_name: 'ICDR Grade 1 - Mild NPDR',
      risk: 'Moderate',
      doctor_signature: 'Verified by Dr. Rajesh Varma',
      status: 'verified_by_doctor'
    }
  ];

  tableBody.innerHTML = sampleTriageQueue.map(item => `
    <tr class="hover:bg-surface-subtle transition-colors">
      <td class="p-3 font-bold text-primary">${item.patient_name || 'Patient'}</td>
      <td class="p-3 text-secondary">${item.age || 50} Y / Female</td>
      <td class="p-3 text-muted truncate max-w-[140px]">${item.district_village || 'Rural Center'}</td>
      <td class="p-3 font-bold text-primary">${item.grade_name || 'ICDR Grade 2'}</td>
      <td class="p-3">
        <span class="px-2 py-0.5 rounded-full text-[10px] font-bold ${
          item.risk?.toLowerCase().includes('critical') ? 'badge-danger' : 'badge-warning'
        }">
          ${item.risk || 'High Risk'}
        </span>
      </td>
      <td class="p-3">
        ${item.doctor_signature 
          ? '<span class="text-emerald-600 font-bold text-[11px] flex items-center gap-1"><i class="fa-solid fa-circle-check"></i> Verified</span>'
          : '<span class="text-amber-600 font-bold text-[11px] flex items-center gap-1"><i class="fa-solid fa-clock"></i> Pending</span>'
        }
      </td>
      <td class="p-3 text-right">
        <button type="button" onclick="window.reviewTriageCase('${item.grade_name || 'moderate'}')" class="btn-sm btn-secondary text-[11px] font-bold">
          Review XAI
        </button>
      </td>
    </tr>
  `).join('');
}

window.reviewTriageCase = function(gradeName) {
  // Jump to screening tab and load corresponding sample
  const screeningTabBtn = document.querySelector('[data-tab="panel-screening"]');
  if (screeningTabBtn) screeningTabBtn.click();
  
  if (gradeName.includes('3') || gradeName.toLowerCase().includes('severe')) {
    loadSampleScan('severe');
  } else if (gradeName.includes('4') || gradeName.toLowerCase().includes('proliferative')) {
    loadSampleScan('pdr');
  } else if (gradeName.includes('1') || gradeName.toLowerCase().includes('mild')) {
    loadSampleScan('mild');
  } else {
    loadSampleScan('moderate');
  }
};

/* -------------------------------------------------------------------------- */
/* MEDICAL REPORT & TELE-REFERRAL EXPORT                                      */
/* -------------------------------------------------------------------------- */
function openReportModal() {
  const profile = getPatientProfile();
  const analysis = getCurrentAnalysis();
  const country = COUNTRY_DATA[getSelectedCountry()] || COUNTRY_DATA['IN'];
  const user = getCurrentUser();

  // Fill in report modal fields
  const setEl = (id, text) => {
    const el = document.getElementById(id);
    if (el) el.textContent = text;
  };

  setEl('rep-patient-name', profile.fullName);
  setEl('rep-patient-age-gender', `${profile.age} Years • ${profile.gender.toUpperCase()}`);
  setEl('rep-patient-diabetes', `${profile.diabetesType.toUpperCase()} (${profile.durationYears} Years Duration)`);
  setEl('rep-patient-hba1c', `${profile.hba1c}%`);
  setEl('rep-patient-bp', profile.bloodPressure);
  setEl('rep-health-worker', `${profile.healthWorkerId} (${user?.full_name || 'ASHA Certified'})`);
  setEl('rep-district-village', profile.districtVillage);
  setEl('rep-report-date', new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }));

  setEl('rep-diagnosis-grade', analysis.gradeName);
  setEl('rep-confidence-score', `${analysis.confidence}%`);
  setEl('rep-clinical-risk', analysis.risk);
  setEl('rep-explanation', analysis.explanation[getLanguage()] || analysis.explanation.en);
  setEl('rep-recommendation', analysis.recommendation[getLanguage()] || analysis.recommendation.en);
  setEl('rep-hospital-referral', `${country.hospitals[0]?.name} (${country.hospitals[0]?.region})`);
  setEl('rep-ambulance-call', country.ambulance);

  // Copy retina canvas snapshot into report image
  const canvas = document.getElementById('retina-canvas');
  const reportImg = document.getElementById('rep-retina-image');
  if (canvas && reportImg) {
    reportImg.src = canvas.toDataURL('image/png');
  }

  const modal = document.getElementById('report-modal');
  if (modal) modal.classList.remove('hidden');
}

window.closeReportModal = function() {
  const modal = document.getElementById('report-modal');
  if (modal) modal.classList.add('hidden');
};

window.triggerPrintDialog = function() {
  window.print();
};

function shareReportViaWhatsApp() {
  const profile = getPatientProfile();
  const analysis = getCurrentAnalysis();
  const country = COUNTRY_DATA[getSelectedCountry()] || COUNTRY_DATA['IN'];

  const message = `*RetinaXAI: Tele-Ophthalmology Referral Slip*
----------------------------------------
*Patient:* ${profile.fullName} (${profile.age} Y / ${profile.gender.toUpperCase()})
*Location:* ${profile.districtVillage}
*ASHA ID:* ${profile.healthWorkerId}
*HbA1c:* ${profile.hba1c}% | *BP:* ${profile.bloodPressure}
----------------------------------------
*AI Diagnosis:* ${analysis.gradeName}
*Confidence:* ${analysis.confidence}%
*Risk Category:* ${analysis.risk.toUpperCase()}
*Action Required:* ${analysis.actionType === 'urgent' ? '🚨 URGENT EMERGENCY REFERRAL' : 'Routine Specialist Follow-up'}
*Nearest Center:* ${country.hospitals[0]?.name}
*Ambulance Hotline:* ${country.ambulance}
----------------------------------------
Generated via RetinaXAI Explainable Screening System (SQLite Verified).`;

  const url = `https://api.whatsapp.com/send?text=${encodeURIComponent(message)}`;
  window.open(url, '_blank');
}

/* -------------------------------------------------------------------------- */
/* TOAST NOTIFICATION UTILITY                                                 */
/* -------------------------------------------------------------------------- */
function showToast(message) {
  const toast = document.createElement('div');
  toast.className = 'fixed bottom-5 right-5 z-50 bg-primary text-white font-medium text-sm px-4 py-3 rounded-xl shadow-xl flex items-center gap-2 animate-fade-in';
  toast.innerHTML = `<i class="fa-solid fa-circle-check"></i><span>${message}</span>`;
  document.body.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transition = 'opacity 0.3s ease';
    setTimeout(() => toast.remove(), 300);
  }, 3000);
}
