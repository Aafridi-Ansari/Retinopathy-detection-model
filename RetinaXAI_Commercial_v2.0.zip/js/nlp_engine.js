/**
 * nlp_engine.js - Clinical Natural Language Processing & Interactive Dialogue Engine
 * Specifically trained for Diabetic Retinopathy (DR) & Ocular Tele-Triage.
 * Features:
 *  - Strict Domain Guardrails (filters out-of-topic queries)
 *  - Clinical Entity Extraction (Symptoms, HbA1c, Duration, Medications, Risk)
 *  - Gemini-style Interactive Socratic Questioning & Patient Triage
 *  - Annotated Retinal Disease Diagram & Image Generation inside Chat
 */

import { getLanguage, t } from './i18n.js';

// Medical domain keywords across supported languages
const DISEASE_ONTOLOGY = [
  // English
  'retinopathy', 'diabetic', 'diabetes', 'retina', 'eye', 'eyes', 'vision', 'sight', 'blur', 'blurry',
  'blind', 'blindness', 'floaters', 'flashes', 'curtain', 'spots', 'dark', 'swelling', 'macula', 'macular',
  'fovea', 'fundus', 'capillary', 'vessel', 'microaneurysm', 'hemorrhage', 'bleed', 'bleeding', 'exudate',
  'cotton wool', 'neovascularization', 'laser', 'prp', 'injection', 'anti-vegf', 'oct', 'insulin', 'metformin',
  'hba1c', 'sugar', 'glucose', 'blood pressure', 'hypertension', 'ophthalmology', 'ophthalmologist',
  'screening', 'gradcam', 'heatmap', 'symptom', 'symptoms', 'treatment', 'prevention', 'diet', 'cure',
  'stage', 'stages', 'grade', 'npdr', 'pdr', 'pain', 'glasses', 'pupil', 'dilation', 'drops', 'cataract',
  'glaucoma', 'edema', 'dme', 'disease', 'condition', 'arogya', 'hospital', 'doctor', 'asha', 'checkup',
  
  // Hindi
  'रेटिना', 'रेटिनोपैथी', 'आंख', 'आंखें', 'नजर', 'दृष्टि', 'धुंधला', 'अंधापन', 'शुगर', 'मधुमेह',
  'इंसुलिन', 'खून', 'पर्दा', 'खून बहना', 'सूजन', 'दवा', 'इलाज', 'लक्षण', 'डॉक्टर', 'अस्पताल', 'हीटमैप',
  
  // Nepali
  'आँखा', 'दृष्टि', 'पर्दा', 'धमिलो', 'चिनी', 'चिनीरोग', 'मधुमेह', 'रगत', 'फुलेको', 'जालो', 'उपचार',
  
  // Tamil
  'கண்', 'விழித்திரை', 'பார்வை', 'சர்க்கரை', 'நீரிழிவு', 'இரத்தம்', 'குருதி', 'மருந்து',
  
  // Arabic
  'شبكية', 'عين', 'عيون', 'سكري', 'بصر', 'رؤية', 'غباش', 'نزيف', 'نضح', 'إنسولين', 'سكر', 'علاج',
  
  // Urdu
  'آنکھ', 'پردہ', 'ریٹینا', 'بینائی', 'دھندلا', 'شوگر', 'ذیابیطس', 'انسولین', 'خون', 'دھبے', 'علاج'
];

// Interactive conversation state
const conversationState = {
  step: 0,
  patientData: {
    durationYears: null,
    hba1c: null,
    symptoms: [],
    hasFlashes: null,
    medicationAdherent: null
  },
  lastIntent: null
};

/**
 * Validates if the user query is strictly within the Diabetic Retinopathy disease domain.
 */
export function isDiseaseRelated(text) {
  if (!text) return false;
  const clean = text.toLowerCase();

  // Greetings are allowed as disease conversation openers
  const greetings = ['hi', 'hello', 'namaste', 'hey', 'salam', 'marhaba', 'vanakkam', 'start', 'help', 'good morning', 'good afternoon'];
  if (greetings.some(g => clean.trim() === g || clean.startsWith(g + ' '))) {
    return true;
  }

  // Check against disease ontology
  return DISEASE_ONTOLOGY.some(term => clean.includes(term.toLowerCase()));
}

/**
 * Extracts clinical entities from user text using NLP regex patterns
 */
export function extractClinicalEntities(text) {
  const clean = text.toLowerCase();
  const entities = {
    symptoms: [],
    hba1c: null,
    durationYears: null,
    hasSevereWarning: false
  };

  // Symptoms extraction
  if (clean.includes('floater') || clean.includes('spots') || clean.includes('cobweb') || clean.includes('जाले') || clean.includes('धब्बे')) {
    entities.symptoms.push('Floaters / Vitreous opacities');
  }
  if (clean.includes('blur') || clean.includes('cloudy') || clean.includes('धुंधला') || clean.includes('धमिलो') || clean.includes('غباش')) {
    entities.symptoms.push('Visual Acuity Blurriness');
  }
  if (clean.includes('curtain') || clean.includes('dark shadow') || clean.includes('पर्दा गिरना')) {
    entities.symptoms.push('Tractional Retinal Detachment warning (Dark Curtain)');
    entities.hasSevereWarning = true;
  }
  if (clean.includes('flash') || clean.includes('flashes') || clean.includes('बिजली चमकना')) {
    entities.symptoms.push('Photopsia / Retinal traction flashes');
    entities.hasSevereWarning = true;
  }

  // Duration extraction (e.g. "8 years", "5 yrs", "10 saal")
  const durationMatch = clean.match(/(\d{1,2})\s*(?:years?|yrs?|साल|वर्ष|سنوات)/);
  if (durationMatch) {
    entities.durationYears = parseInt(durationMatch[1]);
  }

  // HbA1c extraction (e.g. "hba1c 9.2", "sugar 8.5")
  const hba1cMatch = clean.match(/(?:hba1c|sugar|a1c|reading)\s*(?:is|was|=|:)?\s*(\d{1,2}(?:\.\d)?)/);
  if (hba1cMatch) {
    entities.hba1c = parseFloat(hba1cMatch[1]);
  }

  return entities;
}

/**
 * Generates inline SVG Medical Visuals for the chat
 */
export function getMedicalDiagramSVG(type) {
  if (type === 'stages_comparison') {
    return `
      <div class="my-3 rounded-2xl overflow-hidden border border-slate-700 bg-slate-900 p-3 shadow-md">
        <div class="text-center mb-2 font-bold text-xs text-sky-400">
          <i class="fa-solid fa-eye me-1"></i> Medical Progression: Normal Retina vs Diabetic Retinopathy
        </div>
        <svg viewBox="0 0 460 170" class="w-full h-auto">
          <!-- Normal Retina Frame -->
          <g transform="translate(10, 10)">
            <circle cx="65" cy="65" r="60" fill="#a83210" stroke="#f59e0b" stroke-width="2"/>
            <!-- Optic Disc -->
            <circle cx="40" cy="65" r="16" fill="#fef3c7"/>
            <!-- Macula -->
            <circle cx="85" cy="65" r="14" fill="#601504"/>
            <circle cx="85" cy="65" r="2" fill="#fff" opacity="0.6"/>
            <!-- Normal Vessels -->
            <path d="M 40,65 Q 55,30 95,20" stroke="#5a0d0d" stroke-width="2.5" fill="none"/>
            <path d="M 40,65 Q 55,100 95,110" stroke="#5a0d0d" stroke-width="2.5" fill="none"/>
            <text x="65" y="145" text-anchor="middle" fill="#22c55e" font-size="11" font-weight="bold">Stage 0: Normal Retina</text>
            <text x="65" y="160" text-anchor="middle" fill="#94a3b8" font-size="9">Healthy Vessels & Fovea</text>
          </g>

          <!-- NPDR Frame (Microaneurysms & Exudates) -->
          <g transform="translate(160, 10)">
            <circle cx="65" cy="65" r="60" fill="#a83210" stroke="#f59e0b" stroke-width="2"/>
            <circle cx="40" cy="65" r="16" fill="#fef3c7"/>
            <circle cx="85" cy="65" r="14" fill="#601504"/>
            <path d="M 40,65 Q 55,30 95,20" stroke="#5a0d0d" stroke-width="2.5" fill="none"/>
            <!-- Microaneurysms (Red Dots) -->
            <circle cx="70" cy="45" r="2.5" fill="#450a0a"/>
            <circle cx="95" cy="50" r="2" fill="#450a0a"/>
            <circle cx="78" cy="85" r="2.5" fill="#450a0a"/>
            <!-- Hard Exudates (Yellow deposits) -->
            <circle cx="88" cy="42" r="3" fill="#fef08a"/>
            <circle cx="92" cy="40" r="2" fill="#fef08a"/>
            <circle cx="85" cy="85" r="3" fill="#fef08a"/>
            <circle cx="88" cy="88" r="2.5" fill="#fef08a"/>
            <!-- Hemorrhage blot -->
            <ellipse cx="60" cy="85" rx="5" ry="3" fill="#7f1d1d"/>
            <text x="65" y="145" text-anchor="middle" fill="#f59e0b" font-size="11" font-weight="bold">Stage 2: Moderate NPDR</text>
            <text x="65" y="160" text-anchor="middle" fill="#94a3b8" font-size="9">Microaneurysms & Exudates</text>
          </g>

          <!-- PDR Frame (Neovascularization) -->
          <g transform="translate(310, 10)">
            <circle cx="65" cy="65" r="60" fill="#881337" stroke="#ef4444" stroke-width="2.5"/>
            <circle cx="40" cy="65" r="16" fill="#fde68a"/>
            <!-- Severe Neovascular Fronds (Fragile new vessels) -->
            <path d="M 40,65 C 50,40 30,30 45,20 C 55,25 60,35 40,65" stroke="#ef4444" stroke-width="1.8" fill="none"/>
            <path d="M 40,65 C 55,80 70,75 80,95" stroke="#ef4444" stroke-width="2" fill="none"/>
            <!-- Large Vitreous Bleed -->
            <path d="M 55,55 Q 75,50 95,70 Q 75,90 55,55" fill="#450a0a" opacity="0.85"/>
            <circle cx="85" cy="65" r="14" fill="#3b0707"/>
            <text x="65" y="145" text-anchor="middle" fill="#ef4444" font-size="11" font-weight="bold">Stage 4: Proliferative (PDR)</text>
            <text x="65" y="160" text-anchor="middle" fill="#fca5a5" font-size="9">Severe Neovascularization</text>
          </g>
        </svg>
      </div>
    `;
  }

  if (type === 'gradcam_explanation') {
    return `
      <div class="my-3 rounded-2xl overflow-hidden border border-slate-700 bg-slate-900 p-3 shadow-md">
        <div class="text-center mb-2 font-bold text-xs text-amber-400">
          <i class="fa-solid fa-fire me-1"></i> Explainable AI: How Grad-CAM Saliency Heatmaps Work
        </div>
        <svg viewBox="0 0 420 130" class="w-full h-auto">
          <!-- Fundus Base Circle -->
          <circle cx="65" cy="65" r="50" fill="#9a3412"/>
          <circle cx="45" cy="65" r="12" fill="#fed7aa"/>
          <circle cx="85" cy="65" r="10" fill="#431407"/>
          
          <!-- Heatmap Overlay Simulation -->
          <circle cx="75" cy="55" r="32" fill="url(#gradCamRainbow)" opacity="0.75"/>
          <circle cx="75" cy="55" r="14" fill="#ef4444" opacity="0.9"/>

          <defs>
            <radialGradient id="gradCamRainbow" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stop-color="#ef4444"/>
              <stop offset="40%" stop-color="#f59e0b"/>
              <stop offset="70%" stop-color="#10b981"/>
              <stop offset="90%" stop-color="#0284c7"/>
              <stop offset="100%" stop-color="#1e3a8a" stop-opacity="0"/>
            </radialGradient>
          </defs>

          <!-- Explanatory Callouts -->
          <g transform="translate(135, 15)">
            <rect x="0" y="0" width="18" height="18" rx="4" fill="#ef4444"/>
            <text x="26" y="14" fill="#f8fafc" font-size="11" font-weight="bold">RED Zones (Peak Attention):</text>
            <text x="26" y="28" fill="#cbd5e1" font-size="10">Active Hemorrhages & Neovascularization</text>
          </g>

          <g transform="translate(135, 55)">
            <rect x="0" y="0" width="18" height="18" rx="4" fill="#f59e0b"/>
            <text x="26" y="14" fill="#f8fafc" font-size="11" font-weight="bold">YELLOW Zones (Moderate Attention):</text>
            <text x="26" y="28" fill="#cbd5e1" font-size="10">Hard Exudates & Microaneurysms Clusters</text>
          </g>

          <g transform="translate(135, 95)">
            <rect x="0" y="0" width="18" height="18" rx="4" fill="#0284c7"/>
            <text x="26" y="14" fill="#f8fafc" font-size="11" font-weight="bold">BLUE Zones (Zero Attention):</text>
            <text x="26" y="28" fill="#cbd5e1" font-size="10">Normal healthy retinal parenchyma</text>
          </g>
        </svg>
      </div>
    `;
  }

  return '';
}

/**
 * Main NLP Process Function for Chatbot
 * Analyzes query, handles strict domain guardrails, conducts Socratic medical interview,
 * generates disease explanations with embedded clinical visuals.
 */
export function processMedicalNLPQuery(rawText) {
  const text = (rawText || '').trim();
  const lang = getLanguage();

  // 1. STRICT DOMAIN GUARDRAIL CHECK
  if (!isDiseaseRelated(text)) {
    const outOfTopicReplies = {
      en: "Sorry, ask me about the disease only. I am trained for that only.",
      hi: "माफ़ कीजिए, मुझसे केवल इस बीमारी (डायबिटिक रेटिनोपैथी) के बारे में ही पूछें। मुझे केवल इसी के लिए प्रशिक्षित किया गया है।",
      ne: "माफ गर्नुहोस्, मलाई केवल डायबिटिक रेटिनोप्याथी रोगको बारेमा मात्र सोध्नुहोस्। म यसैका लागि मात्र प्रशिक्षित छु।",
      ta: "மன்னிக்கவும், இந்த நோய் (நீரிழிவு விழித்திரை நோய்) பற்றி மட்டுமே என்னிடம் கேளுங்கள். அதற்காக மட்டுமே நான் பயிற்சியளிக்கப்பட்டுள்ளேன்.",
      ar: "عذراً، اسألني عن هذا المرض (اعتلال الشبكية السكري) فقط. لقد تم تدريبي على ذلك حصراً.",
      ur: "معذرت، مجھ سے صرف اس بیماری (ذیابیطس ریٹینوپیتھی) کے بارے में پوچھیں۔ مجھے صرف اسی کے لیے تربیت دی گئی ہے۔"
    };

    return {
      reply: outOfTopicReplies[lang] || outOfTopicReplies.en,
      isOutOfTopic: true,
      suggestedQuestions: [
        "What is Diabetic Retinopathy?",
        "What are the warning signs of eye damage?",
        "Explain the disease stages with images",
        "How can I prevent diabetes blindness?"
      ]
    };
  }

  // 2. EXTRACT CLINICAL ENTITIES VIA NLP
  const entities = extractClinicalEntities(text);
  const clean = text.toLowerCase();

  // Update conversation memory
  if (entities.durationYears) conversationState.patientData.durationYears = entities.durationYears;
  if (entities.hba1c) conversationState.patientData.hba1c = entities.hba1c;
  if (entities.symptoms.length > 0) {
    conversationState.patientData.symptoms.push(...entities.symptoms);
  }

  // 3. SEVERE EMERGENCY DETECTED (Dark curtain, flashes, sudden blindness)
  if (entities.hasSevereWarning) {
    const emergencyReply = {
      en: `🚨 **URGENT CLINICAL ALERT:** You reported critical warning signs (${entities.symptoms.join(', ')}). In diabetic patients, sudden dark shadows or flashes indicate acute vitreous hemorrhage or imminent retinal detachment.\n\n**Action Required Immediately:** Do not wait for a routine appointment. Go to the nearest tertiary emergency eye hospital listed in the Emergency Directory within 24 to 48 hours for immediate dilated evaluation and panretinal photocoagulation (PRP) laser.\n\n*Emergency Ambulance Hotline:* **108 / 102**`,
      hi: `🚨 **तत्काल नैदानिक चेतावनी:** आपने गंभीर खतरे के लक्षण (${entities.symptoms.join(', ')}) बताए हैं। मधुमेह के रोगियों में अचानक पर्दा गिरना या बिजली चमकना रेटिना उखड़ने या आंख के भीतर रक्तस्राव का संकेत है।\n\n**तुरंत की जाने वाली कार्रवाई:** कृपया सामान्य अपॉइंटमेंट का इंतजार न करें। 24 से 48 घंटे के भीतर नजदीकी आपातकालीन नेत्र अस्पताल जाएं।\n\n*आपातकालीन एम्बुलेंस:* **108 / 102**`,
      ne: `🚨 **अति जरुरी चेतावनी:** तपाईंले आँखामा गम्भीर लक्षणहरू संकेत गर्नुभएको छ। मधुमेहका बिरामीमा आँखा अगाडि कालो पर्दा आउनु वा बत्ती चम्किनु पर्दा उप्किन लागेको संकेत हो। तुरुन्त आपतकालीन आँखा अस्पताल जानुहोस्!`
    };

    return {
      reply: emergencyReply[lang] || emergencyReply.en,
      diagram: getMedicalDiagramSVG('stages_comparison'),
      suggestedQuestions: [
        "Find nearest emergency eye hospital",
        "What causes sudden dark floaters?",
        "How does emergency laser treatment work?"
      ]
    };
  }

  // 4. REQUEST FOR IMAGE / STAGES EXPLANATION
  if (clean.includes('image') || clean.includes('photo') || clean.includes('stage') || clean.includes('explain') || clean.includes('diagram') || clean.includes('तस्वीर') || clean.includes('चित्र') || clean.includes('नक्सा') || clean.includes('चित्र')) {
    const stageReply = {
      en: `Here is a complete clinical breakdown of Diabetic Retinopathy across its 5 stages, accompanied by anatomical fundus diagrams:\n\n1. **Grade 0 (Normal Retina)**: Capillaries are intact, healthy pink optic disc, crisp foveal reflex.\n2. **Grade 1 (Mild NPDR)**: Initial microvascular ballooning (microaneurysms) appears due to high glucose damaging capillary pericytes.\n3. **Grade 2 (Moderate NPDR)**: Capillaries begin to leak blood (blot hemorrhages) and fatty lipids (hard exudates) near the macula.\n4. **Grade 3 (Severe NPDR - 4-2-1 Rule)**: Significant capillary death (ischemia), cotton wool spots, and widespread bleeding across 4 quadrants.\n5. **Grade 4 (Proliferative DR)**: Lack of oxygen triggers abnormal, fragile new vessels (neovascularization) to sprout, which can burst causing instant vitreous hemorrhage.\n\n👇 *Interactive Question for you:* Have you been screened with a fundus camera recently? What was your last HbA1c score?`,
      hi: `यहाँ डायबिटिक रेटिनोपैथी के सभी 5 चरणों का विस्तृत नैदानिक विवरण और चिकित्सीय चित्र दिया गया है:\n\n1. **ग्रेड 0 (सामान्य)**: स्वस्थ रक्त वाहिकाएं और सामान्य दृष्टि।\n2. **ग्रेड 1 (हल्का NPDR)**: रक्त वाहिकाओं में छोटे उभार (माइक्रोएन्यूरिज्म)।\n3. **ग्रेड 2 (मध्यम NPDR)**: रेटिना में रक्त के धब्बे और पीले वसा का जमाव (हार्ड एक्सुडेट्स)।\n4. **ग्रेड 3 (गंभीर NPDR)**: चारों चतुर्थांशों में गंभीर रक्तस्राव और ऑक्सीजन की कमी।\n5. **ग्रेड 4 (प्रोलिफेरेटिव PDR)**: असामान्य नई कमजोर रक्त वाहिकाओं का उगना, जिनसे आंख में गंभीर खून बहने का खतरा होता है।\n\n👇 *आपके लिए प्रश्न:* क्या आपने हाल ही में अपनी आंखों की पुतली फैलाकर रेटिना की जांच करवाई है? आपका शुगर लेवल कितना रहता है?`
    };

    return {
      reply: stageReply[lang] || stageReply.en,
      diagram: getMedicalDiagramSVG('stages_comparison'),
      suggestedQuestions: [
        "How do Grad-CAM heatmaps explain the lesions?",
        "My HbA1c is above 8.5%, what is my risk?",
        "What diet helps prevent eye damage?",
        "Can laser treatment restore lost vision?"
      ]
    };
  }

  // 5. REQUEST ABOUT GRAD-CAM / HEATMAP EXPLANATION
  if (clean.includes('gradcam') || clean.includes('heatmap') || clean.includes('color') || clean.includes('colors') || clean.includes('हीटमैप') || clean.includes('रंग')) {
    const heatReply = {
      en: `Our Explainable AI (XAI) utilizes **Grad-CAM (Gradient-weighted Class Activation Mapping)** to eliminate the 'black-box' nature of neural networks by highlighting the exact pixels driving the AI diagnosis:\n\n- 🔴 **RED / HOT Zones (Peak AI Activation)**: Localize high-threat microvascular pathology including dot-blot hemorrhages, venous beading, or neovascularization fronds.\n- 🟡 **YELLOW / AMBER Zones**: Detect lipid-rich hard exudates and early capillary microaneurysms.\n- 🔵 **BLUE / COOL Zones**: Normal, healthy retinal background tissue.\n\n👇 *Clinical Question:* Would you like to select one of the clinical sample scans on the left to see the Grad-CAM heatmap live on the retina?`,
      hi: `हमारा व्याख्यात्मक एआई (XAI) **ग्रैड-सीएएम हीटमैप** तकनीक का उपयोग करता है ताकि डॉक्टर और मरीज यह समझ सकें कि एआई ने यह फैसला क्यों लिया:\n\n- 🔴 **लाल क्षेत्र (उच्चतम ध्यान)**: रेटिना में रक्तस्राव और नई असामान्य रक्त वाहिकाओं के गंभीर खतरे को दर्शाता है।\n- 🟡 **पीला क्षेत्र**: वसा जमाव (हार्ड एक्सुडेट्स) और माइक्रोएन्यूरिज्म को दर्शाता है।\n- 🔵 **नीला क्षेत्र**: सामान्य स्वस्थ रेटिना टिश्यू।\n\n👇 *अगला सवाल:* क्या आप बाईं ओर दिए गए सैम्पल स्कैन में से किसी एक पर हीटमैप देखना चाहते हैं?`
    };

    return {
      reply: heatReply[lang] || heatReply.en,
      diagram: getMedicalDiagramSVG('gradcam_explanation'),
      suggestedQuestions: [
        "Test Grade 2 Moderate NPDR Scan",
        "Test Grade 4 Proliferative DR Scan",
        "What are hard exudates made of?",
        "How do smartphone cameras capture the retina?"
      ]
    };
  }

  // 6. SOCRATIC INTERACTIVE INTERVIEW (Gemini-Style Multi-Turn Triage)
  conversationState.step++;

  if (conversationState.step === 1) {
    const reply = {
      en: `Namaste! I am your **Arogya Netra AI Clinical Assistant**. I specialize exclusively in **Diabetic Retinopathy screening, explainable AI diagnostics, and diabetic eye care**.\n\nTo help evaluate your individual eye health and risk of vision loss, let's start with a quick 3-step assessment:\n\n**Question 1 of 3:** How many years have you been diagnosed with diabetes, and do you happen to know your latest **HbA1c percentage** or fasting blood glucose level?`,
      hi: `नमस्ते! मैं आपका **आरोग्य नेत्रा एआई क्लिनिकल सहायक** हूँ। मैं विशेष रूप से **डायबिटिक रेटिनोपैथी, एआई नेत्र जांच और मधुमेह नेत्र सुरक्षा** के लिए प्रशिक्षित हूँ।\n\nआपकी आंखों के स्वास्थ्य और अंधेपन के जोखिम का मूल्यांकन करने के लिए, आइए 3 छोटे सवालों से शुरुआत करते हैं:\n\n**पहला सवाल (1/3):** आपको कितने वर्षों से डायबिटीज (शुगर) है, और क्या आपको अपना नवीनतम **HbA1c स्तर** या शुगर रीडिंग याद है?`,
      ne: `नमस्ते! म तपाईंको **आरोग्य नेत्रा एआई क्लिनिकल सहायक** हुँ। म केवल **डायबिटिक रेटिनोप्याथी र आँखाको स्याहार** सम्बन्धी परामर्शका लागि तयार छु।\n\n**पहिलो प्रश्न (१/३):** तपाईंलाई चिनीरोग (मधुमेह) भएको कति वर्ष भयो, र पछिल्लो पटक रगतमा चिनीको मात्रा (HbA1c) कति थियो?`
    };

    return {
      reply: reply[lang] || reply.en,
      suggestedQuestions: [
        "Diabetic for 5 years, HbA1c is 8.5%",
        "Diagnosed 10+ years ago, sugar is fluctuating",
        "Just diagnosed with Type 2 diabetes recently",
        "Explain Diabetic Retinopathy stages with images"
      ]
    };
  }

  if (conversationState.step === 2) {
    const durationInfo = conversationState.patientData.durationYears 
      ? `Having diabetes for **${conversationState.patientData.durationYears} years** places your retinal blood vessels at heightened risk, as microvascular damage compounds over time.` 
      : `Thank you for sharing your history.`;

    const reply = {
      en: `${durationInfo}\n\n**Question 2 of 3:** Are you currently experiencing any of these specific vision changes?\n- 👁️ **Floaters**: Floating dark spots, black specks, or cobwebs drifting across your eyes\n- 🌫️ **Blurry Vision**: Trouble reading street signs or recognizing faces\n- 🌓 **Diminished Night Vision**: Difficulty adjusting from bright sunlight into dim rooms`,
      hi: `${durationInfo}\n\n**दूसरा सवाल (2/3):** क्या आप वर्तमान में इनमें से किसी लक्षण का अनुभव कर रहे हैं?\n- 👁️ **फ्लोटर्स**: आंखों के सामने तैरते काले धब्बे, बिंदियां या मकड़ी के जाले\n- 🌫️ **धुंधलापन**: पढ़ने में परेशानी या चेहरों का धुंधला दिखना\n- 🌓 **रात में कम दिखना**: अंधेरे में या कम रोशनी में देखने में कठिनाई`
    };

    return {
      reply: reply[lang] || reply.en,
      suggestedQuestions: [
        "Yes, seeing floating black spots & blurriness",
        "No symptoms, my vision feels normal",
        "Slight blurriness in the morning only",
        "Show me how hemorrhages look in the retina"
      ]
    };
  }

  // Final Step: Personalized Recommendation + Follow-up
  const finalSummary = conversationState.patientData.symptoms.length > 0
    ? `Based on your reported symptoms (${conversationState.patientData.symptoms.join(', ')}), you require formal tele-ophthalmology screening.`
    : `Even with zero visual symptoms, diabetic microvascular damage can develop silently in over 80% of patients.`;

  const reply = {
    en: `✅ **Clinical Triage Summary:**\n\n${finalSummary}\n\n**Key Doctor Recommendations:**\n1. **Retinal Fundus Screening**: Have an ASHA worker capture a fundus image with a smartphone condensing lens or visit a district eye center.\n2. **Glycemic & Blood Pressure Target**: Keep HbA1c strictly below **7.0%** and blood pressure below **130/80 mmHg** to halt microaneurysm progression.\n3. **Daily Medication Adherence**: Check off your daily Metformin and Insulin in our **Medicine Tracker** tab.\n\nWould you like me to explain the **Grad-CAM Explainable AI heatmaps** or find the nearest specialized eye hospital in your country?`,
    hi: `✅ **क्लिनिकल जांच सारांश:**\n\n${finalSummary}\n\n**डॉक्टर की मुख्य सलाह:**\n1. **रेटिना फंडस जांच**: आशा कार्यकर्ता की मदद से स्मार्टफोन लेंस से रेटिना की फोटो लेकर ऐप में जांच करें।\n2. **शुगर और बीपी नियंत्रण**: HbA1c को **7.0%** से नीचे और ब्लड प्रेशर को **130/80** से नीचे रखें।\n3. **दवा का समय पर सेवन**: हमारे **दवा ट्रैकर (Medicine Tracker)** में अपनी दैनिक गोलियां और इंसुलिन दर्ज करें।\n\nक्या आप **ग्रैड-सीएएम हीटमैप** को समझना चाहते हैं या अपने क्षेत्र के शीर्ष नेत्र अस्पताल की जानकारी देखना चाहते हैं?`
  };

  return {
    reply: reply[lang] || reply.en,
    diagram: getMedicalDiagramSVG('stages_comparison'),
    suggestedQuestions: [
      "Explain what the Grad-CAM heatmap colors mean",
      "Find nearest eye hospital for examination",
      "What foods help lower blood sugar naturally?",
      "How often should diabetics get their eyes checked?"
    ]
  };
}
